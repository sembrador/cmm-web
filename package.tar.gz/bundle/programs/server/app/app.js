var require = meteorInstall({"lib":{"case_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/case_utils.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var hasSpace = /\s/;
var hasSeparator = /[\W_]/;
var hasCamel = /([a-z][A-Z]|[A-Z][a-z])/;
/**
 * Remove any starting case from a `string`, like camel or snake, but keep
 * spaces and punctuation that may be important otherwise.
 *
 * @param {String} string
 * @return {String}
 */

this.toNoCase = function (string) {
  if (hasSpace.test(string)) return string.toLowerCase();
  if (hasSeparator.test(string)) return (unseparate(string) || string).toLowerCase();
  if (hasCamel.test(string)) return uncamelize(string).toLowerCase();
  return string.toLowerCase();
};
/**
 * Separator splitter.
 */


var separatorSplitter = /[\W_]+(.|$)/g;
/**
 * Un-separate a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function unseparate(string) {
  return string.replace(separatorSplitter, function (m, next) {
    return next ? ' ' + next : '';
  });
}
/**
 * Camelcase splitter.
 */


var camelSplitter = /(.)([A-Z]+)/g;
/**
 * Un-camelcase a `string`.
 *
 * @param {String} string
 * @return {String}
 */

function uncamelize(string) {
  return string.replace(camelSplitter, function (m, previous, uppers) {
    return previous + ' ' + uppers.toLowerCase().split('').join(' ');
  });
}

this.toSpaceCase = function (string) {
  return toNoCase(string).replace(/[\W_]+(.|$)/g, function (matches, match) {
    return match ? ' ' + match : '';
  }).trim();
};

this.toCamelCase = function (string) {
  return toSpaceCase(string).replace(/\s(\w)/g, function (matches, letter) {
    return letter.toUpperCase();
  });
};

this.toSnakeCase = function (string) {
  return toSpaceCase(string).replace(/\s/g, '_');
};

this.toKebabCase = function (string) {
  return toSpaceCase(string).replace(/\s/g, '-');
};

this.toTitleCase = function (string) {
  var str = toSpaceCase(string).replace(/\s(\w)/g, function (matches, letter) {
    return " " + letter.toUpperCase();
  });

  if (str) {
    str = str.charAt(0).toUpperCase() + str.slice(1);
  }

  return str;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"object_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/object_utils.js                                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/*
   Returns property value, where property name is given as path.

   Example:

       getPropertyValue("x.y.z", { x: { y: { z: 123 } } }); // returns 123
*/
this.getPropertyValue = function (propertyName, obj) {
  var props = propertyName.split(".");
  var res = obj;

  for (var i = 0; i < props.length; i++) {
    res = res[props[i]];

    if (typeof res == "undefined") {
      return res;
    }
  }

  return res;
};
/* 
   converts properties in format { "x.y": "z" } to { x: { y: "z" } }
*/


this.deepen = function (o) {
  var oo = {},
      t,
      parts,
      part;

  for (var k in o) {
    t = oo;
    parts = k.split('.');
    var key = parts.pop();

    while (parts.length) {
      part = parts.shift();
      t = t[part] = t[part] || {};
    }

    t[key] = o[k];
  }

  return oo;
};
/*
	Function converts array of objects to csv, tsv or json string

	exportFields: list of object keys to export (array of strings)
	fileType: can be "json", "csv", "tsv" (string)
*/


this.exportArrayOfObjects = function (data, exportFields, fileType) {
  data = data || [];
  fileType = fileType || "csv";
  exportFields = exportFields || [];
  var str = ""; // export to JSON

  if (fileType == "json") {
    var tmp = [];

    _.each(data, function (doc) {
      var obj = {};

      _.each(exportFields, function (field) {
        obj[field] = doc[field];
      });

      tmp.push(obj);
    });

    str = JSON.stringify(tmp);
  } // export to CSV or TSV


  if (fileType == "csv" || fileType == "tsv") {
    var columnSeparator = "";

    if (fileType == "csv") {
      columnSeparator = ",";
    }

    if (fileType == "tsv") {
      // "\t" object literal does not transpile correctly to coffeesctipt
      columnSeparator = String.fromCharCode(9);
    }

    _.each(exportFields, function (field, i) {
      if (i > 0) {
        str = str + columnSeparator;
      }

      str = str + "\"" + field + "\"";
    }); //\r does not transpile correctly to coffeescript


    str = str + String.fromCharCode(13) + "\n";

    _.each(data, function (doc) {
      _.each(exportFields, function (field, i) {
        if (i > 0) {
          str = str + columnSeparator;
        }

        var value = getPropertyValue(field, doc) + "";
        value = value.replace(/"/g, '""');
        if (typeof value == "undefined") str = str + "\"\"";else str = str + "\"" + value + "\"";
      }); //\r does not transpile correctly to coffeescript


      str = str + String.fromCharCode(13) + "\n";
    });
  }

  return str;
};

this.mergeObjects = function (target, source) {
  /* Merges two (or more) objects,
  giving the last one precedence */
  if (typeof target !== "object") {
    target = {};
  }

  for (var property in source) {
    if (source.hasOwnProperty(property)) {
      var sourceProperty = source[property];

      if (typeof sourceProperty === 'object') {
        target[property] = mergeObjects(target[property], sourceProperty);
        continue;
      }

      target[property] = sourceProperty;
    }
  }

  for (var a = 2, l = arguments.length; a < l; a++) {
    mergeObjects(target, arguments[a]);
  }

  return target;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"string_utils.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/string_utils.js                                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.escapeRegEx = function (string) {
  return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
};

this.replaceSubstrings = function (string, find, replace) {
  return string.replace(new RegExp(escapeRegEx(find), 'g'), replace);
};

this.joinStrings = function (stringArray, join) {
  var sep = join || ", ";
  var res = "";

  _.each(stringArray, function (str) {
    if (str) {
      if (res) res = res + sep;
      res = res + str;
    }
  });

  return res;
};

this.convertToSlug = function (text) {
  return text.toString().toLowerCase().replace(/\s+/g, '-') // Replace spaces with -
  .replace(/[^\w\-]+/g, '') // Remove all non-word chars
  .replace(/\-\-+/g, '-') // Replace multiple - with single -
  .replace(/^-+/, '') // Trim - from start of text
  .replace(/-+$/, ''); // Trim - from end of text
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util_varios.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/util_varios.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * Created by sembrador on 04/23/2017.
 */
Meteor.castleSoft = {
  zeroPad: function (num, size) {
    var s = num + "";

    while (s.length < size) s = "0" + s;

    return s;
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"both":{"collections":{"0_common.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/0_common.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * Created by sembrador on 04/22/2017.
 */
TabularTables = {};
i18n.setLanguage('es');
Meteor.isClient && Template.registerHelper('TabularTables', TabularTables);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_agenda_rx.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_agenda_rx.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoAgendaRx = new Mongo.Collection("info_agenda_rx");

this.InfoAgendaRx.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoAgendaRx.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoAgendaRx.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_agenda_sop.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_agenda_sop.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoAgendaSop = new Mongo.Collection("info_agenda_sop");

this.InfoAgendaSop.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoAgendaSop.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoAgendaSop.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_aseguradoras.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_aseguradoras.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoAseguradoras = new Mongo.Collection("info_aseguradoras");

this.InfoAseguradoras.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoAseguradoras.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoAseguradoras.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_clasificaciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_clasificaciones.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoClasificaciones = new Mongo.Collection("info_clasificaciones");

this.InfoClasificaciones.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoClasificaciones.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoClasificaciones.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_departamentos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_departamentos.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoDepartamentos = new Mongo.Collection("info_departamentos");

this.InfoDepartamentos.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoDepartamentos.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoDepartamentos.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_especialidades.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_especialidades.js                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoEspecialidades = new Mongo.Collection("info_especialidades");

this.InfoEspecialidades.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoEspecialidades.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoEspecialidades.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_pacientes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_pacientes.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoPacientes = new Mongo.Collection("info_pacientes");

this.InfoPacientes.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoPacientes.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoPacientes.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_planes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_planes.js                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoPlanes = new Mongo.Collection("info_planes");

this.InfoPlanes.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoPlanes.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoPlanes.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_procedimientos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_procedimientos.js                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoProcedimientos = new Mongo.Collection("info_procedimientos");

this.InfoProcedimientos.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoProcedimientos.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoProcedimientos.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_referidores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_referidores.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoReferidores = new Mongo.Collection("info_referidores");

this.InfoReferidores.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoReferidores.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoReferidores.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_secciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// both/collections/info_secciones.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
this.InfoSecciones = new Mongo.Collection("info_secciones");

this.InfoSecciones.userCanInsert = function (userId, doc) {
  return true;
};

this.InfoSecciones.userCanUpdate = function (userId, doc) {
  return true;
};

this.InfoSecciones.userCanRemove = function (userId, doc) {
  return true;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"collections":{"info_agenda_rx.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_agenda_rx.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 09:54:40
 * @modify date 2018-04-02 09:54:40
 * @desc Agenda Rx doc definition - javascript
*/
InfoAgendaRx.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoAgendaRx.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoAgendaRx.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoAgendaRx.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoAgendaRx.before.remove(function (userId, doc) {});
InfoAgendaRx.after.insert(function (userId, doc) {});
InfoAgendaRx.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoAgendaRx.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_agenda_sop.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_agenda_sop.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 09:54:40
 * @modify date 2018-04-02 09:54:40
 * @desc Agenda SOP doc definition - javascript
*/
InfoAgendaSop.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoAgendaSop.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoAgendaSop.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoAgendaSop.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoAgendaSop.before.remove(function (userId, doc) {});
InfoAgendaSop.after.insert(function (userId, doc) {});
InfoAgendaSop.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoAgendaSop.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_aseguradoras.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_aseguradoras.js                                                                        //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoAseguradoras.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoAseguradoras.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoAseguradoras.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoAseguradoras.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoAseguradoras.before.remove(function (userId, doc) {});
InfoAseguradoras.after.insert(function (userId, doc) {});
InfoAseguradoras.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoAseguradoras.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_clasificaciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_clasificaciones.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoClasificaciones.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoClasificaciones.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoClasificaciones.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoClasificaciones.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoClasificaciones.before.remove(function (userId, doc) {});
InfoClasificaciones.after.insert(function (userId, doc) {});
InfoClasificaciones.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoClasificaciones.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_departamentos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_departamentos.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoDepartamentos.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoDepartamentos.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoDepartamentos.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoDepartamentos.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoDepartamentos.before.remove(function (userId, doc) {});
InfoDepartamentos.after.insert(function (userId, doc) {});
InfoDepartamentos.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoDepartamentos.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_especialidades.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_especialidades.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoEspecialidades.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoEspecialidades.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoEspecialidades.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoEspecialidades.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoEspecialidades.before.remove(function (userId, doc) {});
InfoEspecialidades.after.insert(function (userId, doc) {});
InfoEspecialidades.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoEspecialidades.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_pacientes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_pacientes.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoPacientes.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoPacientes.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoPacientes.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoPacientes.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoPacientes.before.remove(function (userId, doc) {});
InfoPacientes.after.insert(function (userId, doc) {});
InfoPacientes.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoPacientes.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_planes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_planes.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoPlanes.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoPlanes.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoPlanes.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoPlanes.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoPlanes.before.remove(function (userId, doc) {});
InfoPlanes.after.insert(function (userId, doc) {});
InfoPlanes.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoPlanes.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_procedimientos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_procedimientos.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoProcedimientos.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoProcedimientos.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoProcedimientos.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoProcedimientos.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoProcedimientos.before.remove(function (userId, doc) {});
InfoProcedimientos.after.insert(function (userId, doc) {});
InfoProcedimientos.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoProcedimientos.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_referidores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_referidores.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoReferidores.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoReferidores.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoReferidores.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoReferidores.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoReferidores.before.remove(function (userId, doc) {});
InfoReferidores.after.insert(function (userId, doc) {});
InfoReferidores.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoReferidores.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_secciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/collections/info_secciones.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
InfoSecciones.allow({
  insert: function (userId, doc) {
    return false;
  },
  update: function (userId, doc, fields, modifier) {
    return false;
  },
  remove: function (userId, doc) {
    return false;
  }
});
InfoSecciones.before.insert(function (userId, doc) {
  doc.createdAt = new Date();
  doc.createdBy = userId;
  doc.modifiedAt = doc.createdAt;
  doc.modifiedBy = doc.createdBy;
  if (!doc.createdBy) doc.createdBy = userId;
});
InfoSecciones.before.update(function (userId, doc, fieldNames, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
});
InfoSecciones.before.upsert(function (userId, selector, modifier, options) {
  modifier.$set = modifier.$set || {};
  modifier.$set.modifiedAt = new Date();
  modifier.$set.modifiedBy = userId;
  /*BEFORE_UPSERT_CODE*/
});
InfoSecciones.before.remove(function (userId, doc) {});
InfoSecciones.after.insert(function (userId, doc) {});
InfoSecciones.after.update(function (userId, doc, fieldNames, modifier, options) {});
InfoSecciones.after.remove(function (userId, doc) {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"controllers":{"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/controllers/router.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Router.map(function () {});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"info_agenda_rx.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_agenda_rx.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 09:59:31
 * @modify date 2018-04-02 09:59:31
 * @desc Agenda Rx methods - javascript
*/
Meteor.methods({
  "infoAgendaRxInsert": function (data) {
    check(data, {
      title: String,
      start: String,
      end: String,
      type: String,
      guests: Number
    });

    if (!InfoAgendaRx.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaRx.insert(data);
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  },
  "infoAgendaRxUpdate": function (data) {
    check(data, {
      _id: String,
      title: Match.Optional(String),
      start: String,
      end: String,
      type: Match.Optional(String),
      guests: Match.Optional(Number)
    });
    var doc = InfoAgendaRx.findOne({
      _id: data._id
    });

    if (!InfoAgendaRx.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaRx.update({
          _id: data._id
        }, {
          $set: data
        });
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  },
  "infoAgendaRxRemove": function (id) {
    check(id, String);
    var doc = InfoAgendaRx.findOne({
      _id: id
    });

    if (!InfoAgendaRx.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaRx.remove({
          _id: id
        });
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_agenda_sop.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_agenda_sop.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 09:59:31
 * @modify date 2018-04-02 09:59:31
 * @desc Agenda Sop methods - javascript
*/
Meteor.methods({
  "infoAgendaSopInsert": function (data) {
    check(data, {
      title: String,
      start: String,
      end: String,
      type: String,
      guests: Number
    });

    if (!InfoAgendaSop.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaSop.insert(data);
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  },
  "infoAgendaSopUpdate": function (data) {
    check(data, {
      _id: String,
      title: Match.Optional(String),
      start: String,
      end: String,
      type: Match.Optional(String),
      guests: Match.Optional(Number)
    });
    var doc = InfoAgendaSop.findOne({
      _id: data._id
    });

    if (!InfoAgendaSop.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaSop.update({
          _id: data._id
        }, {
          $set: data
        });
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  },
  "infoAgendaSopRemove": function (id) {
    check(id, String);
    var doc = InfoAgendaSop.findOne({
      _id: id
    });

    if (!InfoAgendaSop.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "PROHIBIDO.");
    } else {
      try {
        return InfoAgendaSop.remove({
          _id: id
        });
      } catch (exception) {
        throw new Meteor.Error(500, '' + exception);
      }
    }
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_aseguradoras.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_aseguradoras.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoAseguradorasInsert": function (data) {
    if (!InfoAseguradoras.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoAseguradoras.insert(data);
  },
  "infoAseguradorasUpdate": function (id, data) {
    var doc = InfoAseguradoras.findOne({
      _id: id
    });

    if (!InfoAseguradoras.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoAseguradoras.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoAseguradorasRemove": function (id) {
    var doc = InfoAseguradoras.findOne({
      _id: id
    });

    if (!InfoAseguradoras.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoAseguradoras.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_clasificaciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_clasificaciones.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoClasificacionesInsert": function (data) {
    if (!InfoClasificaciones.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoClasificaciones.insert(data);
  },
  "infoClasificacionesUpdate": function (id, data) {
    var doc = InfoClasificaciones.findOne({
      _id: id
    });

    if (!InfoClasificaciones.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoClasificaciones.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoClasificacionesRemove": function (id) {
    var doc = InfoClasificaciones.findOne({
      _id: id
    });

    if (!InfoClasificaciones.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoClasificaciones.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_departamentos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_departamentos.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoDepartamentosInsert": function (data) {
    if (!InfoDepartamentos.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoDepartamentos.insert(data);
  },
  "infoDepartamentosUpdate": function (id, data) {
    var doc = InfoDepartamentos.findOne({
      _id: id
    });

    if (!InfoDepartamentos.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoDepartamentos.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoDepartamentosRemove": function (id) {
    var doc = InfoDepartamentos.findOne({
      _id: id
    });

    if (!InfoDepartamentos.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoDepartamentos.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_especialidades.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_especialidades.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoEspecialidadesInsert": function (data) {
    if (!InfoEspecialidades.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoEspecialidades.insert(data);
  },
  "infoEspecialidadesUpdate": function (id, data) {
    var doc = InfoEspecialidades.findOne({
      _id: id
    });

    if (!InfoEspecialidades.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoEspecialidades.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoEspecialidadesRemove": function (id) {
    var doc = InfoEspecialidades.findOne({
      _id: id
    });

    if (!InfoEspecialidades.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoEspecialidades.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_pacientes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_pacientes.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoPacientesInsert": function (data) {
    if (!InfoPacientes.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoPacientes.insert(data);
  },
  "infoPacientesUpdate": function (id, data) {
    var doc = InfoPacientes.findOne({
      _id: id
    });

    if (!InfoPacientes.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoPacientes.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoPacientesRemove": function (id) {
    var doc = InfoPacientes.findOne({
      _id: id
    });

    if (!InfoPacientes.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoPacientes.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_planes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_planes.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoPlanesInsert": function (data) {
    if (!InfoPlanes.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoPlanes.insert(data);
  },
  "infoPlanesUpdate": function (id, data) {
    var doc = InfoPlanes.findOne({
      _id: id
    });

    if (!InfoPlanes.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoPlanes.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoPlanesRemove": function (id) {
    var doc = InfoPlanes.findOne({
      _id: id
    });

    if (!InfoPlanes.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoPlanes.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_procedimientos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_procedimientos.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoProcedimientosInsert": function (data) {
    if (!InfoProcedimientos.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoProcedimientos.insert(data);
  },
  "infoProcedimientosUpdate": function (id, data) {
    var doc = InfoProcedimientos.findOne({
      _id: id
    });

    if (!InfoProcedimientos.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoProcedimientos.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoProcedimientosRemove": function (id) {
    var doc = InfoProcedimientos.findOne({
      _id: id
    });

    if (!InfoProcedimientos.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoProcedimientos.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_referidores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_referidores.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoReferidoresInsert": function (data) {
    if (!InfoReferidores.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoReferidores.insert(data);
  },
  "infoReferidoresUpdate": function (id, data) {
    var doc = InfoReferidores.findOne({
      _id: id
    });

    if (!InfoReferidores.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoReferidores.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoReferidoresRemove": function (id) {
    var doc = InfoReferidores.findOne({
      _id: id
    });

    if (!InfoReferidores.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoReferidores.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_secciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/methods/info_secciones.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.methods({
  "infoSeccionesInsert": function (data) {
    if (!InfoSecciones.userCanInsert(this.userId, data)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    return InfoSecciones.insert(data);
  },
  "infoSeccionesUpdate": function (id, data) {
    var doc = InfoSecciones.findOne({
      _id: id
    });

    if (!InfoSecciones.userCanUpdate(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoSecciones.update({
      _id: id
    }, {
      $set: data
    });
  },
  "infoSeccionesRemove": function (id) {
    var doc = InfoSecciones.findOne({
      _id: id
    });

    if (!InfoSecciones.userCanRemove(this.userId, doc)) {
      throw new Meteor.Error(403, "Forbidden.");
    }

    InfoSecciones.remove({
      _id: id
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publish":{"info_agenda_rx.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_agenda_rx.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 11:08:29
 * @modify date 2018-04-02 11:08:29
 * @desc Agenda Rx publish functions - javascript
*/
Meteor.publish("info_agenda_rx_list", function () {
  return InfoAgendaRx.find({}, {});
});
Meteor.publish("info_agenda_rx_null", function () {
  return InfoAgendaRx.find({
    _id: null
  }, {});
});
Meteor.publish("info_agenda_rx", function (infoEventRxId) {
  return InfoAgendaRx.find({
    _id: infoEventRxId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_agenda_sop.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_agenda_sop.js                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * @author Leandro Camaño Guerrero
 * @email developer@castle-soft.com
 * @create date 2018-04-02 11:08:29
 * @modify date 2018-04-02 11:08:29
 * @desc Agenda Sop publish functions - javascript
*/
Meteor.publish("info_agenda_Sop_list", function () {
  return InfoAgendaSop.find({}, {});
});
Meteor.publish("info_agenda_Sop_null", function () {
  return InfoAgendaSop.find({
    _id: null
  }, {});
});
Meteor.publish("info_agenda_Sop", function (infoEventSopId) {
  return InfoAgendaSop.find({
    _id: infoEventSopId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_aseguradoras.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_aseguradoras.js                                                                            //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("aseguradora_list", function () {
  return InfoAseguradoras.find({}, {});
});
Meteor.publish("aseguradoras_null", function () {
  return InfoAseguradoras.find({
    _id: null
  }, {});
});
Meteor.publish("aseguradora", function (aseguradoraId) {
  return InfoAseguradoras.find({
    _id: aseguradoraId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_clasificaciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_clasificaciones.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("clasificacion_list", function () {
  return InfoClasificaciones.find({}, {});
});
Meteor.publish("clasificaciones_null", function () {
  return InfoClasificaciones.find({
    _id: null
  }, {});
});
Meteor.publish("clasificacion", function (clasificacionId) {
  return InfoClasificaciones.find({
    _id: clasificacionId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_departamentos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_departamentos.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("departamento_list", function () {
  return InfoDepartamentos.find({}, {});
});
Meteor.publish("departamentos_null", function () {
  return InfoDepartamentos.find({
    _id: null
  }, {});
});
Meteor.publish("departamento", function (departamentoId) {
  return InfoDepartamentos.find({
    _id: departamentoId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_especialidades.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_especialidades.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("especialidad_list", function () {
  return InfoEspecialidades.find({}, {});
});
Meteor.publish("especialidades_null", function () {
  return InfoEspecialidades.find({
    _id: null
  }, {});
});
Meteor.publish("especialidad", function (especialidadId) {
  return InfoEspecialidades.find({
    _id: especialidadId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_pacientes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_pacientes.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("pacientes", function () {
  return InfoPacientes.find({}, {});
});
Meteor.publish("paciente_list", function () {
  return InfoPacientes.find({}, {});
});
Meteor.publish("pacientes_null", function () {
  return InfoPacientes.find({
    _id: null
  }, {});
});
Meteor.publish("paciente", function (pacienteId) {
  return InfoPacientes.find({
    _id: pacienteId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_planes.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_planes.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("plan_list", function () {
  return InfoPlanes.find({}, {});
});
Meteor.publish("planes_null", function () {
  return InfoPlanes.find({
    _id: null
  }, {});
});
Meteor.publish("plan", function (planId) {
  return InfoPlanes.find({
    _id: planId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_procedimientos.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_procedimientos.js                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("procedimiento_list", function () {
  return InfoProcedimientos.find({}, {});
});
Meteor.publish("procedimientos_null", function () {
  return InfoProcedimientos.find({
    _id: null
  }, {});
});
Meteor.publish("procedimiento", function (procedimientoId) {
  return InfoProcedimientos.find({
    _id: procedimientoId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_referidores.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_referidores.js                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("referidor_list", function () {
  return InfoReferidores.find({}, {});
});
Meteor.publish("referidores_null", function () {
  return InfoReferidores.find({
    _id: null
  }, {});
});
Meteor.publish("referidor", function (referidorId) {
  return InfoReferidores.find({
    _id: referidorId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"info_secciones.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/publish/info_secciones.js                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Meteor.publish("seccion_list", function () {
  return InfoSecciones.find({}, {});
});
Meteor.publish("secciones_null", function () {
  return InfoSecciones.find({
    _id: null
  }, {});
});
Meteor.publish("seccion", function (seccionId) {
  return InfoSecciones.find({
    _id: seccionId
  }, {});
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/server.js                                                                                               //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var verifyEmail = true;
Accounts.config({
  sendVerificationEmail: verifyEmail
});
Accounts.emailTemplates.siteName = 'CMM-Web';
Accounts.emailTemplates.from = 'CMM-Web Admin <support@castle-soft.com>';
/*Accounts.emailTemplates.enrollAccount.subject = (user) => {
  return 'Bienvenid@ a CMM-Web, ${user.profile.name}';
};

Accounts.emailTemplates.enrollAccount.text = (user, url) => {
  return 'Para verificar su direccion de correo haga click sobre el siguiente enlace.\n\n'
    + url;
};

Accounts.emailTemplates.resetPassword.from = () => {
  // Overrides the value set in `Accounts.emailTemplates.from` when resetting
  // passwords.
  return 'AwesomeSite Password Reset <no-reply@example.com>';
};*/

Accounts.emailTemplates.verifyEmail = {
  subject() {
    return "Como verificar su direccion de correo en app.marbellacm.net";
  },

  text(user, url) {
    return 'Hola ' + user.profile.name + '!,\n\n' + 'Verifique su direccion de correo en el siguiente enlace:\n\n' + url + '\n\n' + 'Por Favor y Gracias,\n\n' + 'El Equipo de CMM-Web.';
  }

};
Meteor.startup(function () {
  // read environment variables from Meteor.settings
  if (Meteor.settings && Meteor.settings.env && _.isObject(Meteor.settings.env)) {
    for (var variableName in Meteor.settings.env) {
      process.env[variableName] = Meteor.settings.env[variableName];
    }
  } //
  // Setup OAuth login service configuration (read from Meteor.settings)
  //
  // Your settings file should look like this:
  //
  // {
  //     "oauth": {
  //         "google": {
  //             "clientId": "yourClientId",
  //             "secret": "yourSecret"
  //         },
  //         "github": {
  //             "clientId": "yourClientId",
  //             "secret": "yourSecret"
  //         }
  //     }
  // }
  //


  if (Accounts && Accounts.loginServiceConfiguration && Meteor.settings && Meteor.settings.oauth && _.isObject(Meteor.settings.oauth)) {
    // google
    if (Meteor.settings.oauth.google && _.isObject(Meteor.settings.oauth.google)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "google"
      });
      var settingsObject = Meteor.settings.oauth.google;
      settingsObject.service = "google"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // github


    if (Meteor.settings.oauth.github && _.isObject(Meteor.settings.oauth.github)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "github"
      });
      var settingsObject = Meteor.settings.oauth.github;
      settingsObject.service = "github"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // linkedin


    if (Meteor.settings.oauth.linkedin && _.isObject(Meteor.settings.oauth.linkedin)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "linkedin"
      });
      var settingsObject = Meteor.settings.oauth.linkedin;
      settingsObject.service = "linkedin"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // facebook


    if (Meteor.settings.oauth.facebook && _.isObject(Meteor.settings.oauth.facebook)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "facebook"
      });
      var settingsObject = Meteor.settings.oauth.facebook;
      settingsObject.service = "facebook"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // twitter


    if (Meteor.settings.oauth.twitter && _.isObject(Meteor.settings.oauth.twitter)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "twitter"
      });
      var settingsObject = Meteor.settings.oauth.twitter;
      settingsObject.service = "twitter"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    } // meteor


    if (Meteor.settings.oauth.meteor && _.isObject(Meteor.settings.oauth.meteor)) {
      // remove old configuration
      Accounts.loginServiceConfiguration.remove({
        service: "meteor-developer"
      });
      var settingsObject = Meteor.settings.oauth.meteor;
      settingsObject.service = "meteor-developer"; // add new configuration

      Accounts.loginServiceConfiguration.insert(settingsObject);
    }
  }
});
Meteor.methods({
  "createUserAccount": function (options) {
    if (!Users.isAdmin(Meteor.userId())) {
      throw new Meteor.Error(403, "ACCESO DENEGADO.");
    }

    var userOptions = {};
    if (options.username) userOptions.username = options.username;
    if (options.email) userOptions.email = options.email;
    if (options.password) userOptions.password = options.password;
    if (options.profile) userOptions.profile = options.profile;
    if (options.profile && options.profile.email) userOptions.email = options.profile.email;
    Accounts.createUser(userOptions);
  },
  "updateUserAccount": function (userId, options) {
    // only admin or users own profile
    if (!(Users.isAdmin(Meteor.userId()) || userId == Meteor.userId())) {
      throw new Meteor.Error(403, "ACCESO DENEGADO.");
    } // non-admin user can change only profile


    if (!Users.isAdmin(Meteor.userId())) {
      var keys = Object.keys(options);

      if (keys.length !== 1 || !options.profile) {
        throw new Meteor.Error(403, "ACCESO DENEGADO.");
      }
    }

    var userOptions = {};
    if (options.username) userOptions.username = options.username;
    if (options.email) userOptions.email = options.email;
    if (options.password) userOptions.password = options.password;
    if (options.profile) userOptions.profile = options.profile;
    if (options.profile && options.profile.email) userOptions.email = options.profile.email;
    if (options.roles) userOptions.roles = options.roles;

    if (userOptions.email) {
      var email = userOptions.email;
      delete userOptions.email;
      var userData = Users.findOne(this.userId);

      if (userData.emails && !userData.emails.find(function (mail) {
        return mail.address == email;
      })) {
        userOptions.emails = [{
          address: email
        }];
      }
    }

    var password = "";

    if (userOptions.password) {
      password = userOptions.password;
      delete userOptions.password;
    }

    if (userOptions) {
      for (var key in userOptions) {
        var obj = userOptions[key];

        if (_.isObject(obj)) {
          for (var k in obj) {
            userOptions[key + "." + k] = obj[k];
          }

          delete userOptions[key];
        }
      }

      Users.update(userId, {
        $set: userOptions
      });
    }

    if (password) {
      Accounts.setPassword(userId, password);
    }
  },
  "sendMail": function (options) {
    this.unblock();
    Email.send(options);
  }
});
Accounts.onCreateUser(function (options, user) {
  user.roles = ["user"];

  if (options.profile) {
    user.profile = options.profile;
  }

  if (!Users.findOne({
    roles: "admin"
  }) && user.roles.indexOf("admin") < 0) {
    user.roles = ["admin"];
  }

  return user;
});
Accounts.validateLoginAttempt(function (info) {
  // reject users with role "blocked"
  if (info.user && Users.isInRole(info.user._id, "blocked")) {
    throw new Meteor.Error(403, "SU CUENTA ESTA BLOQUEADA.");
  }

  if (verifyEmail && info.user && info.user.emails && info.user.emails.length && !info.user.emails[0].verified) {
    throw new Meteor.Error(499, "CORREO NO VERIFICADO.");
  }

  return true;
});
Users.before.insert(function (userId, doc) {
  if (doc.emails && doc.emails[0] && doc.emails[0].address) {
    doc.profile = doc.profile || {};
    doc.profile.email = doc.emails[0].address;
  } else {
    // oauth
    if (doc.services) {
      // google e-mail
      if (doc.services.google && doc.services.google.email) {
        doc.profile = doc.profile || {};
        doc.profile.email = doc.services.google.email;
      } else {
        // github e-mail
        if (doc.services.github && doc.services.github.accessToken) {
          var github = new GitHub({
            version: "3.0.0",
            timeout: 5000
          });
          github.authenticate({
            type: "oauth",
            token: doc.services.github.accessToken
          });

          try {
            var result = github.user.getEmails({});

            var email = _.findWhere(result, {
              primary: true
            });

            if (!email && result.length && _.isString(result[0])) {
              email = {
                email: result[0]
              };
            }

            if (email) {
              doc.profile = doc.profile || {};
              doc.profile.email = email.email;
            }
          } catch (e) {
            console.log(e);
          }
        } else {
          // linkedin email
          if (doc.services.linkedin && doc.services.linkedin.emailAddress) {
            doc.profile = doc.profile || {};
            doc.profile.name = doc.services.linkedin.firstName + " " + doc.services.linkedin.lastName;
            doc.profile.email = doc.services.linkedin.emailAddress;
          } else {
            if (doc.services.facebook && doc.services.facebook.email) {
              doc.profile = doc.profile || {};
              doc.profile.email = doc.services.facebook.email;
            } else {
              if (doc.services.twitter && doc.services.twitter.email) {
                doc.profile = doc.profile || {};
                doc.profile.email = doc.services.twitter.email;
              } else {
                if (doc.services["meteor-developer"] && doc.services["meteor-developer"].emails && doc.services["meteor-developer"].emails.length) {
                  doc.profile = doc.profile || {};
                  doc.profile.email = doc.services["meteor-developer"].emails[0].address;
                }
              }
            }
          }
        }
      }
    }
  }
});
Users.before.update(function (userId, doc, fieldNames, modifier, options) {
  if (modifier.$set && modifier.$set.emails && modifier.$set.emails.length && modifier.$set.emails[0].address) {
    modifier.$set.profile.email = modifier.$set.emails[0].address;
  }
});
Accounts.onLogin(function (info) {});

Accounts.urls.resetPassword = function (token) {
  return Meteor.absoluteUrl('reset_password/' + token);
};

Accounts.urls.verifyEmail = function (token) {
  return Meteor.absoluteUrl('verify_email/' + token);
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/case_utils.js");
require("/lib/object_utils.js");
require("/lib/string_utils.js");
require("/lib/util_varios.js");
require("/both/collections/0_common.js");
require("/both/collections/info_agenda_rx.js");
require("/both/collections/info_agenda_sop.js");
require("/both/collections/info_aseguradoras.js");
require("/both/collections/info_clasificaciones.js");
require("/both/collections/info_departamentos.js");
require("/both/collections/info_especialidades.js");
require("/both/collections/info_pacientes.js");
require("/both/collections/info_planes.js");
require("/both/collections/info_procedimientos.js");
require("/both/collections/info_referidores.js");
require("/both/collections/info_secciones.js");
require("/server/collections/info_agenda_rx.js");
require("/server/collections/info_agenda_sop.js");
require("/server/collections/info_aseguradoras.js");
require("/server/collections/info_clasificaciones.js");
require("/server/collections/info_departamentos.js");
require("/server/collections/info_especialidades.js");
require("/server/collections/info_pacientes.js");
require("/server/collections/info_planes.js");
require("/server/collections/info_procedimientos.js");
require("/server/collections/info_referidores.js");
require("/server/collections/info_secciones.js");
require("/server/controllers/router.js");
require("/server/methods/info_agenda_rx.js");
require("/server/methods/info_agenda_sop.js");
require("/server/methods/info_aseguradoras.js");
require("/server/methods/info_clasificaciones.js");
require("/server/methods/info_departamentos.js");
require("/server/methods/info_especialidades.js");
require("/server/methods/info_pacientes.js");
require("/server/methods/info_planes.js");
require("/server/methods/info_procedimientos.js");
require("/server/methods/info_referidores.js");
require("/server/methods/info_secciones.js");
require("/server/publish/info_agenda_rx.js");
require("/server/publish/info_agenda_sop.js");
require("/server/publish/info_aseguradoras.js");
require("/server/publish/info_clasificaciones.js");
require("/server/publish/info_departamentos.js");
require("/server/publish/info_especialidades.js");
require("/server/publish/info_pacientes.js");
require("/server/publish/info_planes.js");
require("/server/publish/info_procedimientos.js");
require("/server/publish/info_referidores.js");
require("/server/publish/info_secciones.js");
require("/server/server.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2Nhc2VfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9vYmplY3RfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi9zdHJpbmdfdXRpbHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2xpYi91dGlsX3Zhcmlvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy8wX2NvbW1vbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy9pbmZvX2FnZW5kYV9yeC5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy9pbmZvX2FnZW5kYV9zb3AuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19hc2VndXJhZG9yYXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19jbGFzaWZpY2FjaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19kZXBhcnRhbWVudG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL2NvbGxlY3Rpb25zL2luZm9fZXNwZWNpYWxpZGFkZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19wYWNpZW50ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19wbGFuZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2JvdGgvY29sbGVjdGlvbnMvaW5mb19wcm9jZWRpbWllbnRvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvYm90aC9jb2xsZWN0aW9ucy9pbmZvX3JlZmVyaWRvcmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9ib3RoL2NvbGxlY3Rpb25zL2luZm9fc2VjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW5mb19hZ2VuZGFfcnguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb2xsZWN0aW9ucy9pbmZvX2FnZW5kYV9zb3AuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb2xsZWN0aW9ucy9pbmZvX2FzZWd1cmFkb3Jhcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL2luZm9fY2xhc2lmaWNhY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW5mb19kZXBhcnRhbWVudG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW5mb19lc3BlY2lhbGlkYWRlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL2luZm9fcGFjaWVudGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW5mb19wbGFuZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9jb2xsZWN0aW9ucy9pbmZvX3Byb2NlZGltaWVudG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29sbGVjdGlvbnMvaW5mb19yZWZlcmlkb3Jlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2NvbGxlY3Rpb25zL2luZm9fc2VjY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY29udHJvbGxlcnMvcm91dGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9pbmZvX2FnZW5kYV9yeC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZHMvaW5mb19hZ2VuZGFfc29wLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9pbmZvX2FzZWd1cmFkb3Jhcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZHMvaW5mb19jbGFzaWZpY2FjaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL2luZm9fZGVwYXJ0YW1lbnRvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZHMvaW5mb19lc3BlY2lhbGlkYWRlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21ldGhvZHMvaW5mb19wYWNpZW50ZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tZXRob2RzL2luZm9fcGxhbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9pbmZvX3Byb2NlZGltaWVudG9zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9pbmZvX3JlZmVyaWRvcmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWV0aG9kcy9pbmZvX3NlY2Npb25lcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvaW5mb19hZ2VuZGFfcnguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL2luZm9fYWdlbmRhX3NvcC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvaW5mb19hc2VndXJhZG9yYXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL2luZm9fY2xhc2lmaWNhY2lvbmVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGlzaC9pbmZvX2RlcGFydGFtZW50b3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL2luZm9fZXNwZWNpYWxpZGFkZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wdWJsaXNoL2luZm9fcGFjaWVudGVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvcHVibGlzaC9pbmZvX3BsYW5lcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvaW5mb19wcm9jZWRpbWllbnRvcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvaW5mb19yZWZlcmlkb3Jlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2gvaW5mb19zZWNjaW9uZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zZXJ2ZXIuanMiXSwibmFtZXMiOlsiaGFzU3BhY2UiLCJoYXNTZXBhcmF0b3IiLCJoYXNDYW1lbCIsInRvTm9DYXNlIiwic3RyaW5nIiwidGVzdCIsInRvTG93ZXJDYXNlIiwidW5zZXBhcmF0ZSIsInVuY2FtZWxpemUiLCJzZXBhcmF0b3JTcGxpdHRlciIsInJlcGxhY2UiLCJtIiwibmV4dCIsImNhbWVsU3BsaXR0ZXIiLCJwcmV2aW91cyIsInVwcGVycyIsInNwbGl0Iiwiam9pbiIsInRvU3BhY2VDYXNlIiwibWF0Y2hlcyIsIm1hdGNoIiwidHJpbSIsInRvQ2FtZWxDYXNlIiwibGV0dGVyIiwidG9VcHBlckNhc2UiLCJ0b1NuYWtlQ2FzZSIsInRvS2ViYWJDYXNlIiwidG9UaXRsZUNhc2UiLCJzdHIiLCJjaGFyQXQiLCJzbGljZSIsImdldFByb3BlcnR5VmFsdWUiLCJwcm9wZXJ0eU5hbWUiLCJvYmoiLCJwcm9wcyIsInJlcyIsImkiLCJsZW5ndGgiLCJkZWVwZW4iLCJvIiwib28iLCJ0IiwicGFydHMiLCJwYXJ0IiwiayIsImtleSIsInBvcCIsInNoaWZ0IiwiZXhwb3J0QXJyYXlPZk9iamVjdHMiLCJkYXRhIiwiZXhwb3J0RmllbGRzIiwiZmlsZVR5cGUiLCJ0bXAiLCJfIiwiZWFjaCIsImRvYyIsImZpZWxkIiwicHVzaCIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb2x1bW5TZXBhcmF0b3IiLCJTdHJpbmciLCJmcm9tQ2hhckNvZGUiLCJ2YWx1ZSIsIm1lcmdlT2JqZWN0cyIsInRhcmdldCIsInNvdXJjZSIsInByb3BlcnR5IiwiaGFzT3duUHJvcGVydHkiLCJzb3VyY2VQcm9wZXJ0eSIsImEiLCJsIiwiYXJndW1lbnRzIiwiZXNjYXBlUmVnRXgiLCJyZXBsYWNlU3Vic3RyaW5ncyIsImZpbmQiLCJSZWdFeHAiLCJqb2luU3RyaW5ncyIsInN0cmluZ0FycmF5Iiwic2VwIiwiY29udmVydFRvU2x1ZyIsInRleHQiLCJ0b1N0cmluZyIsIk1ldGVvciIsImNhc3RsZVNvZnQiLCJ6ZXJvUGFkIiwibnVtIiwic2l6ZSIsInMiLCJUYWJ1bGFyVGFibGVzIiwiaTE4biIsInNldExhbmd1YWdlIiwiaXNDbGllbnQiLCJUZW1wbGF0ZSIsInJlZ2lzdGVySGVscGVyIiwiSW5mb0FnZW5kYVJ4IiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwidXNlckNhbkluc2VydCIsInVzZXJJZCIsInVzZXJDYW5VcGRhdGUiLCJ1c2VyQ2FuUmVtb3ZlIiwiSW5mb0FnZW5kYVNvcCIsIkluZm9Bc2VndXJhZG9yYXMiLCJJbmZvQ2xhc2lmaWNhY2lvbmVzIiwiSW5mb0RlcGFydGFtZW50b3MiLCJJbmZvRXNwZWNpYWxpZGFkZXMiLCJJbmZvUGFjaWVudGVzIiwiSW5mb1BsYW5lcyIsIkluZm9Qcm9jZWRpbWllbnRvcyIsIkluZm9SZWZlcmlkb3JlcyIsIkluZm9TZWNjaW9uZXMiLCJhbGxvdyIsImluc2VydCIsInVwZGF0ZSIsImZpZWxkcyIsIm1vZGlmaWVyIiwicmVtb3ZlIiwiYmVmb3JlIiwiY3JlYXRlZEF0IiwiRGF0ZSIsImNyZWF0ZWRCeSIsIm1vZGlmaWVkQXQiLCJtb2RpZmllZEJ5IiwiZmllbGROYW1lcyIsIm9wdGlvbnMiLCIkc2V0IiwidXBzZXJ0Iiwic2VsZWN0b3IiLCJhZnRlciIsIlJvdXRlciIsIm1hcCIsIm1ldGhvZHMiLCJjaGVjayIsInRpdGxlIiwic3RhcnQiLCJlbmQiLCJ0eXBlIiwiZ3Vlc3RzIiwiTnVtYmVyIiwiRXJyb3IiLCJleGNlcHRpb24iLCJfaWQiLCJNYXRjaCIsIk9wdGlvbmFsIiwiZmluZE9uZSIsImlkIiwicHVibGlzaCIsImluZm9FdmVudFJ4SWQiLCJpbmZvRXZlbnRTb3BJZCIsImFzZWd1cmFkb3JhSWQiLCJjbGFzaWZpY2FjaW9uSWQiLCJkZXBhcnRhbWVudG9JZCIsImVzcGVjaWFsaWRhZElkIiwicGFjaWVudGVJZCIsInBsYW5JZCIsInByb2NlZGltaWVudG9JZCIsInJlZmVyaWRvcklkIiwic2VjY2lvbklkIiwidmVyaWZ5RW1haWwiLCJBY2NvdW50cyIsImNvbmZpZyIsInNlbmRWZXJpZmljYXRpb25FbWFpbCIsImVtYWlsVGVtcGxhdGVzIiwic2l0ZU5hbWUiLCJmcm9tIiwic3ViamVjdCIsInVzZXIiLCJ1cmwiLCJwcm9maWxlIiwibmFtZSIsInN0YXJ0dXAiLCJzZXR0aW5ncyIsImVudiIsImlzT2JqZWN0IiwidmFyaWFibGVOYW1lIiwicHJvY2VzcyIsImxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24iLCJvYXV0aCIsImdvb2dsZSIsInNlcnZpY2UiLCJzZXR0aW5nc09iamVjdCIsImdpdGh1YiIsImxpbmtlZGluIiwiZmFjZWJvb2siLCJ0d2l0dGVyIiwibWV0ZW9yIiwiVXNlcnMiLCJpc0FkbWluIiwidXNlck9wdGlvbnMiLCJ1c2VybmFtZSIsImVtYWlsIiwicGFzc3dvcmQiLCJjcmVhdGVVc2VyIiwia2V5cyIsIk9iamVjdCIsInJvbGVzIiwidXNlckRhdGEiLCJlbWFpbHMiLCJtYWlsIiwiYWRkcmVzcyIsInNldFBhc3N3b3JkIiwidW5ibG9jayIsIkVtYWlsIiwic2VuZCIsIm9uQ3JlYXRlVXNlciIsImluZGV4T2YiLCJ2YWxpZGF0ZUxvZ2luQXR0ZW1wdCIsImluZm8iLCJpc0luUm9sZSIsInZlcmlmaWVkIiwic2VydmljZXMiLCJhY2Nlc3NUb2tlbiIsIkdpdEh1YiIsInZlcnNpb24iLCJ0aW1lb3V0IiwiYXV0aGVudGljYXRlIiwidG9rZW4iLCJyZXN1bHQiLCJnZXRFbWFpbHMiLCJmaW5kV2hlcmUiLCJwcmltYXJ5IiwiaXNTdHJpbmciLCJlIiwiY29uc29sZSIsImxvZyIsImVtYWlsQWRkcmVzcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwib25Mb2dpbiIsInVybHMiLCJyZXNldFBhc3N3b3JkIiwiYWJzb2x1dGVVcmwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsV0FBVyxJQUFmO0FBQ0EsSUFBSUMsZUFBZSxPQUFuQjtBQUNBLElBQUlDLFdBQVcseUJBQWY7QUFFQTs7Ozs7Ozs7QUFRQSxLQUFLQyxRQUFMLEdBQWdCLFVBQVNDLE1BQVQsRUFBaUI7QUFDL0IsTUFBSUosU0FBU0ssSUFBVCxDQUFjRCxNQUFkLENBQUosRUFBMkIsT0FBT0EsT0FBT0UsV0FBUCxFQUFQO0FBQzNCLE1BQUlMLGFBQWFJLElBQWIsQ0FBa0JELE1BQWxCLENBQUosRUFBK0IsT0FBTyxDQUFDRyxXQUFXSCxNQUFYLEtBQXNCQSxNQUF2QixFQUErQkUsV0FBL0IsRUFBUDtBQUMvQixNQUFJSixTQUFTRyxJQUFULENBQWNELE1BQWQsQ0FBSixFQUEyQixPQUFPSSxXQUFXSixNQUFYLEVBQW1CRSxXQUFuQixFQUFQO0FBQzNCLFNBQU9GLE9BQU9FLFdBQVAsRUFBUDtBQUNELENBTEQ7QUFPQTs7Ozs7QUFJQSxJQUFJRyxvQkFBb0IsY0FBeEI7QUFFQTs7Ozs7OztBQU9BLFNBQVNGLFVBQVQsQ0FBb0JILE1BQXBCLEVBQTRCO0FBQzFCLFNBQU9BLE9BQU9NLE9BQVAsQ0FBZUQsaUJBQWYsRUFBa0MsVUFBVUUsQ0FBVixFQUFhQyxJQUFiLEVBQW1CO0FBQzFELFdBQU9BLE9BQU8sTUFBTUEsSUFBYixHQUFvQixFQUEzQjtBQUNELEdBRk0sQ0FBUDtBQUdEO0FBRUQ7Ozs7O0FBSUEsSUFBSUMsZ0JBQWdCLGNBQXBCO0FBRUE7Ozs7Ozs7QUFPQSxTQUFTTCxVQUFULENBQW9CSixNQUFwQixFQUE0QjtBQUMxQixTQUFPQSxPQUFPTSxPQUFQLENBQWVHLGFBQWYsRUFBOEIsVUFBVUYsQ0FBVixFQUFhRyxRQUFiLEVBQXVCQyxNQUF2QixFQUErQjtBQUNsRSxXQUFPRCxXQUFXLEdBQVgsR0FBaUJDLE9BQU9ULFdBQVAsR0FBcUJVLEtBQXJCLENBQTJCLEVBQTNCLEVBQStCQyxJQUEvQixDQUFvQyxHQUFwQyxDQUF4QjtBQUNELEdBRk0sQ0FBUDtBQUdEOztBQUVELEtBQUtDLFdBQUwsR0FBbUIsVUFBU2QsTUFBVCxFQUFpQjtBQUNsQyxTQUFPRCxTQUFTQyxNQUFULEVBQWlCTSxPQUFqQixDQUF5QixjQUF6QixFQUF5QyxVQUFVUyxPQUFWLEVBQW1CQyxLQUFuQixFQUEwQjtBQUN4RSxXQUFPQSxRQUFRLE1BQU1BLEtBQWQsR0FBc0IsRUFBN0I7QUFDRCxHQUZNLEVBRUpDLElBRkksRUFBUDtBQUdELENBSkQ7O0FBTUEsS0FBS0MsV0FBTCxHQUFtQixVQUFTbEIsTUFBVCxFQUFpQjtBQUNsQyxTQUFPYyxZQUFZZCxNQUFaLEVBQW9CTSxPQUFwQixDQUE0QixTQUE1QixFQUF1QyxVQUFVUyxPQUFWLEVBQW1CSSxNQUFuQixFQUEyQjtBQUN2RSxXQUFPQSxPQUFPQyxXQUFQLEVBQVA7QUFDRCxHQUZNLENBQVA7QUFHRCxDQUpEOztBQU1BLEtBQUtDLFdBQUwsR0FBbUIsVUFBU3JCLE1BQVQsRUFBaUI7QUFDbEMsU0FBT2MsWUFBWWQsTUFBWixFQUFvQk0sT0FBcEIsQ0FBNEIsS0FBNUIsRUFBbUMsR0FBbkMsQ0FBUDtBQUNELENBRkQ7O0FBSUEsS0FBS2dCLFdBQUwsR0FBbUIsVUFBU3RCLE1BQVQsRUFBaUI7QUFDbEMsU0FBT2MsWUFBWWQsTUFBWixFQUFvQk0sT0FBcEIsQ0FBNEIsS0FBNUIsRUFBbUMsR0FBbkMsQ0FBUDtBQUNELENBRkQ7O0FBSUEsS0FBS2lCLFdBQUwsR0FBbUIsVUFBU3ZCLE1BQVQsRUFBaUI7QUFDbEMsTUFBSXdCLE1BQU1WLFlBQVlkLE1BQVosRUFBb0JNLE9BQXBCLENBQTRCLFNBQTVCLEVBQXVDLFVBQVNTLE9BQVQsRUFBa0JJLE1BQWxCLEVBQTBCO0FBQ3pFLFdBQU8sTUFBTUEsT0FBT0MsV0FBUCxFQUFiO0FBQ0QsR0FGUyxDQUFWOztBQUlBLE1BQUdJLEdBQUgsRUFBUTtBQUNOQSxVQUFNQSxJQUFJQyxNQUFKLENBQVcsQ0FBWCxFQUFjTCxXQUFkLEtBQThCSSxJQUFJRSxLQUFKLENBQVUsQ0FBVixDQUFwQztBQUNEOztBQUNELFNBQU9GLEdBQVA7QUFDRCxDQVRELEM7Ozs7Ozs7Ozs7O0FDN0VBOzs7Ozs7O0FBUUEsS0FBS0csZ0JBQUwsR0FBd0IsVUFBU0MsWUFBVCxFQUF1QkMsR0FBdkIsRUFBNEI7QUFDbkQsTUFBSUMsUUFBUUYsYUFBYWhCLEtBQWIsQ0FBbUIsR0FBbkIsQ0FBWjtBQUNBLE1BQUltQixNQUFNRixHQUFWOztBQUNBLE9BQUksSUFBSUcsSUFBSSxDQUFaLEVBQWVBLElBQUlGLE1BQU1HLE1BQXpCLEVBQWlDRCxHQUFqQyxFQUFzQztBQUNyQ0QsVUFBTUEsSUFBSUQsTUFBTUUsQ0FBTixDQUFKLENBQU47O0FBQ0EsUUFBRyxPQUFPRCxHQUFQLElBQWMsV0FBakIsRUFBOEI7QUFDN0IsYUFBT0EsR0FBUDtBQUNBO0FBQ0Q7O0FBQ0QsU0FBT0EsR0FBUDtBQUNBLENBVkQ7QUFhQTs7Ozs7QUFJQSxLQUFLRyxNQUFMLEdBQWMsVUFBU0MsQ0FBVCxFQUFZO0FBQ3pCLE1BQUlDLEtBQUssRUFBVDtBQUFBLE1BQWFDLENBQWI7QUFBQSxNQUFnQkMsS0FBaEI7QUFBQSxNQUF1QkMsSUFBdkI7O0FBQ0EsT0FBSyxJQUFJQyxDQUFULElBQWNMLENBQWQsRUFBaUI7QUFDaEJFLFFBQUlELEVBQUo7QUFDQUUsWUFBUUUsRUFBRTVCLEtBQUYsQ0FBUSxHQUFSLENBQVI7QUFDQSxRQUFJNkIsTUFBTUgsTUFBTUksR0FBTixFQUFWOztBQUNBLFdBQU9KLE1BQU1MLE1BQWIsRUFBcUI7QUFDcEJNLGFBQU9ELE1BQU1LLEtBQU4sRUFBUDtBQUNBTixVQUFJQSxFQUFFRSxJQUFGLElBQVVGLEVBQUVFLElBQUYsS0FBVyxFQUF6QjtBQUNBOztBQUNERixNQUFFSSxHQUFGLElBQVNOLEVBQUVLLENBQUYsQ0FBVDtBQUNBOztBQUNELFNBQU9KLEVBQVA7QUFDQSxDQWJEO0FBZUE7Ozs7Ozs7O0FBT0EsS0FBS1Esb0JBQUwsR0FBNEIsVUFBU0MsSUFBVCxFQUFlQyxZQUFmLEVBQTZCQyxRQUE3QixFQUF1QztBQUNsRUYsU0FBT0EsUUFBUSxFQUFmO0FBQ0FFLGFBQVdBLFlBQVksS0FBdkI7QUFDQUQsaUJBQWVBLGdCQUFnQixFQUEvQjtBQUVBLE1BQUl0QixNQUFNLEVBQVYsQ0FMa0UsQ0FNbEU7O0FBQ0EsTUFBR3VCLFlBQVksTUFBZixFQUF1QjtBQUV0QixRQUFJQyxNQUFNLEVBQVY7O0FBQ0FDLE1BQUVDLElBQUYsQ0FBT0wsSUFBUCxFQUFhLFVBQVNNLEdBQVQsRUFBYztBQUMxQixVQUFJdEIsTUFBTSxFQUFWOztBQUNBb0IsUUFBRUMsSUFBRixDQUFPSixZQUFQLEVBQXFCLFVBQVNNLEtBQVQsRUFBZ0I7QUFDcEN2QixZQUFJdUIsS0FBSixJQUFhRCxJQUFJQyxLQUFKLENBQWI7QUFDQSxPQUZEOztBQUdBSixVQUFJSyxJQUFKLENBQVN4QixHQUFUO0FBQ0EsS0FORDs7QUFRQUwsVUFBTThCLEtBQUtDLFNBQUwsQ0FBZVAsR0FBZixDQUFOO0FBQ0EsR0FuQmlFLENBcUJsRTs7O0FBQ0EsTUFBR0QsWUFBWSxLQUFaLElBQXFCQSxZQUFZLEtBQXBDLEVBQTJDO0FBQzFDLFFBQUlTLGtCQUFrQixFQUF0Qjs7QUFDQSxRQUFHVCxZQUFZLEtBQWYsRUFBc0I7QUFDckJTLHdCQUFrQixHQUFsQjtBQUNBOztBQUNELFFBQUdULFlBQVksS0FBZixFQUFzQjtBQUNyQjtBQUNBUyx3QkFBa0JDLE9BQU9DLFlBQVAsQ0FBb0IsQ0FBcEIsQ0FBbEI7QUFDQTs7QUFFRFQsTUFBRUMsSUFBRixDQUFPSixZQUFQLEVBQXFCLFVBQVNNLEtBQVQsRUFBZ0JwQixDQUFoQixFQUFtQjtBQUN2QyxVQUFHQSxJQUFJLENBQVAsRUFBVTtBQUNUUixjQUFNQSxNQUFNZ0MsZUFBWjtBQUNBOztBQUNEaEMsWUFBTUEsTUFBTSxJQUFOLEdBQWE0QixLQUFiLEdBQXFCLElBQTNCO0FBQ0EsS0FMRCxFQVYwQyxDQWdCMUM7OztBQUNBNUIsVUFBTUEsTUFBTWlDLE9BQU9DLFlBQVAsQ0FBb0IsRUFBcEIsQ0FBTixHQUFnQyxJQUF0Qzs7QUFFQVQsTUFBRUMsSUFBRixDQUFPTCxJQUFQLEVBQWEsVUFBU00sR0FBVCxFQUFjO0FBQzFCRixRQUFFQyxJQUFGLENBQU9KLFlBQVAsRUFBcUIsVUFBU00sS0FBVCxFQUFnQnBCLENBQWhCLEVBQW1CO0FBQ3ZDLFlBQUdBLElBQUksQ0FBUCxFQUFVO0FBQ1RSLGdCQUFNQSxNQUFNZ0MsZUFBWjtBQUNBOztBQUVELFlBQUlHLFFBQVFoQyxpQkFBaUJ5QixLQUFqQixFQUF3QkQsR0FBeEIsSUFBK0IsRUFBM0M7QUFDQVEsZ0JBQVFBLE1BQU1yRCxPQUFOLENBQWMsSUFBZCxFQUFvQixJQUFwQixDQUFSO0FBQ0EsWUFBRyxPQUFPcUQsS0FBUCxJQUFpQixXQUFwQixFQUNDbkMsTUFBTUEsTUFBTSxNQUFaLENBREQsS0FHQ0EsTUFBTUEsTUFBTSxJQUFOLEdBQWFtQyxLQUFiLEdBQXFCLElBQTNCO0FBQ0QsT0FYRCxFQUQwQixDQWExQjs7O0FBQ0FuQyxZQUFNQSxNQUFNaUMsT0FBT0MsWUFBUCxDQUFvQixFQUFwQixDQUFOLEdBQWdDLElBQXRDO0FBQ0EsS0FmRDtBQWdCQTs7QUFFRCxTQUFPbEMsR0FBUDtBQUNBLENBNUREOztBQStEQSxLQUFLb0MsWUFBTCxHQUFvQixVQUFTQyxNQUFULEVBQWlCQyxNQUFqQixFQUF5QjtBQUU1Qzs7QUFHQSxNQUFHLE9BQU9ELE1BQVAsS0FBa0IsUUFBckIsRUFBK0I7QUFDOUJBLGFBQVMsRUFBVDtBQUNBOztBQUVELE9BQUksSUFBSUUsUUFBUixJQUFvQkQsTUFBcEIsRUFBNEI7QUFFM0IsUUFBR0EsT0FBT0UsY0FBUCxDQUFzQkQsUUFBdEIsQ0FBSCxFQUFvQztBQUVuQyxVQUFJRSxpQkFBaUJILE9BQVFDLFFBQVIsQ0FBckI7O0FBRUEsVUFBRyxPQUFPRSxjQUFQLEtBQTBCLFFBQTdCLEVBQXVDO0FBQ3RDSixlQUFPRSxRQUFQLElBQW1CSCxhQUFhQyxPQUFPRSxRQUFQLENBQWIsRUFBK0JFLGNBQS9CLENBQW5CO0FBQ0E7QUFDQTs7QUFFREosYUFBT0UsUUFBUCxJQUFtQkUsY0FBbkI7QUFDQTtBQUNEOztBQUVELE9BQUksSUFBSUMsSUFBSSxDQUFSLEVBQVdDLElBQUlDLFVBQVVuQyxNQUE3QixFQUFxQ2lDLElBQUlDLENBQXpDLEVBQTRDRCxHQUE1QyxFQUFpRDtBQUNoRE4saUJBQWFDLE1BQWIsRUFBcUJPLFVBQVVGLENBQVYsQ0FBckI7QUFDQTs7QUFFRCxTQUFPTCxNQUFQO0FBQ0EsQ0E3QkQsQzs7Ozs7Ozs7Ozs7QUM5R0EsS0FBS1EsV0FBTCxHQUFtQixVQUFVckUsTUFBVixFQUFrQjtBQUNwQyxTQUFPQSxPQUFPTSxPQUFQLENBQWUsNkJBQWYsRUFBOEMsTUFBOUMsQ0FBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS2dFLGlCQUFMLEdBQXlCLFVBQVN0RSxNQUFULEVBQWlCdUUsSUFBakIsRUFBdUJqRSxPQUF2QixFQUFnQztBQUN4RCxTQUFPTixPQUFPTSxPQUFQLENBQWUsSUFBSWtFLE1BQUosQ0FBV0gsWUFBWUUsSUFBWixDQUFYLEVBQThCLEdBQTlCLENBQWYsRUFBbURqRSxPQUFuRCxDQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLbUUsV0FBTCxHQUFtQixVQUFTQyxXQUFULEVBQXNCN0QsSUFBdEIsRUFBNEI7QUFDOUMsTUFBSThELE1BQU05RCxRQUFRLElBQWxCO0FBQ0EsTUFBSWtCLE1BQU0sRUFBVjs7QUFDQWtCLElBQUVDLElBQUYsQ0FBT3dCLFdBQVAsRUFBb0IsVUFBU2xELEdBQVQsRUFBYztBQUNqQyxRQUFHQSxHQUFILEVBQVE7QUFDUCxVQUFHTyxHQUFILEVBQ0NBLE1BQU1BLE1BQU00QyxHQUFaO0FBQ0Q1QyxZQUFNQSxNQUFNUCxHQUFaO0FBQ0E7QUFDRCxHQU5EOztBQU9BLFNBQU9PLEdBQVA7QUFDQSxDQVhEOztBQWFBLEtBQUs2QyxhQUFMLEdBQXFCLFVBQVNDLElBQVQsRUFBZTtBQUNsQyxTQUFPQSxLQUFLQyxRQUFMLEdBQWdCNUUsV0FBaEIsR0FDSkksT0FESSxDQUNJLE1BREosRUFDWSxHQURaLEVBQzJCO0FBRDNCLEdBRUpBLE9BRkksQ0FFSSxXQUZKLEVBRWlCLEVBRmpCLEVBRTJCO0FBRjNCLEdBR0pBLE9BSEksQ0FHSSxRQUhKLEVBR2MsR0FIZCxFQUcyQjtBQUgzQixHQUlKQSxPQUpJLENBSUksS0FKSixFQUlXLEVBSlgsRUFJMkI7QUFKM0IsR0FLSkEsT0FMSSxDQUtJLEtBTEosRUFLVyxFQUxYLENBQVAsQ0FEa0MsQ0FNQTtBQUNuQyxDQVBELEM7Ozs7Ozs7Ozs7O0FDckJBOzs7QUFJQXlFLE9BQU9DLFVBQVAsR0FBb0I7QUFDaEJDLFdBQVMsVUFBVUMsR0FBVixFQUFlQyxJQUFmLEVBQXNCO0FBQzNCLFFBQUlDLElBQUlGLE1BQU0sRUFBZDs7QUFDQSxXQUFRRSxFQUFFbkQsTUFBRixHQUFXa0QsSUFBbkIsRUFDSUMsSUFBSSxNQUFNQSxDQUFWOztBQUNKLFdBQU9BLENBQVA7QUFDSDtBQU5lLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDSEE7OztBQUlBQyxnQkFBZ0IsRUFBaEI7QUFFQUMsS0FBS0MsV0FBTCxDQUFpQixJQUFqQjtBQUVBUixPQUFPUyxRQUFQLElBQW1CQyxTQUFTQyxjQUFULENBQXdCLGVBQXhCLEVBQXlDTCxhQUF6QyxDQUFuQixDOzs7Ozs7Ozs7OztBQ1JBLEtBQUtNLFlBQUwsR0FBb0IsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixnQkFBckIsQ0FBcEI7O0FBRUEsS0FBS0YsWUFBTCxDQUFrQkcsYUFBbEIsR0FBa0MsVUFBU0MsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3ZELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS3dDLFlBQUwsQ0FBa0JLLGFBQWxCLEdBQWtDLFVBQVNELE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUN2RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUt3QyxZQUFMLENBQWtCTSxhQUFsQixHQUFrQyxVQUFTRixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDdkQsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUsrQyxhQUFMLEdBQXFCLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsaUJBQXJCLENBQXJCOztBQUVBLEtBQUtLLGFBQUwsQ0FBbUJKLGFBQW5CLEdBQW1DLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUN4RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUsrQyxhQUFMLENBQW1CRixhQUFuQixHQUFtQyxVQUFTRCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDeEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLK0MsYUFBTCxDQUFtQkQsYUFBbkIsR0FBbUMsVUFBU0YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3hELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNYQSxLQUFLZ0QsZ0JBQUwsR0FBd0IsSUFBSVAsTUFBTUMsVUFBVixDQUFxQixtQkFBckIsQ0FBeEI7O0FBRUEsS0FBS00sZ0JBQUwsQ0FBc0JMLGFBQXRCLEdBQXNDLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUMzRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtnRCxnQkFBTCxDQUFzQkgsYUFBdEIsR0FBc0MsVUFBU0QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzNELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS2dELGdCQUFMLENBQXNCRixhQUF0QixHQUFzQyxVQUFTRixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDM0QsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUtpRCxtQkFBTCxHQUEyQixJQUFJUixNQUFNQyxVQUFWLENBQXFCLHNCQUFyQixDQUEzQjs7QUFFQSxLQUFLTyxtQkFBTCxDQUF5Qk4sYUFBekIsR0FBeUMsVUFBU0MsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzlELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS2lELG1CQUFMLENBQXlCSixhQUF6QixHQUF5QyxVQUFTRCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDOUQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLaUQsbUJBQUwsQ0FBeUJILGFBQXpCLEdBQXlDLFVBQVNGLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUM5RCxTQUFPLElBQVA7QUFDQSxDQUZELEM7Ozs7Ozs7Ozs7O0FDVkEsS0FBS2tELGlCQUFMLEdBQXlCLElBQUlULE1BQU1DLFVBQVYsQ0FBcUIsb0JBQXJCLENBQXpCOztBQUVBLEtBQUtRLGlCQUFMLENBQXVCUCxhQUF2QixHQUF1QyxVQUFTQyxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDNUQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLa0QsaUJBQUwsQ0FBdUJMLGFBQXZCLEdBQXVDLFVBQVNELE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUM1RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtrRCxpQkFBTCxDQUF1QkosYUFBdkIsR0FBdUMsVUFBU0YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzVELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLbUQsa0JBQUwsR0FBMEIsSUFBSVYsTUFBTUMsVUFBVixDQUFxQixxQkFBckIsQ0FBMUI7O0FBRUEsS0FBS1Msa0JBQUwsQ0FBd0JSLGFBQXhCLEdBQXdDLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUM3RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUttRCxrQkFBTCxDQUF3Qk4sYUFBeEIsR0FBd0MsVUFBU0QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzdELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS21ELGtCQUFMLENBQXdCTCxhQUF4QixHQUF3QyxVQUFTRixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDN0QsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUtvRCxhQUFMLEdBQXFCLElBQUlYLE1BQU1DLFVBQVYsQ0FBcUIsZ0JBQXJCLENBQXJCOztBQUVBLEtBQUtVLGFBQUwsQ0FBbUJULGFBQW5CLEdBQW1DLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUN4RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtvRCxhQUFMLENBQW1CUCxhQUFuQixHQUFtQyxVQUFTRCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDeEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLb0QsYUFBTCxDQUFtQk4sYUFBbkIsR0FBbUMsVUFBU0YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3hELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLcUQsVUFBTCxHQUFrQixJQUFJWixNQUFNQyxVQUFWLENBQXFCLGFBQXJCLENBQWxCOztBQUVBLEtBQUtXLFVBQUwsQ0FBZ0JWLGFBQWhCLEdBQWdDLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUNyRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtxRCxVQUFMLENBQWdCUixhQUFoQixHQUFnQyxVQUFTRCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDckQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLcUQsVUFBTCxDQUFnQlAsYUFBaEIsR0FBZ0MsVUFBU0YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3JELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLc0Qsa0JBQUwsR0FBMEIsSUFBSWIsTUFBTUMsVUFBVixDQUFxQixxQkFBckIsQ0FBMUI7O0FBRUEsS0FBS1ksa0JBQUwsQ0FBd0JYLGFBQXhCLEdBQXdDLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUM3RCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUtzRCxrQkFBTCxDQUF3QlQsYUFBeEIsR0FBd0MsVUFBU0QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzdELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS3NELGtCQUFMLENBQXdCUixhQUF4QixHQUF3QyxVQUFTRixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDN0QsU0FBTyxJQUFQO0FBQ0EsQ0FGRCxDOzs7Ozs7Ozs7OztBQ1ZBLEtBQUt1RCxlQUFMLEdBQXVCLElBQUlkLE1BQU1DLFVBQVYsQ0FBcUIsa0JBQXJCLENBQXZCOztBQUVBLEtBQUthLGVBQUwsQ0FBcUJaLGFBQXJCLEdBQXFDLFVBQVNDLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUMxRCxTQUFPLElBQVA7QUFDQSxDQUZEOztBQUlBLEtBQUt1RCxlQUFMLENBQXFCVixhQUFyQixHQUFxQyxVQUFTRCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDMUQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLdUQsZUFBTCxDQUFxQlQsYUFBckIsR0FBcUMsVUFBU0YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzFELFNBQU8sSUFBUDtBQUNBLENBRkQsQzs7Ozs7Ozs7Ozs7QUNWQSxLQUFLd0QsYUFBTCxHQUFxQixJQUFJZixNQUFNQyxVQUFWLENBQXFCLGdCQUFyQixDQUFyQjs7QUFFQSxLQUFLYyxhQUFMLENBQW1CYixhQUFuQixHQUFtQyxVQUFTQyxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDeEQsU0FBTyxJQUFQO0FBQ0EsQ0FGRDs7QUFJQSxLQUFLd0QsYUFBTCxDQUFtQlgsYUFBbkIsR0FBbUMsVUFBU0QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3hELFNBQU8sSUFBUDtBQUNBLENBRkQ7O0FBSUEsS0FBS3dELGFBQUwsQ0FBbUJWLGFBQW5CLEdBQW1DLFVBQVNGLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUN4RCxTQUFPLElBQVA7QUFDQSxDQUZELEM7Ozs7Ozs7Ozs7O0FDVEE7Ozs7Ozs7QUFRQXdDLGFBQWFpQixLQUFiLENBQW1CO0FBQ2ZDLFVBQVEsVUFBVWQsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzNCLFdBQU8sS0FBUDtBQUNILEdBSGM7QUFJZjJELFVBQVEsVUFBVWYsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCNEQsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQzdDLFdBQU8sS0FBUDtBQUNILEdBTmM7QUFPZkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzNCLFdBQU8sS0FBUDtBQUNIO0FBVGMsQ0FBbkI7QUFZQXdDLGFBQWF1QixNQUFiLENBQW9CTCxNQUFwQixDQUEyQixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDN0NBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUNBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUN0QixDQU5EO0FBUUFKLGFBQWF1QixNQUFiLENBQW9CSixNQUFwQixDQUEyQixVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQzVFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBQ0gsQ0FKRDtBQU1BSixhQUFhdUIsTUFBYixDQUFvQlMsTUFBcEIsQ0FBMkIsVUFBUzVCLE1BQVQsRUFBaUI2QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQ3JFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBQ0gsQ0FKRDtBQU1BSixhQUFhdUIsTUFBYixDQUFvQkQsTUFBcEIsQ0FBMkIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQW5EO0FBRUF3QyxhQUFha0MsS0FBYixDQUFtQmhCLE1BQW5CLENBQTBCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQWxEO0FBRUF3QyxhQUFha0MsS0FBYixDQUFtQmYsTUFBbkIsQ0FBMEIsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUFFLENBQWpGO0FBRUE5QixhQUFha0MsS0FBYixDQUFtQlosTUFBbkIsQ0FBMEIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQWxELEU7Ozs7Ozs7Ozs7O0FDOUNBOzs7Ozs7O0FBUUErQyxjQUFjVSxLQUFkLENBQW9CO0FBQ2hCQyxVQUFRLFVBQVVkLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjtBQUMzQixXQUFPLEtBQVA7QUFDSCxHQUhlO0FBSWhCMkQsVUFBUSxVQUFVZixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI0RCxNQUF2QixFQUErQkMsUUFBL0IsRUFBeUM7QUFDN0MsV0FBTyxLQUFQO0FBQ0gsR0FOZTtBQU9oQkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzNCLFdBQU8sS0FBUDtBQUNIO0FBVGUsQ0FBcEI7QUFZQStDLGNBQWNnQixNQUFkLENBQXFCTCxNQUFyQixDQUE0QixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDOUNBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUNBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUN0QixDQU5EO0FBUUFHLGNBQWNnQixNQUFkLENBQXFCSixNQUFyQixDQUE0QixVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQzdFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBQ0gsQ0FKRDtBQU1BRyxjQUFjZ0IsTUFBZCxDQUFxQlMsTUFBckIsQ0FBNEIsVUFBUzVCLE1BQVQsRUFBaUI2QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQ3RFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBQ0gsQ0FKRDtBQU1BRyxjQUFjZ0IsTUFBZCxDQUFxQkQsTUFBckIsQ0FBNEIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQXBEO0FBRUErQyxjQUFjMkIsS0FBZCxDQUFvQmhCLE1BQXBCLENBQTJCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQW5EO0FBRUErQyxjQUFjMkIsS0FBZCxDQUFvQmYsTUFBcEIsQ0FBMkIsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUFFLENBQWxGO0FBRUF2QixjQUFjMkIsS0FBZCxDQUFvQlosTUFBcEIsQ0FBMkIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUFFLENBQW5ELEU7Ozs7Ozs7Ozs7O0FDL0NBZ0QsaUJBQWlCUyxLQUFqQixDQUF1QjtBQUN0QkMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIcUI7QUFLdEIyRCxVQUFRLFVBQVVmLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjRELE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBxQjtBQVN0QkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWHFCLENBQXZCO0FBY0FnRCxpQkFBaUJlLE1BQWpCLENBQXdCTCxNQUF4QixDQUErQixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDcERBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUdBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNuQixDQVJEO0FBVUFJLGlCQUFpQmUsTUFBakIsQ0FBd0JKLE1BQXhCLENBQStCLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDbkZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFHQSxDQU5EO0FBUUFJLGlCQUFpQmUsTUFBakIsQ0FBd0JTLE1BQXhCLENBQStCLFVBQVM1QixNQUFULEVBQWlCNkIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUM1RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBSSxpQkFBaUJlLE1BQWpCLENBQXdCRCxNQUF4QixDQUErQixVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXBELENBRkQ7QUFJQWdELGlCQUFpQjBCLEtBQWpCLENBQXVCaEIsTUFBdkIsQ0FBOEIsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRW5ELENBRkQ7QUFJQWdELGlCQUFpQjBCLEtBQWpCLENBQXVCZixNQUF2QixDQUE4QixVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRWxGLENBRkQ7QUFJQXRCLGlCQUFpQjBCLEtBQWpCLENBQXVCWixNQUF2QixDQUE4QixVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRW5ELENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREFpRCxvQkFBb0JRLEtBQXBCLENBQTBCO0FBQ3pCQyxVQUFRLFVBQVVkLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQUh3QjtBQUt6QjJELFVBQVEsVUFBVWYsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCNEQsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUHdCO0FBU3pCQyxVQUFRLFVBQVVsQixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYd0IsQ0FBMUI7QUFjQWlELG9CQUFvQmMsTUFBcEIsQ0FBMkJMLE1BQTNCLENBQWtDLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUN2REEsTUFBSWdFLFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBakUsTUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNBNUMsTUFBSW1FLFVBQUosR0FBaUJuRSxJQUFJZ0UsU0FBckI7QUFDQWhFLE1BQUlvRSxVQUFKLEdBQWlCcEUsSUFBSWtFLFNBQXJCO0FBR0EsTUFBRyxDQUFDbEUsSUFBSWtFLFNBQVIsRUFBbUJsRSxJQUFJa0UsU0FBSixHQUFnQnRCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQUssb0JBQW9CYyxNQUFwQixDQUEyQkosTUFBM0IsQ0FBa0MsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUN0RlQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUdBLENBTkQ7QUFRQUssb0JBQW9CYyxNQUFwQixDQUEyQlMsTUFBM0IsQ0FBa0MsVUFBUzVCLE1BQVQsRUFBaUI2QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQy9FVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBRUE7QUFDQSxDQU5EO0FBUUFLLG9CQUFvQmMsTUFBcEIsQ0FBMkJELE1BQTNCLENBQWtDLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFdkQsQ0FGRDtBQUlBaUQsb0JBQW9CeUIsS0FBcEIsQ0FBMEJoQixNQUExQixDQUFpQyxVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFdEQsQ0FGRDtBQUlBaUQsb0JBQW9CeUIsS0FBcEIsQ0FBMEJmLE1BQTFCLENBQWlDLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFckYsQ0FGRDtBQUlBckIsb0JBQW9CeUIsS0FBcEIsQ0FBMEJaLE1BQTFCLENBQWlDLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFdEQsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQWtELGtCQUFrQk8sS0FBbEIsQ0FBd0I7QUFDdkJDLFVBQVEsVUFBVWQsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBLEdBSHNCO0FBS3ZCMkQsVUFBUSxVQUFVZixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI0RCxNQUF2QixFQUErQkMsUUFBL0IsRUFBeUM7QUFDaEQsV0FBTyxLQUFQO0FBQ0EsR0FQc0I7QUFTdkJDLFVBQVEsVUFBVWxCLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQTtBQVhzQixDQUF4QjtBQWNBa0Qsa0JBQWtCYSxNQUFsQixDQUF5QkwsTUFBekIsQ0FBZ0MsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3JEQSxNQUFJZ0UsU0FBSixHQUFnQixJQUFJQyxJQUFKLEVBQWhCO0FBQ0FqRSxNQUFJa0UsU0FBSixHQUFnQnRCLE1BQWhCO0FBQ0E1QyxNQUFJbUUsVUFBSixHQUFpQm5FLElBQUlnRSxTQUFyQjtBQUNBaEUsTUFBSW9FLFVBQUosR0FBaUJwRSxJQUFJa0UsU0FBckI7QUFHQSxNQUFHLENBQUNsRSxJQUFJa0UsU0FBUixFQUFtQmxFLElBQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDbkIsQ0FSRDtBQVVBTSxrQkFBa0JhLE1BQWxCLENBQXlCSixNQUF6QixDQUFnQyxVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQ3BGVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBR0EsQ0FORDtBQVFBTSxrQkFBa0JhLE1BQWxCLENBQXlCUyxNQUF6QixDQUFnQyxVQUFTNUIsTUFBVCxFQUFpQjZCLFFBQWpCLEVBQTJCWixRQUEzQixFQUFxQ1MsT0FBckMsRUFBOEM7QUFDN0VULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFFQTtBQUNBLENBTkQ7QUFRQU0sa0JBQWtCYSxNQUFsQixDQUF5QkQsTUFBekIsQ0FBZ0MsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUVyRCxDQUZEO0FBSUFrRCxrQkFBa0J3QixLQUFsQixDQUF3QmhCLE1BQXhCLENBQStCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUVwRCxDQUZEO0FBSUFrRCxrQkFBa0J3QixLQUFsQixDQUF3QmYsTUFBeEIsQ0FBK0IsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUVuRixDQUZEO0FBSUFwQixrQkFBa0J3QixLQUFsQixDQUF3QlosTUFBeEIsQ0FBK0IsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUVwRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBbUQsbUJBQW1CTSxLQUFuQixDQUF5QjtBQUN4QkMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIdUI7QUFLeEIyRCxVQUFRLFVBQVVmLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjRELE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVB1QjtBQVN4QkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWHVCLENBQXpCO0FBY0FtRCxtQkFBbUJZLE1BQW5CLENBQTBCTCxNQUExQixDQUFpQyxVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDdERBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUdBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNuQixDQVJEO0FBVUFPLG1CQUFtQlksTUFBbkIsQ0FBMEJKLE1BQTFCLENBQWlDLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDckZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFHQSxDQU5EO0FBUUFPLG1CQUFtQlksTUFBbkIsQ0FBMEJTLE1BQTFCLENBQWlDLFVBQVM1QixNQUFULEVBQWlCNkIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUM5RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBTyxtQkFBbUJZLE1BQW5CLENBQTBCRCxNQUExQixDQUFpQyxVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXRELENBRkQ7QUFJQW1ELG1CQUFtQnVCLEtBQW5CLENBQXlCaEIsTUFBekIsQ0FBZ0MsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXJELENBRkQ7QUFJQW1ELG1CQUFtQnVCLEtBQW5CLENBQXlCZixNQUF6QixDQUFnQyxVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRXBGLENBRkQ7QUFJQW5CLG1CQUFtQnVCLEtBQW5CLENBQXlCWixNQUF6QixDQUFnQyxVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXJELENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREFvRCxjQUFjSyxLQUFkLENBQW9CO0FBQ25CQyxVQUFRLFVBQVVkLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQUhrQjtBQUtuQjJELFVBQVEsVUFBVWYsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCNEQsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUGtCO0FBU25CQyxVQUFRLFVBQVVsQixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYa0IsQ0FBcEI7QUFjQW9ELGNBQWNXLE1BQWQsQ0FBcUJMLE1BQXJCLENBQTRCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUNqREEsTUFBSWdFLFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBakUsTUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNBNUMsTUFBSW1FLFVBQUosR0FBaUJuRSxJQUFJZ0UsU0FBckI7QUFDQWhFLE1BQUlvRSxVQUFKLEdBQWlCcEUsSUFBSWtFLFNBQXJCO0FBR0EsTUFBRyxDQUFDbEUsSUFBSWtFLFNBQVIsRUFBbUJsRSxJQUFJa0UsU0FBSixHQUFnQnRCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQVEsY0FBY1csTUFBZCxDQUFxQkosTUFBckIsQ0FBNEIsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUNoRlQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUdBLENBTkQ7QUFRQVEsY0FBY1csTUFBZCxDQUFxQlMsTUFBckIsQ0FBNEIsVUFBUzVCLE1BQVQsRUFBaUI2QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQ3pFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBRUE7QUFDQSxDQU5EO0FBUUFRLGNBQWNXLE1BQWQsQ0FBcUJELE1BQXJCLENBQTRCLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFakQsQ0FGRDtBQUlBb0QsY0FBY3NCLEtBQWQsQ0FBb0JoQixNQUFwQixDQUEyQixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFaEQsQ0FGRDtBQUlBb0QsY0FBY3NCLEtBQWQsQ0FBb0JmLE1BQXBCLENBQTJCLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFL0UsQ0FGRDtBQUlBbEIsY0FBY3NCLEtBQWQsQ0FBb0JaLE1BQXBCLENBQTJCLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFaEQsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQXFELFdBQVdJLEtBQVgsQ0FBaUI7QUFDaEJDLFVBQVEsVUFBVWQsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBLEdBSGU7QUFLaEIyRCxVQUFRLFVBQVVmLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjRELE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBlO0FBU2hCQyxVQUFRLFVBQVVsQixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYZSxDQUFqQjtBQWNBcUQsV0FBV1UsTUFBWCxDQUFrQkwsTUFBbEIsQ0FBeUIsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQzlDQSxNQUFJZ0UsU0FBSixHQUFnQixJQUFJQyxJQUFKLEVBQWhCO0FBQ0FqRSxNQUFJa0UsU0FBSixHQUFnQnRCLE1BQWhCO0FBQ0E1QyxNQUFJbUUsVUFBSixHQUFpQm5FLElBQUlnRSxTQUFyQjtBQUNBaEUsTUFBSW9FLFVBQUosR0FBaUJwRSxJQUFJa0UsU0FBckI7QUFHQSxNQUFHLENBQUNsRSxJQUFJa0UsU0FBUixFQUFtQmxFLElBQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDbkIsQ0FSRDtBQVVBUyxXQUFXVSxNQUFYLENBQWtCSixNQUFsQixDQUF5QixVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFEO0FBQzdFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBR0EsQ0FORDtBQVFBUyxXQUFXVSxNQUFYLENBQWtCUyxNQUFsQixDQUF5QixVQUFTNUIsTUFBVCxFQUFpQjZCLFFBQWpCLEVBQTJCWixRQUEzQixFQUFxQ1MsT0FBckMsRUFBOEM7QUFDdEVULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFFQTtBQUNBLENBTkQ7QUFRQVMsV0FBV1UsTUFBWCxDQUFrQkQsTUFBbEIsQ0FBeUIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUU5QyxDQUZEO0FBSUFxRCxXQUFXcUIsS0FBWCxDQUFpQmhCLE1BQWpCLENBQXdCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUU3QyxDQUZEO0FBSUFxRCxXQUFXcUIsS0FBWCxDQUFpQmYsTUFBakIsQ0FBd0IsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRCxDQUU1RSxDQUZEO0FBSUFqQixXQUFXcUIsS0FBWCxDQUFpQlosTUFBakIsQ0FBd0IsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUU3QyxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBc0QsbUJBQW1CRyxLQUFuQixDQUF5QjtBQUN4QkMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIdUI7QUFLeEIyRCxVQUFRLFVBQVVmLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjRELE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVB1QjtBQVN4QkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWHVCLENBQXpCO0FBY0FzRCxtQkFBbUJTLE1BQW5CLENBQTBCTCxNQUExQixDQUFpQyxVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDdERBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUdBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNuQixDQVJEO0FBVUFVLG1CQUFtQlMsTUFBbkIsQ0FBMEJKLE1BQTFCLENBQWlDLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDckZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFHQSxDQU5EO0FBUUFVLG1CQUFtQlMsTUFBbkIsQ0FBMEJTLE1BQTFCLENBQWlDLFVBQVM1QixNQUFULEVBQWlCNkIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUM5RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBVSxtQkFBbUJTLE1BQW5CLENBQTBCRCxNQUExQixDQUFpQyxVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXRELENBRkQ7QUFJQXNELG1CQUFtQm9CLEtBQW5CLENBQXlCaEIsTUFBekIsQ0FBZ0MsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXJELENBRkQ7QUFJQXNELG1CQUFtQm9CLEtBQW5CLENBQXlCZixNQUF6QixDQUFnQyxVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRXBGLENBRkQ7QUFJQWhCLG1CQUFtQm9CLEtBQW5CLENBQXlCWixNQUF6QixDQUFnQyxVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRXJELENBRkQsRTs7Ozs7Ozs7Ozs7QUNwREF1RCxnQkFBZ0JFLEtBQWhCLENBQXNCO0FBQ3JCQyxVQUFRLFVBQVVkLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjtBQUM5QixXQUFPLEtBQVA7QUFDQSxHQUhvQjtBQUtyQjJELFVBQVEsVUFBVWYsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCNEQsTUFBdkIsRUFBK0JDLFFBQS9CLEVBQXlDO0FBQ2hELFdBQU8sS0FBUDtBQUNBLEdBUG9CO0FBU3JCQyxVQUFRLFVBQVVsQixNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0E7QUFYb0IsQ0FBdEI7QUFjQXVELGdCQUFnQlEsTUFBaEIsQ0FBdUJMLE1BQXZCLENBQThCLFVBQVNkLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQjtBQUNuREEsTUFBSWdFLFNBQUosR0FBZ0IsSUFBSUMsSUFBSixFQUFoQjtBQUNBakUsTUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNBNUMsTUFBSW1FLFVBQUosR0FBaUJuRSxJQUFJZ0UsU0FBckI7QUFDQWhFLE1BQUlvRSxVQUFKLEdBQWlCcEUsSUFBSWtFLFNBQXJCO0FBR0EsTUFBRyxDQUFDbEUsSUFBSWtFLFNBQVIsRUFBbUJsRSxJQUFJa0UsU0FBSixHQUFnQnRCLE1BQWhCO0FBQ25CLENBUkQ7QUFVQVcsZ0JBQWdCUSxNQUFoQixDQUF1QkosTUFBdkIsQ0FBOEIsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUNsRlQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUdBLENBTkQ7QUFRQVcsZ0JBQWdCUSxNQUFoQixDQUF1QlMsTUFBdkIsQ0FBOEIsVUFBUzVCLE1BQVQsRUFBaUI2QixRQUFqQixFQUEyQlosUUFBM0IsRUFBcUNTLE9BQXJDLEVBQThDO0FBQzNFVCxXQUFTVSxJQUFULEdBQWdCVixTQUFTVSxJQUFULElBQWlCLEVBQWpDO0FBQ0FWLFdBQVNVLElBQVQsQ0FBY0osVUFBZCxHQUEyQixJQUFJRixJQUFKLEVBQTNCO0FBQ0FKLFdBQVNVLElBQVQsQ0FBY0gsVUFBZCxHQUEyQnhCLE1BQTNCO0FBRUE7QUFDQSxDQU5EO0FBUUFXLGdCQUFnQlEsTUFBaEIsQ0FBdUJELE1BQXZCLENBQThCLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFbkQsQ0FGRDtBQUlBdUQsZ0JBQWdCbUIsS0FBaEIsQ0FBc0JoQixNQUF0QixDQUE2QixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFbEQsQ0FGRDtBQUlBdUQsZ0JBQWdCbUIsS0FBaEIsQ0FBc0JmLE1BQXRCLENBQTZCLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQsQ0FFakYsQ0FGRDtBQUlBZixnQkFBZ0JtQixLQUFoQixDQUFzQlosTUFBdEIsQ0FBNkIsVUFBU2xCLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQixDQUVsRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDcERBd0QsY0FBY0MsS0FBZCxDQUFvQjtBQUNuQkMsVUFBUSxVQUFVZCxNQUFWLEVBQWtCNUMsR0FBbEIsRUFBdUI7QUFDOUIsV0FBTyxLQUFQO0FBQ0EsR0FIa0I7QUFLbkIyRCxVQUFRLFVBQVVmLE1BQVYsRUFBa0I1QyxHQUFsQixFQUF1QjRELE1BQXZCLEVBQStCQyxRQUEvQixFQUF5QztBQUNoRCxXQUFPLEtBQVA7QUFDQSxHQVBrQjtBQVNuQkMsVUFBUSxVQUFVbEIsTUFBVixFQUFrQjVDLEdBQWxCLEVBQXVCO0FBQzlCLFdBQU8sS0FBUDtBQUNBO0FBWGtCLENBQXBCO0FBY0F3RCxjQUFjTyxNQUFkLENBQXFCTCxNQUFyQixDQUE0QixVQUFTZCxNQUFULEVBQWlCNUMsR0FBakIsRUFBc0I7QUFDakRBLE1BQUlnRSxTQUFKLEdBQWdCLElBQUlDLElBQUosRUFBaEI7QUFDQWpFLE1BQUlrRSxTQUFKLEdBQWdCdEIsTUFBaEI7QUFDQTVDLE1BQUltRSxVQUFKLEdBQWlCbkUsSUFBSWdFLFNBQXJCO0FBQ0FoRSxNQUFJb0UsVUFBSixHQUFpQnBFLElBQUlrRSxTQUFyQjtBQUdBLE1BQUcsQ0FBQ2xFLElBQUlrRSxTQUFSLEVBQW1CbEUsSUFBSWtFLFNBQUosR0FBZ0J0QixNQUFoQjtBQUNuQixDQVJEO0FBVUFZLGNBQWNPLE1BQWQsQ0FBcUJKLE1BQXJCLENBQTRCLFVBQVNmLE1BQVQsRUFBaUI1QyxHQUFqQixFQUFzQnFFLFVBQXRCLEVBQWtDUixRQUFsQyxFQUE0Q1MsT0FBNUMsRUFBcUQ7QUFDaEZULFdBQVNVLElBQVQsR0FBZ0JWLFNBQVNVLElBQVQsSUFBaUIsRUFBakM7QUFDQVYsV0FBU1UsSUFBVCxDQUFjSixVQUFkLEdBQTJCLElBQUlGLElBQUosRUFBM0I7QUFDQUosV0FBU1UsSUFBVCxDQUFjSCxVQUFkLEdBQTJCeEIsTUFBM0I7QUFHQSxDQU5EO0FBUUFZLGNBQWNPLE1BQWQsQ0FBcUJTLE1BQXJCLENBQTRCLFVBQVM1QixNQUFULEVBQWlCNkIsUUFBakIsRUFBMkJaLFFBQTNCLEVBQXFDUyxPQUFyQyxFQUE4QztBQUN6RVQsV0FBU1UsSUFBVCxHQUFnQlYsU0FBU1UsSUFBVCxJQUFpQixFQUFqQztBQUNBVixXQUFTVSxJQUFULENBQWNKLFVBQWQsR0FBMkIsSUFBSUYsSUFBSixFQUEzQjtBQUNBSixXQUFTVSxJQUFULENBQWNILFVBQWQsR0FBMkJ4QixNQUEzQjtBQUVBO0FBQ0EsQ0FORDtBQVFBWSxjQUFjTyxNQUFkLENBQXFCRCxNQUFyQixDQUE0QixVQUFTbEIsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRWpELENBRkQ7QUFJQXdELGNBQWNrQixLQUFkLENBQW9CaEIsTUFBcEIsQ0FBMkIsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCLENBRWhELENBRkQ7QUFJQXdELGNBQWNrQixLQUFkLENBQW9CZixNQUFwQixDQUEyQixVQUFTZixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0JxRSxVQUF0QixFQUFrQ1IsUUFBbEMsRUFBNENTLE9BQTVDLEVBQXFELENBRS9FLENBRkQ7QUFJQWQsY0FBY2tCLEtBQWQsQ0FBb0JaLE1BQXBCLENBQTJCLFVBQVNsQixNQUFULEVBQWlCNUMsR0FBakIsRUFBc0IsQ0FFaEQsQ0FGRCxFOzs7Ozs7Ozs7OztBQ3BEQTJFLE9BQU9DLEdBQVAsQ0FBVyxZQUFZLENBRXRCLENBRkQsRTs7Ozs7Ozs7Ozs7QUNDQTs7Ozs7OztBQVFBaEQsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLHdCQUFzQixVQUFTbkYsSUFBVCxFQUFlO0FBQ3BDb0YsVUFBTXBGLElBQU4sRUFBWTtBQUNYcUYsYUFBT3pFLE1BREk7QUFFWDBFLGFBQU8xRSxNQUZJO0FBR1gyRSxXQUFLM0UsTUFITTtBQUlYNEUsWUFBTTVFLE1BSks7QUFLWDZFLGNBQVFDO0FBTEcsS0FBWjs7QUFPQSxRQUFHLENBQUM1QyxhQUFhRyxhQUFiLENBQTJCLEtBQUtDLE1BQWhDLEVBQXdDbEQsSUFBeEMsQ0FBSixFQUFtRDtBQUN6QyxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ1QsS0FGRCxNQUVPO0FBQ04sVUFBSTtBQUNILGVBQU83QyxhQUFha0IsTUFBYixDQUFvQmhFLElBQXBCLENBQVA7QUFDQSxPQUZELENBRUUsT0FBTzRGLFNBQVAsRUFBa0I7QUFDbkIsY0FBTSxJQUFJMUQsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsS0FBS0MsU0FBM0IsQ0FBTjtBQUNBO0FBQ0Q7QUFDRCxHQWxCYTtBQW1CZCx3QkFBc0IsVUFBUzVGLElBQVQsRUFBZTtBQUNwQ29GLFVBQU1wRixJQUFOLEVBQVk7QUFDWDZGLFdBQUtqRixNQURNO0FBRVh5RSxhQUFPUyxNQUFNQyxRQUFOLENBQWVuRixNQUFmLENBRkk7QUFHWDBFLGFBQU8xRSxNQUhJO0FBSVgyRSxXQUFLM0UsTUFKTTtBQUtYNEUsWUFBTU0sTUFBTUMsUUFBTixDQUFlbkYsTUFBZixDQUxLO0FBTVg2RSxjQUFRSyxNQUFNQyxRQUFOLENBQWVMLE1BQWY7QUFORyxLQUFaO0FBUUEsUUFBSXBGLE1BQU13QyxhQUFha0QsT0FBYixDQUFxQjtBQUFFSCxXQUFLN0YsS0FBSzZGO0FBQVosS0FBckIsQ0FBVjs7QUFDQSxRQUFHLENBQUMvQyxhQUFhSyxhQUFiLENBQTJCLEtBQUtELE1BQWhDLEVBQXdDNUMsR0FBeEMsQ0FBSixFQUFrRDtBQUNqRCxZQUFNLElBQUk0QixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ04sVUFBSTtBQUNILGVBQU83QyxhQUFhbUIsTUFBYixDQUFvQjtBQUFFNEIsZUFBSzdGLEtBQUs2RjtBQUFaLFNBQXBCLEVBQXVDO0FBQUVoQixnQkFBTTdFO0FBQVIsU0FBdkMsQ0FBUDtBQUNBLE9BRkQsQ0FFRSxPQUFPNEYsU0FBUCxFQUFrQjtBQUNuQixjQUFNLElBQUkxRCxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixLQUFLQyxTQUEzQixDQUFOO0FBQ0E7QUFDRDtBQUNELEdBdENhO0FBdUNkLHdCQUFzQixVQUFTSyxFQUFULEVBQWE7QUFDNUJiLFVBQU1hLEVBQU4sRUFBVXJGLE1BQVY7QUFDTixRQUFJTixNQUFNd0MsYUFBYWtELE9BQWIsQ0FBcUI7QUFBRUgsV0FBS0k7QUFBUCxLQUFyQixDQUFWOztBQUNBLFFBQUcsQ0FBQ25ELGFBQWFNLGFBQWIsQ0FBMkIsS0FBS0YsTUFBaEMsRUFBd0M1QyxHQUF4QyxDQUFKLEVBQWtEO0FBQ2pELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQSxLQUZELE1BRU87QUFDTixVQUFJO0FBQ0gsZUFBTzdDLGFBQWFzQixNQUFiLENBQW9CO0FBQUV5QixlQUFLSTtBQUFQLFNBQXBCLENBQVA7QUFDQSxPQUZELENBRUUsT0FBT0wsU0FBUCxFQUFrQjtBQUNuQixjQUFNLElBQUkxRCxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixLQUFLQyxTQUEzQixDQUFOO0FBQ0E7QUFDRDtBQUNEO0FBbkRhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQTs7Ozs7OztBQVFBMUQsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLHlCQUF1QixVQUFTbkYsSUFBVCxFQUFlO0FBQ3JDb0YsVUFBTXBGLElBQU4sRUFBWTtBQUNYcUYsYUFBT3pFLE1BREk7QUFFWDBFLGFBQU8xRSxNQUZJO0FBR1gyRSxXQUFLM0UsTUFITTtBQUlYNEUsWUFBTTVFLE1BSks7QUFLWDZFLGNBQVFDO0FBTEcsS0FBWjs7QUFPQSxRQUFHLENBQUNyQyxjQUFjSixhQUFkLENBQTRCLEtBQUtDLE1BQWpDLEVBQXlDbEQsSUFBekMsQ0FBSixFQUFvRDtBQUMxQyxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ1QsS0FGRCxNQUVPO0FBQ04sVUFBSTtBQUNILGVBQU90QyxjQUFjVyxNQUFkLENBQXFCaEUsSUFBckIsQ0FBUDtBQUNBLE9BRkQsQ0FFRSxPQUFPNEYsU0FBUCxFQUFrQjtBQUNuQixjQUFNLElBQUkxRCxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixLQUFLQyxTQUEzQixDQUFOO0FBQ0E7QUFDRDtBQUNELEdBbEJhO0FBbUJkLHlCQUF1QixVQUFTNUYsSUFBVCxFQUFlO0FBQ3JDb0YsVUFBTXBGLElBQU4sRUFBWTtBQUNYNkYsV0FBS2pGLE1BRE07QUFFWHlFLGFBQU9TLE1BQU1DLFFBQU4sQ0FBZW5GLE1BQWYsQ0FGSTtBQUdYMEUsYUFBTzFFLE1BSEk7QUFJWDJFLFdBQUszRSxNQUpNO0FBS1g0RSxZQUFNTSxNQUFNQyxRQUFOLENBQWVuRixNQUFmLENBTEs7QUFNWDZFLGNBQVFLLE1BQU1DLFFBQU4sQ0FBZUwsTUFBZjtBQU5HLEtBQVo7QUFRQSxRQUFJcEYsTUFBTStDLGNBQWMyQyxPQUFkLENBQXNCO0FBQUVILFdBQUs3RixLQUFLNkY7QUFBWixLQUF0QixDQUFWOztBQUNBLFFBQUcsQ0FBQ3hDLGNBQWNGLGFBQWQsQ0FBNEIsS0FBS0QsTUFBakMsRUFBeUM1QyxHQUF6QyxDQUFKLEVBQW1EO0FBQ2xELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQSxLQUZELE1BRU87QUFDTixVQUFJO0FBQ0gsZUFBT3RDLGNBQWNZLE1BQWQsQ0FBcUI7QUFBRTRCLGVBQUs3RixLQUFLNkY7QUFBWixTQUFyQixFQUF3QztBQUFFaEIsZ0JBQU03RTtBQUFSLFNBQXhDLENBQVA7QUFDQSxPQUZELENBRUUsT0FBTzRGLFNBQVAsRUFBa0I7QUFDbkIsY0FBTSxJQUFJMUQsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsS0FBS0MsU0FBM0IsQ0FBTjtBQUNBO0FBQ0Q7QUFDRCxHQXRDYTtBQXVDZCx5QkFBdUIsVUFBU0ssRUFBVCxFQUFhO0FBQzdCYixVQUFNYSxFQUFOLEVBQVVyRixNQUFWO0FBQ04sUUFBSU4sTUFBTStDLGNBQWMyQyxPQUFkLENBQXNCO0FBQUVILFdBQUtJO0FBQVAsS0FBdEIsQ0FBVjs7QUFDQSxRQUFHLENBQUM1QyxjQUFjRCxhQUFkLENBQTRCLEtBQUtGLE1BQWpDLEVBQXlDNUMsR0FBekMsQ0FBSixFQUFtRDtBQUNsRCxZQUFNLElBQUk0QixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0EsS0FGRCxNQUVPO0FBQ04sVUFBSTtBQUNILGVBQU90QyxjQUFjZSxNQUFkLENBQXFCO0FBQUV5QixlQUFLSTtBQUFQLFNBQXJCLENBQVA7QUFDQSxPQUZELENBRUUsT0FBT0wsU0FBUCxFQUFrQjtBQUNuQixjQUFNLElBQUkxRCxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixLQUFLQyxTQUEzQixDQUFOO0FBQ0E7QUFDRDtBQUNEO0FBbkRhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNUQTFELE9BQU9pRCxPQUFQLENBQWU7QUFDZCw0QkFBMEIsVUFBU25GLElBQVQsRUFBZTtBQUN4QyxRQUFHLENBQUNzRCxpQkFBaUJMLGFBQWpCLENBQStCLEtBQUtDLE1BQXBDLEVBQTRDbEQsSUFBNUMsQ0FBSixFQUF1RDtBQUN0RCxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT3JDLGlCQUFpQlUsTUFBakIsQ0FBd0JoRSxJQUF4QixDQUFQO0FBQ0EsR0FQYTtBQVNkLDRCQUEwQixVQUFTaUcsRUFBVCxFQUFhakcsSUFBYixFQUFtQjtBQUM1QyxRQUFJTSxNQUFNZ0QsaUJBQWlCMEMsT0FBakIsQ0FBeUI7QUFBRUgsV0FBS0k7QUFBUCxLQUF6QixDQUFWOztBQUNBLFFBQUcsQ0FBQzNDLGlCQUFpQkgsYUFBakIsQ0FBK0IsS0FBS0QsTUFBcEMsRUFBNEM1QyxHQUE1QyxDQUFKLEVBQXNEO0FBQ3JELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRHJDLHFCQUFpQlcsTUFBakIsQ0FBd0I7QUFBRTRCLFdBQUtJO0FBQVAsS0FBeEIsRUFBcUM7QUFBRXBCLFlBQU03RTtBQUFSLEtBQXJDO0FBQ0EsR0FoQmE7QUFrQmQsNEJBQTBCLFVBQVNpRyxFQUFULEVBQWE7QUFDdEMsUUFBSTNGLE1BQU1nRCxpQkFBaUIwQyxPQUFqQixDQUF5QjtBQUFFSCxXQUFLSTtBQUFQLEtBQXpCLENBQVY7O0FBQ0EsUUFBRyxDQUFDM0MsaUJBQWlCRixhQUFqQixDQUErQixLQUFLRixNQUFwQyxFQUE0QzVDLEdBQTVDLENBQUosRUFBc0Q7QUFDckQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEckMscUJBQWlCYyxNQUFqQixDQUF3QjtBQUFFeUIsV0FBS0k7QUFBUCxLQUF4QjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQS9ELE9BQU9pRCxPQUFQLENBQWU7QUFDZCwrQkFBNkIsVUFBU25GLElBQVQsRUFBZTtBQUMzQyxRQUFHLENBQUN1RCxvQkFBb0JOLGFBQXBCLENBQWtDLEtBQUtDLE1BQXZDLEVBQStDbEQsSUFBL0MsQ0FBSixFQUEwRDtBQUN6RCxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT3BDLG9CQUFvQlMsTUFBcEIsQ0FBMkJoRSxJQUEzQixDQUFQO0FBQ0EsR0FQYTtBQVNkLCtCQUE2QixVQUFTaUcsRUFBVCxFQUFhakcsSUFBYixFQUFtQjtBQUMvQyxRQUFJTSxNQUFNaUQsb0JBQW9CeUMsT0FBcEIsQ0FBNEI7QUFBRUgsV0FBS0k7QUFBUCxLQUE1QixDQUFWOztBQUNBLFFBQUcsQ0FBQzFDLG9CQUFvQkosYUFBcEIsQ0FBa0MsS0FBS0QsTUFBdkMsRUFBK0M1QyxHQUEvQyxDQUFKLEVBQXlEO0FBQ3hELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRHBDLHdCQUFvQlUsTUFBcEIsQ0FBMkI7QUFBRTRCLFdBQUtJO0FBQVAsS0FBM0IsRUFBd0M7QUFBRXBCLFlBQU03RTtBQUFSLEtBQXhDO0FBQ0EsR0FoQmE7QUFrQmQsK0JBQTZCLFVBQVNpRyxFQUFULEVBQWE7QUFDekMsUUFBSTNGLE1BQU1pRCxvQkFBb0J5QyxPQUFwQixDQUE0QjtBQUFFSCxXQUFLSTtBQUFQLEtBQTVCLENBQVY7O0FBQ0EsUUFBRyxDQUFDMUMsb0JBQW9CSCxhQUFwQixDQUFrQyxLQUFLRixNQUF2QyxFQUErQzVDLEdBQS9DLENBQUosRUFBeUQ7QUFDeEQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEcEMsd0JBQW9CYSxNQUFwQixDQUEyQjtBQUFFeUIsV0FBS0k7QUFBUCxLQUEzQjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQS9ELE9BQU9pRCxPQUFQLENBQWU7QUFDZCw2QkFBMkIsVUFBU25GLElBQVQsRUFBZTtBQUN6QyxRQUFHLENBQUN3RCxrQkFBa0JQLGFBQWxCLENBQWdDLEtBQUtDLE1BQXJDLEVBQTZDbEQsSUFBN0MsQ0FBSixFQUF3RDtBQUN2RCxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT25DLGtCQUFrQlEsTUFBbEIsQ0FBeUJoRSxJQUF6QixDQUFQO0FBQ0EsR0FQYTtBQVNkLDZCQUEyQixVQUFTaUcsRUFBVCxFQUFhakcsSUFBYixFQUFtQjtBQUM3QyxRQUFJTSxNQUFNa0Qsa0JBQWtCd0MsT0FBbEIsQ0FBMEI7QUFBRUgsV0FBS0k7QUFBUCxLQUExQixDQUFWOztBQUNBLFFBQUcsQ0FBQ3pDLGtCQUFrQkwsYUFBbEIsQ0FBZ0MsS0FBS0QsTUFBckMsRUFBNkM1QyxHQUE3QyxDQUFKLEVBQXVEO0FBQ3RELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRG5DLHNCQUFrQlMsTUFBbEIsQ0FBeUI7QUFBRTRCLFdBQUtJO0FBQVAsS0FBekIsRUFBc0M7QUFBRXBCLFlBQU03RTtBQUFSLEtBQXRDO0FBQ0EsR0FoQmE7QUFrQmQsNkJBQTJCLFVBQVNpRyxFQUFULEVBQWE7QUFDdkMsUUFBSTNGLE1BQU1rRCxrQkFBa0J3QyxPQUFsQixDQUEwQjtBQUFFSCxXQUFLSTtBQUFQLEtBQTFCLENBQVY7O0FBQ0EsUUFBRyxDQUFDekMsa0JBQWtCSixhQUFsQixDQUFnQyxLQUFLRixNQUFyQyxFQUE2QzVDLEdBQTdDLENBQUosRUFBdUQ7QUFDdEQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEbkMsc0JBQWtCWSxNQUFsQixDQUF5QjtBQUFFeUIsV0FBS0k7QUFBUCxLQUF6QjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQS9ELE9BQU9pRCxPQUFQLENBQWU7QUFDZCw4QkFBNEIsVUFBU25GLElBQVQsRUFBZTtBQUMxQyxRQUFHLENBQUN5RCxtQkFBbUJSLGFBQW5CLENBQWlDLEtBQUtDLE1BQXRDLEVBQThDbEQsSUFBOUMsQ0FBSixFQUF5RDtBQUN4RCxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT2xDLG1CQUFtQk8sTUFBbkIsQ0FBMEJoRSxJQUExQixDQUFQO0FBQ0EsR0FQYTtBQVNkLDhCQUE0QixVQUFTaUcsRUFBVCxFQUFhakcsSUFBYixFQUFtQjtBQUM5QyxRQUFJTSxNQUFNbUQsbUJBQW1CdUMsT0FBbkIsQ0FBMkI7QUFBRUgsV0FBS0k7QUFBUCxLQUEzQixDQUFWOztBQUNBLFFBQUcsQ0FBQ3hDLG1CQUFtQk4sYUFBbkIsQ0FBaUMsS0FBS0QsTUFBdEMsRUFBOEM1QyxHQUE5QyxDQUFKLEVBQXdEO0FBQ3ZELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRGxDLHVCQUFtQlEsTUFBbkIsQ0FBMEI7QUFBRTRCLFdBQUtJO0FBQVAsS0FBMUIsRUFBdUM7QUFBRXBCLFlBQU03RTtBQUFSLEtBQXZDO0FBQ0EsR0FoQmE7QUFrQmQsOEJBQTRCLFVBQVNpRyxFQUFULEVBQWE7QUFDeEMsUUFBSTNGLE1BQU1tRCxtQkFBbUJ1QyxPQUFuQixDQUEyQjtBQUFFSCxXQUFLSTtBQUFQLEtBQTNCLENBQVY7O0FBQ0EsUUFBRyxDQUFDeEMsbUJBQW1CTCxhQUFuQixDQUFpQyxLQUFLRixNQUF0QyxFQUE4QzVDLEdBQTlDLENBQUosRUFBd0Q7QUFDdkQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEbEMsdUJBQW1CVyxNQUFuQixDQUEwQjtBQUFFeUIsV0FBS0k7QUFBUCxLQUExQjtBQUNBO0FBekJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNBQS9ELE9BQU9pRCxPQUFQLENBQWU7QUFDZCx5QkFBdUIsVUFBU25GLElBQVQsRUFBZTtBQUNyQyxRQUFHLENBQUMwRCxjQUFjVCxhQUFkLENBQTRCLEtBQUtDLE1BQWpDLEVBQXlDbEQsSUFBekMsQ0FBSixFQUFvRDtBQUNuRCxZQUFNLElBQUlrQyxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQsV0FBT2pDLGNBQWNNLE1BQWQsQ0FBcUJoRSxJQUFyQixDQUFQO0FBQ0EsR0FQYTtBQVNkLHlCQUF1QixVQUFTaUcsRUFBVCxFQUFhakcsSUFBYixFQUFtQjtBQUN6QyxRQUFJTSxNQUFNb0QsY0FBY3NDLE9BQWQsQ0FBc0I7QUFBRUgsV0FBS0k7QUFBUCxLQUF0QixDQUFWOztBQUNBLFFBQUcsQ0FBQ3ZDLGNBQWNQLGFBQWQsQ0FBNEIsS0FBS0QsTUFBakMsRUFBeUM1QyxHQUF6QyxDQUFKLEVBQW1EO0FBQ2xELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRGpDLGtCQUFjTyxNQUFkLENBQXFCO0FBQUU0QixXQUFLSTtBQUFQLEtBQXJCLEVBQWtDO0FBQUVwQixZQUFNN0U7QUFBUixLQUFsQztBQUNBLEdBaEJhO0FBa0JkLHlCQUF1QixVQUFTaUcsRUFBVCxFQUFhO0FBQ25DLFFBQUkzRixNQUFNb0QsY0FBY3NDLE9BQWQsQ0FBc0I7QUFBRUgsV0FBS0k7QUFBUCxLQUF0QixDQUFWOztBQUNBLFFBQUcsQ0FBQ3ZDLGNBQWNOLGFBQWQsQ0FBNEIsS0FBS0YsTUFBakMsRUFBeUM1QyxHQUF6QyxDQUFKLEVBQW1EO0FBQ2xELFlBQU0sSUFBSTRCLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRGpDLGtCQUFjVSxNQUFkLENBQXFCO0FBQUV5QixXQUFLSTtBQUFQLEtBQXJCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBL0QsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLHNCQUFvQixVQUFTbkYsSUFBVCxFQUFlO0FBQ2xDLFFBQUcsQ0FBQzJELFdBQVdWLGFBQVgsQ0FBeUIsS0FBS0MsTUFBOUIsRUFBc0NsRCxJQUF0QyxDQUFKLEVBQWlEO0FBQ2hELFlBQU0sSUFBSWtDLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPaEMsV0FBV0ssTUFBWCxDQUFrQmhFLElBQWxCLENBQVA7QUFDQSxHQVBhO0FBU2Qsc0JBQW9CLFVBQVNpRyxFQUFULEVBQWFqRyxJQUFiLEVBQW1CO0FBQ3RDLFFBQUlNLE1BQU1xRCxXQUFXcUMsT0FBWCxDQUFtQjtBQUFFSCxXQUFLSTtBQUFQLEtBQW5CLENBQVY7O0FBQ0EsUUFBRyxDQUFDdEMsV0FBV1IsYUFBWCxDQUF5QixLQUFLRCxNQUE5QixFQUFzQzVDLEdBQXRDLENBQUosRUFBZ0Q7QUFDL0MsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEaEMsZUFBV00sTUFBWCxDQUFrQjtBQUFFNEIsV0FBS0k7QUFBUCxLQUFsQixFQUErQjtBQUFFcEIsWUFBTTdFO0FBQVIsS0FBL0I7QUFDQSxHQWhCYTtBQWtCZCxzQkFBb0IsVUFBU2lHLEVBQVQsRUFBYTtBQUNoQyxRQUFJM0YsTUFBTXFELFdBQVdxQyxPQUFYLENBQW1CO0FBQUVILFdBQUtJO0FBQVAsS0FBbkIsQ0FBVjs7QUFDQSxRQUFHLENBQUN0QyxXQUFXUCxhQUFYLENBQXlCLEtBQUtGLE1BQTlCLEVBQXNDNUMsR0FBdEMsQ0FBSixFQUFnRDtBQUMvQyxZQUFNLElBQUk0QixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRURoQyxlQUFXUyxNQUFYLENBQWtCO0FBQUV5QixXQUFLSTtBQUFQLEtBQWxCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBL0QsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLDhCQUE0QixVQUFTbkYsSUFBVCxFQUFlO0FBQzFDLFFBQUcsQ0FBQzRELG1CQUFtQlgsYUFBbkIsQ0FBaUMsS0FBS0MsTUFBdEMsRUFBOENsRCxJQUE5QyxDQUFKLEVBQXlEO0FBQ3hELFlBQU0sSUFBSWtDLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPL0IsbUJBQW1CSSxNQUFuQixDQUEwQmhFLElBQTFCLENBQVA7QUFDQSxHQVBhO0FBU2QsOEJBQTRCLFVBQVNpRyxFQUFULEVBQWFqRyxJQUFiLEVBQW1CO0FBQzlDLFFBQUlNLE1BQU1zRCxtQkFBbUJvQyxPQUFuQixDQUEyQjtBQUFFSCxXQUFLSTtBQUFQLEtBQTNCLENBQVY7O0FBQ0EsUUFBRyxDQUFDckMsbUJBQW1CVCxhQUFuQixDQUFpQyxLQUFLRCxNQUF0QyxFQUE4QzVDLEdBQTlDLENBQUosRUFBd0Q7QUFDdkQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEL0IsdUJBQW1CSyxNQUFuQixDQUEwQjtBQUFFNEIsV0FBS0k7QUFBUCxLQUExQixFQUF1QztBQUFFcEIsWUFBTTdFO0FBQVIsS0FBdkM7QUFDQSxHQWhCYTtBQWtCZCw4QkFBNEIsVUFBU2lHLEVBQVQsRUFBYTtBQUN4QyxRQUFJM0YsTUFBTXNELG1CQUFtQm9DLE9BQW5CLENBQTJCO0FBQUVILFdBQUtJO0FBQVAsS0FBM0IsQ0FBVjs7QUFDQSxRQUFHLENBQUNyQyxtQkFBbUJSLGFBQW5CLENBQWlDLEtBQUtGLE1BQXRDLEVBQThDNUMsR0FBOUMsQ0FBSixFQUF3RDtBQUN2RCxZQUFNLElBQUk0QixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQvQix1QkFBbUJRLE1BQW5CLENBQTBCO0FBQUV5QixXQUFLSTtBQUFQLEtBQTFCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBL0QsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLDJCQUF5QixVQUFTbkYsSUFBVCxFQUFlO0FBQ3ZDLFFBQUcsQ0FBQzZELGdCQUFnQlosYUFBaEIsQ0FBOEIsS0FBS0MsTUFBbkMsRUFBMkNsRCxJQUEzQyxDQUFKLEVBQXNEO0FBQ3JELFlBQU0sSUFBSWtDLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPOUIsZ0JBQWdCRyxNQUFoQixDQUF1QmhFLElBQXZCLENBQVA7QUFDQSxHQVBhO0FBU2QsMkJBQXlCLFVBQVNpRyxFQUFULEVBQWFqRyxJQUFiLEVBQW1CO0FBQzNDLFFBQUlNLE1BQU11RCxnQkFBZ0JtQyxPQUFoQixDQUF3QjtBQUFFSCxXQUFLSTtBQUFQLEtBQXhCLENBQVY7O0FBQ0EsUUFBRyxDQUFDcEMsZ0JBQWdCVixhQUFoQixDQUE4QixLQUFLRCxNQUFuQyxFQUEyQzVDLEdBQTNDLENBQUosRUFBcUQ7QUFDcEQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEOUIsb0JBQWdCSSxNQUFoQixDQUF1QjtBQUFFNEIsV0FBS0k7QUFBUCxLQUF2QixFQUFvQztBQUFFcEIsWUFBTTdFO0FBQVIsS0FBcEM7QUFDQSxHQWhCYTtBQWtCZCwyQkFBeUIsVUFBU2lHLEVBQVQsRUFBYTtBQUNyQyxRQUFJM0YsTUFBTXVELGdCQUFnQm1DLE9BQWhCLENBQXdCO0FBQUVILFdBQUtJO0FBQVAsS0FBeEIsQ0FBVjs7QUFDQSxRQUFHLENBQUNwQyxnQkFBZ0JULGFBQWhCLENBQThCLEtBQUtGLE1BQW5DLEVBQTJDNUMsR0FBM0MsQ0FBSixFQUFxRDtBQUNwRCxZQUFNLElBQUk0QixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixZQUF0QixDQUFOO0FBQ0E7O0FBRUQ5QixvQkFBZ0JPLE1BQWhCLENBQXVCO0FBQUV5QixXQUFLSTtBQUFQLEtBQXZCO0FBQ0E7QUF6QmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0FBL0QsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLHlCQUF1QixVQUFTbkYsSUFBVCxFQUFlO0FBQ3JDLFFBQUcsQ0FBQzhELGNBQWNiLGFBQWQsQ0FBNEIsS0FBS0MsTUFBakMsRUFBeUNsRCxJQUF6QyxDQUFKLEVBQW9EO0FBQ25ELFlBQU0sSUFBSWtDLE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLFlBQXRCLENBQU47QUFDQTs7QUFFRCxXQUFPN0IsY0FBY0UsTUFBZCxDQUFxQmhFLElBQXJCLENBQVA7QUFDQSxHQVBhO0FBU2QseUJBQXVCLFVBQVNpRyxFQUFULEVBQWFqRyxJQUFiLEVBQW1CO0FBQ3pDLFFBQUlNLE1BQU13RCxjQUFja0MsT0FBZCxDQUFzQjtBQUFFSCxXQUFLSTtBQUFQLEtBQXRCLENBQVY7O0FBQ0EsUUFBRyxDQUFDbkMsY0FBY1gsYUFBZCxDQUE0QixLQUFLRCxNQUFqQyxFQUF5QzVDLEdBQXpDLENBQUosRUFBbUQ7QUFDbEQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEN0Isa0JBQWNHLE1BQWQsQ0FBcUI7QUFBRTRCLFdBQUtJO0FBQVAsS0FBckIsRUFBa0M7QUFBRXBCLFlBQU03RTtBQUFSLEtBQWxDO0FBQ0EsR0FoQmE7QUFrQmQseUJBQXVCLFVBQVNpRyxFQUFULEVBQWE7QUFDbkMsUUFBSTNGLE1BQU13RCxjQUFja0MsT0FBZCxDQUFzQjtBQUFFSCxXQUFLSTtBQUFQLEtBQXRCLENBQVY7O0FBQ0EsUUFBRyxDQUFDbkMsY0FBY1YsYUFBZCxDQUE0QixLQUFLRixNQUFqQyxFQUF5QzVDLEdBQXpDLENBQUosRUFBbUQ7QUFDbEQsWUFBTSxJQUFJNEIsT0FBT3lELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0IsWUFBdEIsQ0FBTjtBQUNBOztBQUVEN0Isa0JBQWNNLE1BQWQsQ0FBcUI7QUFBRXlCLFdBQUtJO0FBQVAsS0FBckI7QUFDQTtBQXpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDQ0E7Ozs7Ozs7QUFRQS9ELE9BQU9nRSxPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBVztBQUNoRCxTQUFPcEQsYUFBYXBCLElBQWIsQ0FBa0IsRUFBbEIsRUFBc0IsRUFBdEIsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxxQkFBZixFQUFzQyxZQUFXO0FBQ2hELFNBQU9wRCxhQUFhcEIsSUFBYixDQUFrQjtBQUFDbUUsU0FBSTtBQUFMLEdBQWxCLEVBQThCLEVBQTlCLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFVBQVNDLGFBQVQsRUFBd0I7QUFDeEQsU0FBT3JELGFBQWFwQixJQUFiLENBQWtCO0FBQUNtRSxTQUFJTTtBQUFMLEdBQWxCLEVBQXVDLEVBQXZDLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7O0FDaEJBOzs7Ozs7O0FBUUFqRSxPQUFPZ0UsT0FBUCxDQUFlLHNCQUFmLEVBQXVDLFlBQVc7QUFDakQsU0FBTzdDLGNBQWMzQixJQUFkLENBQW1CLEVBQW5CLEVBQXVCLEVBQXZCLENBQVA7QUFDQSxDQUZEO0FBSUFRLE9BQU9nRSxPQUFQLENBQWUsc0JBQWYsRUFBdUMsWUFBVztBQUNqRCxTQUFPN0MsY0FBYzNCLElBQWQsQ0FBbUI7QUFBQ21FLFNBQUk7QUFBTCxHQUFuQixFQUErQixFQUEvQixDQUFQO0FBQ0EsQ0FGRDtBQUlBM0QsT0FBT2dFLE9BQVAsQ0FBZSxpQkFBZixFQUFrQyxVQUFTRSxjQUFULEVBQXlCO0FBQzFELFNBQU8vQyxjQUFjM0IsSUFBZCxDQUFtQjtBQUFDbUUsU0FBSU87QUFBTCxHQUFuQixFQUF5QyxFQUF6QyxDQUFQO0FBQ0EsQ0FGRCxFOzs7Ozs7Ozs7OztBQ2pCQWxFLE9BQU9nRSxPQUFQLENBQWUsa0JBQWYsRUFBbUMsWUFBVztBQUM3QyxTQUFPNUMsaUJBQWlCNUIsSUFBakIsQ0FBc0IsRUFBdEIsRUFBMEIsRUFBMUIsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxZQUFXO0FBQzlDLFNBQU81QyxpQkFBaUI1QixJQUFqQixDQUFzQjtBQUFDbUUsU0FBSTtBQUFMLEdBQXRCLEVBQWtDLEVBQWxDLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLGFBQWYsRUFBOEIsVUFBU0csYUFBVCxFQUF3QjtBQUNyRCxTQUFPL0MsaUJBQWlCNUIsSUFBakIsQ0FBc0I7QUFBQ21FLFNBQUlRO0FBQUwsR0FBdEIsRUFBMkMsRUFBM0MsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNSQW5FLE9BQU9nRSxPQUFQLENBQWUsb0JBQWYsRUFBcUMsWUFBVztBQUMvQyxTQUFPM0Msb0JBQW9CN0IsSUFBcEIsQ0FBeUIsRUFBekIsRUFBNkIsRUFBN0IsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxzQkFBZixFQUF1QyxZQUFXO0FBQ2pELFNBQU8zQyxvQkFBb0I3QixJQUFwQixDQUF5QjtBQUFDbUUsU0FBSTtBQUFMLEdBQXpCLEVBQXFDLEVBQXJDLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsVUFBU0ksZUFBVCxFQUEwQjtBQUN6RCxTQUFPL0Msb0JBQW9CN0IsSUFBcEIsQ0FBeUI7QUFBQ21FLFNBQUlTO0FBQUwsR0FBekIsRUFBZ0QsRUFBaEQsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNSQXBFLE9BQU9nRSxPQUFQLENBQWUsbUJBQWYsRUFBb0MsWUFBVztBQUM5QyxTQUFPMUMsa0JBQWtCOUIsSUFBbEIsQ0FBdUIsRUFBdkIsRUFBMkIsRUFBM0IsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxvQkFBZixFQUFxQyxZQUFXO0FBQy9DLFNBQU8xQyxrQkFBa0I5QixJQUFsQixDQUF1QjtBQUFDbUUsU0FBSTtBQUFMLEdBQXZCLEVBQW1DLEVBQW5DLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLGNBQWYsRUFBK0IsVUFBU0ssY0FBVCxFQUF5QjtBQUN2RCxTQUFPL0Msa0JBQWtCOUIsSUFBbEIsQ0FBdUI7QUFBQ21FLFNBQUlVO0FBQUwsR0FBdkIsRUFBNkMsRUFBN0MsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNSQXJFLE9BQU9nRSxPQUFQLENBQWUsbUJBQWYsRUFBb0MsWUFBVztBQUM5QyxTQUFPekMsbUJBQW1CL0IsSUFBbkIsQ0FBd0IsRUFBeEIsRUFBNEIsRUFBNUIsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxxQkFBZixFQUFzQyxZQUFXO0FBQ2hELFNBQU96QyxtQkFBbUIvQixJQUFuQixDQUF3QjtBQUFDbUUsU0FBSTtBQUFMLEdBQXhCLEVBQW9DLEVBQXBDLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLGNBQWYsRUFBK0IsVUFBU00sY0FBVCxFQUF5QjtBQUN2RCxTQUFPL0MsbUJBQW1CL0IsSUFBbkIsQ0FBd0I7QUFBQ21FLFNBQUlXO0FBQUwsR0FBeEIsRUFBOEMsRUFBOUMsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNSQXRFLE9BQU9nRSxPQUFQLENBQWUsV0FBZixFQUE0QixZQUFXO0FBQ3RDLFNBQU94QyxjQUFjaEMsSUFBZCxDQUFtQixFQUFuQixFQUF1QixFQUF2QixDQUFQO0FBQ0EsQ0FGRDtBQUlBUSxPQUFPZ0UsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBVztBQUMxQyxTQUFPeEMsY0FBY2hDLElBQWQsQ0FBbUIsRUFBbkIsRUFBdUIsRUFBdkIsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFXO0FBQzNDLFNBQU94QyxjQUFjaEMsSUFBZCxDQUFtQjtBQUFDbUUsU0FBSTtBQUFMLEdBQW5CLEVBQStCLEVBQS9CLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLFVBQWYsRUFBMkIsVUFBU08sVUFBVCxFQUFxQjtBQUMvQyxTQUFPL0MsY0FBY2hDLElBQWQsQ0FBbUI7QUFBQ21FLFNBQUlZO0FBQUwsR0FBbkIsRUFBcUMsRUFBckMsQ0FBUDtBQUNBLENBRkQsRTs7Ozs7Ozs7Ozs7QUNaQXZFLE9BQU9nRSxPQUFQLENBQWUsV0FBZixFQUE0QixZQUFXO0FBQ3RDLFNBQU92QyxXQUFXakMsSUFBWCxDQUFnQixFQUFoQixFQUFvQixFQUFwQixDQUFQO0FBQ0EsQ0FGRDtBQUlBUSxPQUFPZ0UsT0FBUCxDQUFlLGFBQWYsRUFBOEIsWUFBVztBQUN4QyxTQUFPdkMsV0FBV2pDLElBQVgsQ0FBZ0I7QUFBQ21FLFNBQUk7QUFBTCxHQUFoQixFQUE0QixFQUE1QixDQUFQO0FBQ0EsQ0FGRDtBQUlBM0QsT0FBT2dFLE9BQVAsQ0FBZSxNQUFmLEVBQXVCLFVBQVNRLE1BQVQsRUFBaUI7QUFDdkMsU0FBTy9DLFdBQVdqQyxJQUFYLENBQWdCO0FBQUNtRSxTQUFJYTtBQUFMLEdBQWhCLEVBQThCLEVBQTlCLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7O0FDUkF4RSxPQUFPZ0UsT0FBUCxDQUFlLG9CQUFmLEVBQXFDLFlBQVc7QUFDL0MsU0FBT3RDLG1CQUFtQmxDLElBQW5CLENBQXdCLEVBQXhCLEVBQTRCLEVBQTVCLENBQVA7QUFDQSxDQUZEO0FBSUFRLE9BQU9nRSxPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBVztBQUNoRCxTQUFPdEMsbUJBQW1CbEMsSUFBbkIsQ0FBd0I7QUFBQ21FLFNBQUk7QUFBTCxHQUF4QixFQUFvQyxFQUFwQyxDQUFQO0FBQ0EsQ0FGRDtBQUlBM0QsT0FBT2dFLE9BQVAsQ0FBZSxlQUFmLEVBQWdDLFVBQVNTLGVBQVQsRUFBMEI7QUFDekQsU0FBTy9DLG1CQUFtQmxDLElBQW5CLENBQXdCO0FBQUNtRSxTQUFJYztBQUFMLEdBQXhCLEVBQStDLEVBQS9DLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7O0FDUkF6RSxPQUFPZ0UsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQVc7QUFDM0MsU0FBT3JDLGdCQUFnQm5DLElBQWhCLENBQXFCLEVBQXJCLEVBQXlCLEVBQXpCLENBQVA7QUFDQSxDQUZEO0FBSUFRLE9BQU9nRSxPQUFQLENBQWUsa0JBQWYsRUFBbUMsWUFBVztBQUM3QyxTQUFPckMsZ0JBQWdCbkMsSUFBaEIsQ0FBcUI7QUFBQ21FLFNBQUk7QUFBTCxHQUFyQixFQUFpQyxFQUFqQyxDQUFQO0FBQ0EsQ0FGRDtBQUlBM0QsT0FBT2dFLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFVBQVNVLFdBQVQsRUFBc0I7QUFDakQsU0FBTy9DLGdCQUFnQm5DLElBQWhCLENBQXFCO0FBQUNtRSxTQUFJZTtBQUFMLEdBQXJCLEVBQXdDLEVBQXhDLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7O0FDUkExRSxPQUFPZ0UsT0FBUCxDQUFlLGNBQWYsRUFBK0IsWUFBVztBQUN6QyxTQUFPcEMsY0FBY3BDLElBQWQsQ0FBbUIsRUFBbkIsRUFBdUIsRUFBdkIsQ0FBUDtBQUNBLENBRkQ7QUFJQVEsT0FBT2dFLE9BQVAsQ0FBZSxnQkFBZixFQUFpQyxZQUFXO0FBQzNDLFNBQU9wQyxjQUFjcEMsSUFBZCxDQUFtQjtBQUFDbUUsU0FBSTtBQUFMLEdBQW5CLEVBQStCLEVBQS9CLENBQVA7QUFDQSxDQUZEO0FBSUEzRCxPQUFPZ0UsT0FBUCxDQUFlLFNBQWYsRUFBMEIsVUFBU1csU0FBVCxFQUFvQjtBQUM3QyxTQUFPL0MsY0FBY3BDLElBQWQsQ0FBbUI7QUFBQ21FLFNBQUlnQjtBQUFMLEdBQW5CLEVBQW9DLEVBQXBDLENBQVA7QUFDQSxDQUZELEU7Ozs7Ozs7Ozs7O0FDUkEsSUFBSUMsY0FBYyxJQUFsQjtBQUVBQyxTQUFTQyxNQUFULENBQWdCO0FBQUVDLHlCQUF1Qkg7QUFBekIsQ0FBaEI7QUFFQUMsU0FBU0csY0FBVCxDQUF3QkMsUUFBeEIsR0FBbUMsU0FBbkM7QUFDQUosU0FBU0csY0FBVCxDQUF3QkUsSUFBeEIsR0FBK0IseUNBQS9CO0FBRUE7Ozs7Ozs7Ozs7Ozs7OztBQWVBTCxTQUFTRyxjQUFULENBQXdCSixXQUF4QixHQUFzQztBQUNuQ08sWUFBVTtBQUNQLFdBQU8sNkRBQVA7QUFDRixHQUhrQzs7QUFJbkNyRixPQUFLc0YsSUFBTCxFQUFXQyxHQUFYLEVBQWdCO0FBQ2IsV0FBTyxVQUFVRCxLQUFLRSxPQUFMLENBQWFDLElBQXZCLEdBQThCLFFBQTlCLEdBQ0wsOERBREssR0FFTEYsR0FGSyxHQUVDLE1BRkQsR0FHTCwwQkFISyxHQUlMLHVCQUpGO0FBS0Y7O0FBVmtDLENBQXRDO0FBYUFyRixPQUFPd0YsT0FBUCxDQUFlLFlBQVc7QUFDekI7QUFDQSxNQUFHeEYsT0FBT3lGLFFBQVAsSUFBbUJ6RixPQUFPeUYsUUFBUCxDQUFnQkMsR0FBbkMsSUFBMEN4SCxFQUFFeUgsUUFBRixDQUFXM0YsT0FBT3lGLFFBQVAsQ0FBZ0JDLEdBQTNCLENBQTdDLEVBQThFO0FBQzdFLFNBQUksSUFBSUUsWUFBUixJQUF3QjVGLE9BQU95RixRQUFQLENBQWdCQyxHQUF4QyxFQUE2QztBQUM1Q0csY0FBUUgsR0FBUixDQUFZRSxZQUFaLElBQTRCNUYsT0FBT3lGLFFBQVAsQ0FBZ0JDLEdBQWhCLENBQW9CRSxZQUFwQixDQUE1QjtBQUNBO0FBQ0QsR0FOd0IsQ0FRekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxNQUFHZixZQUFZQSxTQUFTaUIseUJBQXJCLElBQWtEOUYsT0FBT3lGLFFBQXpELElBQXFFekYsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQXJGLElBQThGN0gsRUFBRXlILFFBQUYsQ0FBVzNGLE9BQU95RixRQUFQLENBQWdCTSxLQUEzQixDQUFqRyxFQUFvSTtBQUNuSTtBQUNBLFFBQUcvRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JDLE1BQXRCLElBQWdDOUgsRUFBRXlILFFBQUYsQ0FBVzNGLE9BQU95RixRQUFQLENBQWdCTSxLQUFoQixDQUFzQkMsTUFBakMsQ0FBbkMsRUFBNkU7QUFDNUU7QUFDQW5CLGVBQVNpQix5QkFBVCxDQUFtQzVELE1BQW5DLENBQTBDO0FBQ3pDK0QsaUJBQVM7QUFEZ0MsT0FBMUM7QUFJQSxVQUFJQyxpQkFBaUJsRyxPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JDLE1BQTNDO0FBQ0FFLHFCQUFlRCxPQUFmLEdBQXlCLFFBQXpCLENBUDRFLENBUzVFOztBQUNBcEIsZUFBU2lCLHlCQUFULENBQW1DaEUsTUFBbkMsQ0FBMENvRSxjQUExQztBQUNBLEtBYmtJLENBY25JOzs7QUFDQSxRQUFHbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSSxNQUF0QixJQUFnQ2pJLEVBQUV5SCxRQUFGLENBQVczRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JJLE1BQWpDLENBQW5DLEVBQTZFO0FBQzVFO0FBQ0F0QixlQUFTaUIseUJBQVQsQ0FBbUM1RCxNQUFuQyxDQUEwQztBQUN6QytELGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSSxNQUEzQztBQUNBRCxxQkFBZUQsT0FBZixHQUF5QixRQUF6QixDQVA0RSxDQVM1RTs7QUFDQXBCLGVBQVNpQix5QkFBVCxDQUFtQ2hFLE1BQW5DLENBQTBDb0UsY0FBMUM7QUFDQSxLQTFCa0ksQ0EyQm5JOzs7QUFDQSxRQUFHbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSyxRQUF0QixJQUFrQ2xJLEVBQUV5SCxRQUFGLENBQVczRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JLLFFBQWpDLENBQXJDLEVBQWlGO0FBQ2hGO0FBQ0F2QixlQUFTaUIseUJBQVQsQ0FBbUM1RCxNQUFuQyxDQUEwQztBQUN6QytELGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCSyxRQUEzQztBQUNBRixxQkFBZUQsT0FBZixHQUF5QixVQUF6QixDQVBnRixDQVNoRjs7QUFDQXBCLGVBQVNpQix5QkFBVCxDQUFtQ2hFLE1BQW5DLENBQTBDb0UsY0FBMUM7QUFDQSxLQXZDa0ksQ0F3Q25JOzs7QUFDQSxRQUFHbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTSxRQUF0QixJQUFrQ25JLEVBQUV5SCxRQUFGLENBQVczRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JNLFFBQWpDLENBQXJDLEVBQWlGO0FBQ2hGO0FBQ0F4QixlQUFTaUIseUJBQVQsQ0FBbUM1RCxNQUFuQyxDQUEwQztBQUN6QytELGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTSxRQUEzQztBQUNBSCxxQkFBZUQsT0FBZixHQUF5QixVQUF6QixDQVBnRixDQVNoRjs7QUFDQXBCLGVBQVNpQix5QkFBVCxDQUFtQ2hFLE1BQW5DLENBQTBDb0UsY0FBMUM7QUFDQSxLQXBEa0ksQ0FxRG5JOzs7QUFDQSxRQUFHbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTyxPQUF0QixJQUFpQ3BJLEVBQUV5SCxRQUFGLENBQVczRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JPLE9BQWpDLENBQXBDLEVBQStFO0FBQzlFO0FBQ0F6QixlQUFTaUIseUJBQVQsQ0FBbUM1RCxNQUFuQyxDQUEwQztBQUN6QytELGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCTyxPQUEzQztBQUNBSixxQkFBZUQsT0FBZixHQUF5QixTQUF6QixDQVA4RSxDQVM5RTs7QUFDQXBCLGVBQVNpQix5QkFBVCxDQUFtQ2hFLE1BQW5DLENBQTBDb0UsY0FBMUM7QUFDQSxLQWpFa0ksQ0FrRW5JOzs7QUFDQSxRQUFHbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCUSxNQUF0QixJQUFnQ3JJLEVBQUV5SCxRQUFGLENBQVczRixPQUFPeUYsUUFBUCxDQUFnQk0sS0FBaEIsQ0FBc0JRLE1BQWpDLENBQW5DLEVBQTZFO0FBQzVFO0FBQ0ExQixlQUFTaUIseUJBQVQsQ0FBbUM1RCxNQUFuQyxDQUEwQztBQUN6QytELGlCQUFTO0FBRGdDLE9BQTFDO0FBSUEsVUFBSUMsaUJBQWlCbEcsT0FBT3lGLFFBQVAsQ0FBZ0JNLEtBQWhCLENBQXNCUSxNQUEzQztBQUNBTCxxQkFBZUQsT0FBZixHQUF5QixrQkFBekIsQ0FQNEUsQ0FTNUU7O0FBQ0FwQixlQUFTaUIseUJBQVQsQ0FBbUNoRSxNQUFuQyxDQUEwQ29FLGNBQTFDO0FBQ0E7QUFDRDtBQUdELENBN0dEO0FBK0dBbEcsT0FBT2lELE9BQVAsQ0FBZTtBQUNkLHVCQUFxQixVQUFTUCxPQUFULEVBQWtCO0FBQ3RDLFFBQUcsQ0FBQzhELE1BQU1DLE9BQU4sQ0FBY3pHLE9BQU9nQixNQUFQLEVBQWQsQ0FBSixFQUFvQztBQUNuQyxZQUFNLElBQUloQixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrQkFBdEIsQ0FBTjtBQUNBOztBQUVELFFBQUlpRCxjQUFjLEVBQWxCO0FBQ0EsUUFBR2hFLFFBQVFpRSxRQUFYLEVBQXFCRCxZQUFZQyxRQUFaLEdBQXVCakUsUUFBUWlFLFFBQS9CO0FBQ3JCLFFBQUdqRSxRQUFRa0UsS0FBWCxFQUFrQkYsWUFBWUUsS0FBWixHQUFvQmxFLFFBQVFrRSxLQUE1QjtBQUNsQixRQUFHbEUsUUFBUW1FLFFBQVgsRUFBcUJILFlBQVlHLFFBQVosR0FBdUJuRSxRQUFRbUUsUUFBL0I7QUFDckIsUUFBR25FLFFBQVE0QyxPQUFYLEVBQW9Cb0IsWUFBWXBCLE9BQVosR0FBc0I1QyxRQUFRNEMsT0FBOUI7QUFDcEIsUUFBRzVDLFFBQVE0QyxPQUFSLElBQW1CNUMsUUFBUTRDLE9BQVIsQ0FBZ0JzQixLQUF0QyxFQUE2Q0YsWUFBWUUsS0FBWixHQUFvQmxFLFFBQVE0QyxPQUFSLENBQWdCc0IsS0FBcEM7QUFFN0MvQixhQUFTaUMsVUFBVCxDQUFvQkosV0FBcEI7QUFDQSxHQWRhO0FBZWQsdUJBQXFCLFVBQVMxRixNQUFULEVBQWlCMEIsT0FBakIsRUFBMEI7QUFDOUM7QUFDQSxRQUFHLEVBQUU4RCxNQUFNQyxPQUFOLENBQWN6RyxPQUFPZ0IsTUFBUCxFQUFkLEtBQWtDQSxVQUFVaEIsT0FBT2dCLE1BQVAsRUFBOUMsQ0FBSCxFQUFtRTtBQUNsRSxZQUFNLElBQUloQixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrQkFBdEIsQ0FBTjtBQUNBLEtBSjZDLENBTTlDOzs7QUFDQSxRQUFHLENBQUMrQyxNQUFNQyxPQUFOLENBQWN6RyxPQUFPZ0IsTUFBUCxFQUFkLENBQUosRUFBb0M7QUFDbkMsVUFBSStGLE9BQU9DLE9BQU9ELElBQVAsQ0FBWXJFLE9BQVosQ0FBWDs7QUFDQSxVQUFHcUUsS0FBSzdKLE1BQUwsS0FBZ0IsQ0FBaEIsSUFBcUIsQ0FBQ3dGLFFBQVE0QyxPQUFqQyxFQUEwQztBQUN6QyxjQUFNLElBQUl0RixPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrQkFBdEIsQ0FBTjtBQUNBO0FBQ0Q7O0FBRUQsUUFBSWlELGNBQWMsRUFBbEI7QUFDQSxRQUFHaEUsUUFBUWlFLFFBQVgsRUFBcUJELFlBQVlDLFFBQVosR0FBdUJqRSxRQUFRaUUsUUFBL0I7QUFDckIsUUFBR2pFLFFBQVFrRSxLQUFYLEVBQWtCRixZQUFZRSxLQUFaLEdBQW9CbEUsUUFBUWtFLEtBQTVCO0FBQ2xCLFFBQUdsRSxRQUFRbUUsUUFBWCxFQUFxQkgsWUFBWUcsUUFBWixHQUF1Qm5FLFFBQVFtRSxRQUEvQjtBQUNyQixRQUFHbkUsUUFBUTRDLE9BQVgsRUFBb0JvQixZQUFZcEIsT0FBWixHQUFzQjVDLFFBQVE0QyxPQUE5QjtBQUVwQixRQUFHNUMsUUFBUTRDLE9BQVIsSUFBbUI1QyxRQUFRNEMsT0FBUixDQUFnQnNCLEtBQXRDLEVBQTZDRixZQUFZRSxLQUFaLEdBQW9CbEUsUUFBUTRDLE9BQVIsQ0FBZ0JzQixLQUFwQztBQUM3QyxRQUFHbEUsUUFBUXVFLEtBQVgsRUFBa0JQLFlBQVlPLEtBQVosR0FBb0J2RSxRQUFRdUUsS0FBNUI7O0FBRWxCLFFBQUdQLFlBQVlFLEtBQWYsRUFBc0I7QUFDckIsVUFBSUEsUUFBUUYsWUFBWUUsS0FBeEI7QUFDQSxhQUFPRixZQUFZRSxLQUFuQjtBQUNBLFVBQUlNLFdBQVdWLE1BQU0xQyxPQUFOLENBQWMsS0FBSzlDLE1BQW5CLENBQWY7O0FBQ0EsVUFBR2tHLFNBQVNDLE1BQVQsSUFBbUIsQ0FBQ0QsU0FBU0MsTUFBVCxDQUFnQjNILElBQWhCLENBQXFCLFVBQVM0SCxJQUFULEVBQWU7QUFBRSxlQUFPQSxLQUFLQyxPQUFMLElBQWdCVCxLQUF2QjtBQUErQixPQUFyRSxDQUF2QixFQUErRjtBQUM5RkYsb0JBQVlTLE1BQVosR0FBcUIsQ0FBQztBQUFFRSxtQkFBU1Q7QUFBWCxTQUFELENBQXJCO0FBQ0E7QUFDRDs7QUFFRCxRQUFJQyxXQUFXLEVBQWY7O0FBQ0EsUUFBR0gsWUFBWUcsUUFBZixFQUF5QjtBQUN4QkEsaUJBQVdILFlBQVlHLFFBQXZCO0FBQ0EsYUFBT0gsWUFBWUcsUUFBbkI7QUFDQTs7QUFFRCxRQUFHSCxXQUFILEVBQWdCO0FBQ2YsV0FBSSxJQUFJaEosR0FBUixJQUFlZ0osV0FBZixFQUE0QjtBQUMzQixZQUFJNUosTUFBTTRKLFlBQVloSixHQUFaLENBQVY7O0FBQ0EsWUFBR1EsRUFBRXlILFFBQUYsQ0FBVzdJLEdBQVgsQ0FBSCxFQUFvQjtBQUNuQixlQUFJLElBQUlXLENBQVIsSUFBYVgsR0FBYixFQUFrQjtBQUNqQjRKLHdCQUFZaEosTUFBTSxHQUFOLEdBQVlELENBQXhCLElBQTZCWCxJQUFJVyxDQUFKLENBQTdCO0FBQ0E7O0FBQ0QsaUJBQU9pSixZQUFZaEosR0FBWixDQUFQO0FBQ0E7QUFDRDs7QUFDRDhJLFlBQU16RSxNQUFOLENBQWFmLE1BQWIsRUFBcUI7QUFBRTJCLGNBQU0rRDtBQUFSLE9BQXJCO0FBQ0E7O0FBRUQsUUFBR0csUUFBSCxFQUFhO0FBQ1poQyxlQUFTeUMsV0FBVCxDQUFxQnRHLE1BQXJCLEVBQTZCNkYsUUFBN0I7QUFDQTtBQUNELEdBckVhO0FBdUVkLGNBQVksVUFBU25FLE9BQVQsRUFBa0I7QUFDN0IsU0FBSzZFLE9BQUw7QUFFQUMsVUFBTUMsSUFBTixDQUFXL0UsT0FBWDtBQUNBO0FBM0VhLENBQWY7QUE4RUFtQyxTQUFTNkMsWUFBVCxDQUFzQixVQUFVaEYsT0FBVixFQUFtQjBDLElBQW5CLEVBQXlCO0FBQzlDQSxPQUFLNkIsS0FBTCxHQUFhLENBQUMsTUFBRCxDQUFiOztBQUVBLE1BQUd2RSxRQUFRNEMsT0FBWCxFQUFvQjtBQUNuQkYsU0FBS0UsT0FBTCxHQUFlNUMsUUFBUTRDLE9BQXZCO0FBQ0E7O0FBRUQsTUFBRyxDQUFDa0IsTUFBTTFDLE9BQU4sQ0FBYztBQUFFbUQsV0FBTztBQUFULEdBQWQsQ0FBRCxJQUFzQzdCLEtBQUs2QixLQUFMLENBQVdVLE9BQVgsQ0FBbUIsT0FBbkIsSUFBOEIsQ0FBdkUsRUFBMEU7QUFDekV2QyxTQUFLNkIsS0FBTCxHQUFhLENBQUMsT0FBRCxDQUFiO0FBQ0M7O0FBRUYsU0FBTzdCLElBQVA7QUFDQSxDQVpEO0FBY0FQLFNBQVMrQyxvQkFBVCxDQUE4QixVQUFTQyxJQUFULEVBQWU7QUFFNUM7QUFDQSxNQUFHQSxLQUFLekMsSUFBTCxJQUFhb0IsTUFBTXNCLFFBQU4sQ0FBZUQsS0FBS3pDLElBQUwsQ0FBVXpCLEdBQXpCLEVBQThCLFNBQTlCLENBQWhCLEVBQTBEO0FBQ3pELFVBQU0sSUFBSTNELE9BQU95RCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDJCQUF0QixDQUFOO0FBQ0E7O0FBRUEsTUFBR21CLGVBQWVpRCxLQUFLekMsSUFBcEIsSUFBNEJ5QyxLQUFLekMsSUFBTCxDQUFVK0IsTUFBdEMsSUFBZ0RVLEtBQUt6QyxJQUFMLENBQVUrQixNQUFWLENBQWlCakssTUFBakUsSUFBMkUsQ0FBQzJLLEtBQUt6QyxJQUFMLENBQVUrQixNQUFWLENBQWlCLENBQWpCLEVBQW9CWSxRQUFuRyxFQUE4RztBQUM3RyxVQUFNLElBQUkvSCxPQUFPeUQsS0FBWCxDQUFpQixHQUFqQixFQUFzQix1QkFBdEIsQ0FBTjtBQUNBOztBQUVGLFNBQU8sSUFBUDtBQUNBLENBWkQ7QUFlQStDLE1BQU1yRSxNQUFOLENBQWFMLE1BQWIsQ0FBb0IsVUFBU2QsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCO0FBQ3pDLE1BQUdBLElBQUkrSSxNQUFKLElBQWMvSSxJQUFJK0ksTUFBSixDQUFXLENBQVgsQ0FBZCxJQUErQi9JLElBQUkrSSxNQUFKLENBQVcsQ0FBWCxFQUFjRSxPQUFoRCxFQUF5RDtBQUN4RGpKLFFBQUlrSCxPQUFKLEdBQWNsSCxJQUFJa0gsT0FBSixJQUFlLEVBQTdCO0FBQ0FsSCxRQUFJa0gsT0FBSixDQUFZc0IsS0FBWixHQUFvQnhJLElBQUkrSSxNQUFKLENBQVcsQ0FBWCxFQUFjRSxPQUFsQztBQUNBLEdBSEQsTUFHTztBQUNOO0FBQ0EsUUFBR2pKLElBQUk0SixRQUFQLEVBQWlCO0FBQ2hCO0FBQ0EsVUFBRzVKLElBQUk0SixRQUFKLENBQWFoQyxNQUFiLElBQXVCNUgsSUFBSTRKLFFBQUosQ0FBYWhDLE1BQWIsQ0FBb0JZLEtBQTlDLEVBQXFEO0FBQ3BEeEksWUFBSWtILE9BQUosR0FBY2xILElBQUlrSCxPQUFKLElBQWUsRUFBN0I7QUFDQWxILFlBQUlrSCxPQUFKLENBQVlzQixLQUFaLEdBQW9CeEksSUFBSTRKLFFBQUosQ0FBYWhDLE1BQWIsQ0FBb0JZLEtBQXhDO0FBQ0EsT0FIRCxNQUdPO0FBQ047QUFDQSxZQUFHeEksSUFBSTRKLFFBQUosQ0FBYTdCLE1BQWIsSUFBdUIvSCxJQUFJNEosUUFBSixDQUFhN0IsTUFBYixDQUFvQjhCLFdBQTlDLEVBQTJEO0FBQzFELGNBQUk5QixTQUFTLElBQUkrQixNQUFKLENBQVc7QUFDdkJDLHFCQUFTLE9BRGM7QUFFdkJDLHFCQUFTO0FBRmMsV0FBWCxDQUFiO0FBS0FqQyxpQkFBT2tDLFlBQVAsQ0FBb0I7QUFDbkIvRSxrQkFBTSxPQURhO0FBRW5CZ0YsbUJBQU9sSyxJQUFJNEosUUFBSixDQUFhN0IsTUFBYixDQUFvQjhCO0FBRlIsV0FBcEI7O0FBS0EsY0FBSTtBQUNILGdCQUFJTSxTQUFTcEMsT0FBT2YsSUFBUCxDQUFZb0QsU0FBWixDQUFzQixFQUF0QixDQUFiOztBQUNBLGdCQUFJNUIsUUFBUTFJLEVBQUV1SyxTQUFGLENBQVlGLE1BQVosRUFBb0I7QUFBRUcsdUJBQVM7QUFBWCxhQUFwQixDQUFaOztBQUNBLGdCQUFHLENBQUM5QixLQUFELElBQVUyQixPQUFPckwsTUFBakIsSUFBMkJnQixFQUFFeUssUUFBRixDQUFXSixPQUFPLENBQVAsQ0FBWCxDQUE5QixFQUFxRDtBQUNwRDNCLHNCQUFRO0FBQUVBLHVCQUFPMkIsT0FBTyxDQUFQO0FBQVQsZUFBUjtBQUNBOztBQUVELGdCQUFHM0IsS0FBSCxFQUFVO0FBQ1R4SSxrQkFBSWtILE9BQUosR0FBY2xILElBQUlrSCxPQUFKLElBQWUsRUFBN0I7QUFDQWxILGtCQUFJa0gsT0FBSixDQUFZc0IsS0FBWixHQUFvQkEsTUFBTUEsS0FBMUI7QUFDQTtBQUNELFdBWEQsQ0FXRSxPQUFNZ0MsQ0FBTixFQUFTO0FBQ1ZDLG9CQUFRQyxHQUFSLENBQVlGLENBQVo7QUFDQTtBQUNELFNBekJELE1BeUJPO0FBQ047QUFDQSxjQUFHeEssSUFBSTRKLFFBQUosQ0FBYTVCLFFBQWIsSUFBeUJoSSxJQUFJNEosUUFBSixDQUFhNUIsUUFBYixDQUFzQjJDLFlBQWxELEVBQWdFO0FBQy9EM0ssZ0JBQUlrSCxPQUFKLEdBQWNsSCxJQUFJa0gsT0FBSixJQUFlLEVBQTdCO0FBQ0FsSCxnQkFBSWtILE9BQUosQ0FBWUMsSUFBWixHQUFtQm5ILElBQUk0SixRQUFKLENBQWE1QixRQUFiLENBQXNCNEMsU0FBdEIsR0FBa0MsR0FBbEMsR0FBd0M1SyxJQUFJNEosUUFBSixDQUFhNUIsUUFBYixDQUFzQjZDLFFBQWpGO0FBQ0E3SyxnQkFBSWtILE9BQUosQ0FBWXNCLEtBQVosR0FBb0J4SSxJQUFJNEosUUFBSixDQUFhNUIsUUFBYixDQUFzQjJDLFlBQTFDO0FBQ0EsV0FKRCxNQUlPO0FBQ04sZ0JBQUczSyxJQUFJNEosUUFBSixDQUFhM0IsUUFBYixJQUF5QmpJLElBQUk0SixRQUFKLENBQWEzQixRQUFiLENBQXNCTyxLQUFsRCxFQUF5RDtBQUN4RHhJLGtCQUFJa0gsT0FBSixHQUFjbEgsSUFBSWtILE9BQUosSUFBZSxFQUE3QjtBQUNBbEgsa0JBQUlrSCxPQUFKLENBQVlzQixLQUFaLEdBQW9CeEksSUFBSTRKLFFBQUosQ0FBYTNCLFFBQWIsQ0FBc0JPLEtBQTFDO0FBQ0EsYUFIRCxNQUdPO0FBQ04sa0JBQUd4SSxJQUFJNEosUUFBSixDQUFhMUIsT0FBYixJQUF3QmxJLElBQUk0SixRQUFKLENBQWExQixPQUFiLENBQXFCTSxLQUFoRCxFQUF1RDtBQUN0RHhJLG9CQUFJa0gsT0FBSixHQUFjbEgsSUFBSWtILE9BQUosSUFBZSxFQUE3QjtBQUNBbEgsb0JBQUlrSCxPQUFKLENBQVlzQixLQUFaLEdBQW9CeEksSUFBSTRKLFFBQUosQ0FBYTFCLE9BQWIsQ0FBcUJNLEtBQXpDO0FBQ0EsZUFIRCxNQUdPO0FBQ04sb0JBQUd4SSxJQUFJNEosUUFBSixDQUFhLGtCQUFiLEtBQW9DNUosSUFBSTRKLFFBQUosQ0FBYSxrQkFBYixFQUFpQ2IsTUFBckUsSUFBK0UvSSxJQUFJNEosUUFBSixDQUFhLGtCQUFiLEVBQWlDYixNQUFqQyxDQUF3Q2pLLE1BQTFILEVBQWtJO0FBQ2pJa0Isc0JBQUlrSCxPQUFKLEdBQWNsSCxJQUFJa0gsT0FBSixJQUFlLEVBQTdCO0FBQ0FsSCxzQkFBSWtILE9BQUosQ0FBWXNCLEtBQVosR0FBb0J4SSxJQUFJNEosUUFBSixDQUFhLGtCQUFiLEVBQWlDYixNQUFqQyxDQUF3QyxDQUF4QyxFQUEyQ0UsT0FBL0Q7QUFDQTtBQUNEO0FBQ0Q7QUFDRDtBQUNEO0FBQ0Q7QUFDRDtBQUNEO0FBQ0QsQ0FoRUQ7QUFrRUFiLE1BQU1yRSxNQUFOLENBQWFKLE1BQWIsQ0FBb0IsVUFBU2YsTUFBVCxFQUFpQjVDLEdBQWpCLEVBQXNCcUUsVUFBdEIsRUFBa0NSLFFBQWxDLEVBQTRDUyxPQUE1QyxFQUFxRDtBQUN4RSxNQUFHVCxTQUFTVSxJQUFULElBQWlCVixTQUFTVSxJQUFULENBQWN3RSxNQUEvQixJQUF5Q2xGLFNBQVNVLElBQVQsQ0FBY3dFLE1BQWQsQ0FBcUJqSyxNQUE5RCxJQUF3RStFLFNBQVNVLElBQVQsQ0FBY3dFLE1BQWQsQ0FBcUIsQ0FBckIsRUFBd0JFLE9BQW5HLEVBQTRHO0FBQzNHcEYsYUFBU1UsSUFBVCxDQUFjMkMsT0FBZCxDQUFzQnNCLEtBQXRCLEdBQThCM0UsU0FBU1UsSUFBVCxDQUFjd0UsTUFBZCxDQUFxQixDQUFyQixFQUF3QkUsT0FBdEQ7QUFDQTtBQUNELENBSkQ7QUFNQXhDLFNBQVNxRSxPQUFULENBQWlCLFVBQVVyQixJQUFWLEVBQWdCLENBRWhDLENBRkQ7O0FBSUFoRCxTQUFTc0UsSUFBVCxDQUFjQyxhQUFkLEdBQThCLFVBQVVkLEtBQVYsRUFBaUI7QUFDOUMsU0FBT3RJLE9BQU9xSixXQUFQLENBQW1CLG9CQUFvQmYsS0FBdkMsQ0FBUDtBQUNBLENBRkQ7O0FBSUF6RCxTQUFTc0UsSUFBVCxDQUFjdkUsV0FBZCxHQUE0QixVQUFVMEQsS0FBVixFQUFpQjtBQUM1QyxTQUFPdEksT0FBT3FKLFdBQVAsQ0FBbUIsa0JBQWtCZixLQUFyQyxDQUFQO0FBQ0EsQ0FGRCxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgaGFzU3BhY2UgPSAvXFxzL1xudmFyIGhhc1NlcGFyYXRvciA9IC9bXFxXX10vXG52YXIgaGFzQ2FtZWwgPSAvKFthLXpdW0EtWl18W0EtWl1bYS16XSkvXG5cbi8qKlxuICogUmVtb3ZlIGFueSBzdGFydGluZyBjYXNlIGZyb20gYSBgc3RyaW5nYCwgbGlrZSBjYW1lbCBvciBzbmFrZSwgYnV0IGtlZXBcbiAqIHNwYWNlcyBhbmQgcHVuY3R1YXRpb24gdGhhdCBtYXkgYmUgaW1wb3J0YW50IG90aGVyd2lzZS5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cblxudGhpcy50b05vQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICBpZiAoaGFzU3BhY2UudGVzdChzdHJpbmcpKSByZXR1cm4gc3RyaW5nLnRvTG93ZXJDYXNlKCk7XG4gIGlmIChoYXNTZXBhcmF0b3IudGVzdChzdHJpbmcpKSByZXR1cm4gKHVuc2VwYXJhdGUoc3RyaW5nKSB8fCBzdHJpbmcpLnRvTG93ZXJDYXNlKCk7XG4gIGlmIChoYXNDYW1lbC50ZXN0KHN0cmluZykpIHJldHVybiB1bmNhbWVsaXplKHN0cmluZykudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIHN0cmluZy50b0xvd2VyQ2FzZSgpO1xufTtcblxuLyoqXG4gKiBTZXBhcmF0b3Igc3BsaXR0ZXIuXG4gKi9cblxudmFyIHNlcGFyYXRvclNwbGl0dGVyID0gL1tcXFdfXSsoLnwkKS9nXG5cbi8qKlxuICogVW4tc2VwYXJhdGUgYSBgc3RyaW5nYC5cbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtTdHJpbmd9XG4gKi9cblxuZnVuY3Rpb24gdW5zZXBhcmF0ZShzdHJpbmcpIHtcbiAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKHNlcGFyYXRvclNwbGl0dGVyLCBmdW5jdGlvbiAobSwgbmV4dCkge1xuICAgIHJldHVybiBuZXh0ID8gJyAnICsgbmV4dCA6ICcnO1xuICB9KTtcbn1cblxuLyoqXG4gKiBDYW1lbGNhc2Ugc3BsaXR0ZXIuXG4gKi9cblxudmFyIGNhbWVsU3BsaXR0ZXIgPSAvKC4pKFtBLVpdKykvZ1xuXG4vKipcbiAqIFVuLWNhbWVsY2FzZSBhIGBzdHJpbmdgLlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJpbmdcbiAqIEByZXR1cm4ge1N0cmluZ31cbiAqL1xuXG5mdW5jdGlvbiB1bmNhbWVsaXplKHN0cmluZykge1xuICByZXR1cm4gc3RyaW5nLnJlcGxhY2UoY2FtZWxTcGxpdHRlciwgZnVuY3Rpb24gKG0sIHByZXZpb3VzLCB1cHBlcnMpIHtcbiAgICByZXR1cm4gcHJldmlvdXMgKyAnICcgKyB1cHBlcnMudG9Mb3dlckNhc2UoKS5zcGxpdCgnJykuam9pbignICcpO1xuICB9KTtcbn1cblxudGhpcy50b1NwYWNlQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICByZXR1cm4gdG9Ob0Nhc2Uoc3RyaW5nKS5yZXBsYWNlKC9bXFxXX10rKC58JCkvZywgZnVuY3Rpb24gKG1hdGNoZXMsIG1hdGNoKSB7XG4gICAgcmV0dXJuIG1hdGNoID8gJyAnICsgbWF0Y2ggOiAnJztcbiAgfSkudHJpbSgpO1xufTtcblxudGhpcy50b0NhbWVsQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICByZXR1cm4gdG9TcGFjZUNhc2Uoc3RyaW5nKS5yZXBsYWNlKC9cXHMoXFx3KS9nLCBmdW5jdGlvbiAobWF0Y2hlcywgbGV0dGVyKSB7XG4gICAgcmV0dXJuIGxldHRlci50b1VwcGVyQ2FzZSgpO1xuICB9KTtcbn07XG5cbnRoaXMudG9TbmFrZUNhc2UgPSBmdW5jdGlvbihzdHJpbmcpIHtcbiAgcmV0dXJuIHRvU3BhY2VDYXNlKHN0cmluZykucmVwbGFjZSgvXFxzL2csICdfJyk7XG59O1xuXG50aGlzLnRvS2ViYWJDYXNlID0gZnVuY3Rpb24oc3RyaW5nKSB7XG4gIHJldHVybiB0b1NwYWNlQ2FzZShzdHJpbmcpLnJlcGxhY2UoL1xccy9nLCAnLScpO1xufTtcblxudGhpcy50b1RpdGxlQ2FzZSA9IGZ1bmN0aW9uKHN0cmluZykge1xuICB2YXIgc3RyID0gdG9TcGFjZUNhc2Uoc3RyaW5nKS5yZXBsYWNlKC9cXHMoXFx3KS9nLCBmdW5jdGlvbihtYXRjaGVzLCBsZXR0ZXIpIHtcbiAgICByZXR1cm4gXCIgXCIgKyBsZXR0ZXIudG9VcHBlckNhc2UoKTtcbiAgfSk7XG5cbiAgaWYoc3RyKSB7XG4gICAgc3RyID0gc3RyLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyLnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiBzdHI7XG59O1xuIiwiLypcbiAgIFJldHVybnMgcHJvcGVydHkgdmFsdWUsIHdoZXJlIHByb3BlcnR5IG5hbWUgaXMgZ2l2ZW4gYXMgcGF0aC5cblxuICAgRXhhbXBsZTpcblxuICAgICAgIGdldFByb3BlcnR5VmFsdWUoXCJ4LnkuelwiLCB7IHg6IHsgeTogeyB6OiAxMjMgfSB9IH0pOyAvLyByZXR1cm5zIDEyM1xuKi9cblxudGhpcy5nZXRQcm9wZXJ0eVZhbHVlID0gZnVuY3Rpb24ocHJvcGVydHlOYW1lLCBvYmopIHtcblx0dmFyIHByb3BzID0gcHJvcGVydHlOYW1lLnNwbGl0KFwiLlwiKTtcblx0dmFyIHJlcyA9IG9iajtcblx0Zm9yKHZhciBpID0gMDsgaSA8IHByb3BzLmxlbmd0aDsgaSsrKSB7XG5cdFx0cmVzID0gcmVzW3Byb3BzW2ldXTtcblx0XHRpZih0eXBlb2YgcmVzID09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdHJldHVybiByZXM7XG5cdFx0fVxuXHR9XG5cdHJldHVybiByZXM7XG59O1xuXG5cbi8qIFxuICAgY29udmVydHMgcHJvcGVydGllcyBpbiBmb3JtYXQgeyBcIngueVwiOiBcInpcIiB9IHRvIHsgeDogeyB5OiBcInpcIiB9IH1cbiovXG5cbnRoaXMuZGVlcGVuID0gZnVuY3Rpb24obykge1xuXHR2YXIgb28gPSB7fSwgdCwgcGFydHMsIHBhcnQ7XG5cdGZvciAodmFyIGsgaW4gbykge1xuXHRcdHQgPSBvbztcblx0XHRwYXJ0cyA9IGsuc3BsaXQoJy4nKTtcblx0XHR2YXIga2V5ID0gcGFydHMucG9wKCk7XG5cdFx0d2hpbGUgKHBhcnRzLmxlbmd0aCkge1xuXHRcdFx0cGFydCA9IHBhcnRzLnNoaWZ0KCk7XG5cdFx0XHR0ID0gdFtwYXJ0XSA9IHRbcGFydF0gfHwge307XG5cdFx0fVxuXHRcdHRba2V5XSA9IG9ba107XG5cdH1cblx0cmV0dXJuIG9vO1xufTtcblxuLypcblx0RnVuY3Rpb24gY29udmVydHMgYXJyYXkgb2Ygb2JqZWN0cyB0byBjc3YsIHRzdiBvciBqc29uIHN0cmluZ1xuXG5cdGV4cG9ydEZpZWxkczogbGlzdCBvZiBvYmplY3Qga2V5cyB0byBleHBvcnQgKGFycmF5IG9mIHN0cmluZ3MpXG5cdGZpbGVUeXBlOiBjYW4gYmUgXCJqc29uXCIsIFwiY3N2XCIsIFwidHN2XCIgKHN0cmluZylcbiovXG5cbnRoaXMuZXhwb3J0QXJyYXlPZk9iamVjdHMgPSBmdW5jdGlvbihkYXRhLCBleHBvcnRGaWVsZHMsIGZpbGVUeXBlKSB7XG5cdGRhdGEgPSBkYXRhIHx8IFtdO1xuXHRmaWxlVHlwZSA9IGZpbGVUeXBlIHx8IFwiY3N2XCI7XG5cdGV4cG9ydEZpZWxkcyA9IGV4cG9ydEZpZWxkcyB8fCBbXTtcblxuXHR2YXIgc3RyID0gXCJcIjtcblx0Ly8gZXhwb3J0IHRvIEpTT05cblx0aWYoZmlsZVR5cGUgPT0gXCJqc29uXCIpIHtcblxuXHRcdHZhciB0bXAgPSBbXTtcblx0XHRfLmVhY2goZGF0YSwgZnVuY3Rpb24oZG9jKSB7XG5cdFx0XHR2YXIgb2JqID0ge307XG5cdFx0XHRfLmVhY2goZXhwb3J0RmllbGRzLCBmdW5jdGlvbihmaWVsZCkge1xuXHRcdFx0XHRvYmpbZmllbGRdID0gZG9jW2ZpZWxkXTtcblx0XHRcdH0pO1xuXHRcdFx0dG1wLnB1c2gob2JqKTtcblx0XHR9KTtcblxuXHRcdHN0ciA9IEpTT04uc3RyaW5naWZ5KHRtcCk7XG5cdH1cblxuXHQvLyBleHBvcnQgdG8gQ1NWIG9yIFRTVlxuXHRpZihmaWxlVHlwZSA9PSBcImNzdlwiIHx8IGZpbGVUeXBlID09IFwidHN2XCIpIHtcblx0XHR2YXIgY29sdW1uU2VwYXJhdG9yID0gXCJcIjtcblx0XHRpZihmaWxlVHlwZSA9PSBcImNzdlwiKSB7XG5cdFx0XHRjb2x1bW5TZXBhcmF0b3IgPSBcIixcIjtcblx0XHR9XG5cdFx0aWYoZmlsZVR5cGUgPT0gXCJ0c3ZcIikge1xuXHRcdFx0Ly8gXCJcXHRcIiBvYmplY3QgbGl0ZXJhbCBkb2VzIG5vdCB0cmFuc3BpbGUgY29ycmVjdGx5IHRvIGNvZmZlZXNjdGlwdFxuXHRcdFx0Y29sdW1uU2VwYXJhdG9yID0gU3RyaW5nLmZyb21DaGFyQ29kZSg5KTtcblx0XHR9XG5cblx0XHRfLmVhY2goZXhwb3J0RmllbGRzLCBmdW5jdGlvbihmaWVsZCwgaSkge1xuXHRcdFx0aWYoaSA+IDApIHtcblx0XHRcdFx0c3RyID0gc3RyICsgY29sdW1uU2VwYXJhdG9yO1xuXHRcdFx0fVxuXHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXCIgKyBmaWVsZCArIFwiXFxcIlwiO1xuXHRcdH0pO1xuXHRcdC8vXFxyIGRvZXMgbm90IHRyYW5zcGlsZSBjb3JyZWN0bHkgdG8gY29mZmVlc2NyaXB0XG5cdFx0c3RyID0gc3RyICsgU3RyaW5nLmZyb21DaGFyQ29kZSgxMykgKyBcIlxcblwiO1xuXG5cdFx0Xy5lYWNoKGRhdGEsIGZ1bmN0aW9uKGRvYykge1xuXHRcdFx0Xy5lYWNoKGV4cG9ydEZpZWxkcywgZnVuY3Rpb24oZmllbGQsIGkpIHtcblx0XHRcdFx0aWYoaSA+IDApIHtcblx0XHRcdFx0XHRzdHIgPSBzdHIgKyBjb2x1bW5TZXBhcmF0b3I7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHR2YXIgdmFsdWUgPSBnZXRQcm9wZXJ0eVZhbHVlKGZpZWxkLCBkb2MpICsgXCJcIjtcblx0XHRcdFx0dmFsdWUgPSB2YWx1ZS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpO1xuXHRcdFx0XHRpZih0eXBlb2YodmFsdWUpID09IFwidW5kZWZpbmVkXCIpXG5cdFx0XHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXFxcIlwiO1xuXHRcdFx0XHRlbHNlXG5cdFx0XHRcdFx0c3RyID0gc3RyICsgXCJcXFwiXCIgKyB2YWx1ZSArIFwiXFxcIlwiO1xuXHRcdFx0fSk7XG5cdFx0XHQvL1xcciBkb2VzIG5vdCB0cmFuc3BpbGUgY29ycmVjdGx5IHRvIGNvZmZlZXNjcmlwdFxuXHRcdFx0c3RyID0gc3RyICsgU3RyaW5nLmZyb21DaGFyQ29kZSgxMykgKyBcIlxcblwiO1xuXHRcdH0pO1xuXHR9XG5cblx0cmV0dXJuIHN0cjtcbn07XG5cblxudGhpcy5tZXJnZU9iamVjdHMgPSBmdW5jdGlvbih0YXJnZXQsIHNvdXJjZSkge1xuXG5cdC8qIE1lcmdlcyB0d28gKG9yIG1vcmUpIG9iamVjdHMsXG5cdGdpdmluZyB0aGUgbGFzdCBvbmUgcHJlY2VkZW5jZSAqL1xuXG5cdGlmKHR5cGVvZiB0YXJnZXQgIT09IFwib2JqZWN0XCIpIHtcblx0XHR0YXJnZXQgPSB7fTtcblx0fVxuXG5cdGZvcih2YXIgcHJvcGVydHkgaW4gc291cmNlKSB7XG5cblx0XHRpZihzb3VyY2UuaGFzT3duUHJvcGVydHkocHJvcGVydHkpKSB7XG5cblx0XHRcdHZhciBzb3VyY2VQcm9wZXJ0eSA9IHNvdXJjZVsgcHJvcGVydHkgXTtcblxuXHRcdFx0aWYodHlwZW9mIHNvdXJjZVByb3BlcnR5ID09PSAnb2JqZWN0Jykge1xuXHRcdFx0XHR0YXJnZXRbcHJvcGVydHldID0gbWVyZ2VPYmplY3RzKHRhcmdldFtwcm9wZXJ0eV0sIHNvdXJjZVByb3BlcnR5KTtcblx0XHRcdFx0Y29udGludWU7XG5cdFx0XHR9XG5cblx0XHRcdHRhcmdldFtwcm9wZXJ0eV0gPSBzb3VyY2VQcm9wZXJ0eTtcblx0XHR9XG5cdH1cblxuXHRmb3IodmFyIGEgPSAyLCBsID0gYXJndW1lbnRzLmxlbmd0aDsgYSA8IGw7IGErKykge1xuXHRcdG1lcmdlT2JqZWN0cyh0YXJnZXQsIGFyZ3VtZW50c1thXSk7XG5cdH1cblxuXHRyZXR1cm4gdGFyZ2V0O1xufTtcbiIsInRoaXMuZXNjYXBlUmVnRXggPSBmdW5jdGlvbiAoc3RyaW5nKSB7XG5cdHJldHVybiBzdHJpbmcucmVwbGFjZSgvKFsuKis/Xj0hOiR7fSgpfFxcW1xcXVxcL1xcXFxdKS9nLCBcIlxcXFwkMVwiKTtcbn1cblxudGhpcy5yZXBsYWNlU3Vic3RyaW5ncyA9IGZ1bmN0aW9uKHN0cmluZywgZmluZCwgcmVwbGFjZSkge1xuXHRyZXR1cm4gc3RyaW5nLnJlcGxhY2UobmV3IFJlZ0V4cChlc2NhcGVSZWdFeChmaW5kKSwgJ2cnKSwgcmVwbGFjZSk7XG59O1xuXG50aGlzLmpvaW5TdHJpbmdzID0gZnVuY3Rpb24oc3RyaW5nQXJyYXksIGpvaW4pIHtcblx0dmFyIHNlcCA9IGpvaW4gfHwgXCIsIFwiO1xuXHR2YXIgcmVzID0gXCJcIjtcblx0Xy5lYWNoKHN0cmluZ0FycmF5LCBmdW5jdGlvbihzdHIpIHtcblx0XHRpZihzdHIpIHtcblx0XHRcdGlmKHJlcylcblx0XHRcdFx0cmVzID0gcmVzICsgc2VwO1xuXHRcdFx0cmVzID0gcmVzICsgc3RyO1xuXHRcdH1cdFx0XG5cdH0pO1xuXHRyZXR1cm4gcmVzO1xufTtcblxudGhpcy5jb252ZXJ0VG9TbHVnID0gZnVuY3Rpb24odGV4dCkge1xuICByZXR1cm4gdGV4dC50b1N0cmluZygpLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvXFxzKy9nLCAnLScpICAgICAgICAgICAvLyBSZXBsYWNlIHNwYWNlcyB3aXRoIC1cbiAgICAucmVwbGFjZSgvW15cXHdcXC1dKy9nLCAnJykgICAgICAgLy8gUmVtb3ZlIGFsbCBub24td29yZCBjaGFyc1xuICAgIC5yZXBsYWNlKC9cXC1cXC0rL2csICctJykgICAgICAgICAvLyBSZXBsYWNlIG11bHRpcGxlIC0gd2l0aCBzaW5nbGUgLVxuICAgIC5yZXBsYWNlKC9eLSsvLCAnJykgICAgICAgICAgICAgLy8gVHJpbSAtIGZyb20gc3RhcnQgb2YgdGV4dFxuICAgIC5yZXBsYWNlKC8tKyQvLCAnJyk7ICAgICAgICAgICAgLy8gVHJpbSAtIGZyb20gZW5kIG9mIHRleHRcbn07XG4iLCIvKipcbiAqIENyZWF0ZWQgYnkgc2VtYnJhZG9yIG9uIDA0LzIzLzIwMTcuXG4gKi9cblxuTWV0ZW9yLmNhc3RsZVNvZnQgPSB7XG4gICAgemVyb1BhZDogZnVuY3Rpb24oIG51bSwgc2l6ZSApIHtcbiAgICAgICAgdmFyIHMgPSBudW0gKyBcIlwiO1xuICAgICAgICB3aGlsZSAoIHMubGVuZ3RoIDwgc2l6ZSApXG4gICAgICAgICAgICBzID0gXCIwXCIgKyBzO1xuICAgICAgICByZXR1cm4gcztcbiAgICB9XG59OyIsIlxuLyoqXG4gKiBDcmVhdGVkIGJ5IHNlbWJyYWRvciBvbiAwNC8yMi8yMDE3LlxuICovXG5cblRhYnVsYXJUYWJsZXMgPSB7fTtcblxuaTE4bi5zZXRMYW5ndWFnZSgnZXMnKTtcblxuTWV0ZW9yLmlzQ2xpZW50ICYmIFRlbXBsYXRlLnJlZ2lzdGVySGVscGVyKCdUYWJ1bGFyVGFibGVzJywgVGFidWxhclRhYmxlcyk7IiwiXG50aGlzLkluZm9BZ2VuZGFSeCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19hZ2VuZGFfcnhcIik7XG5cbnRoaXMuSW5mb0FnZW5kYVJ4LnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb0FnZW5kYVJ4LnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb0FnZW5kYVJ4LnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJcbnRoaXMuSW5mb0FnZW5kYVNvcCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19hZ2VuZGFfc29wXCIpO1xuXG50aGlzLkluZm9BZ2VuZGFTb3AudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvQWdlbmRhU29wLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb0FnZW5kYVNvcC51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5JbmZvQXNlZ3VyYWRvcmFzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJpbmZvX2FzZWd1cmFkb3Jhc1wiKTtcblxudGhpcy5JbmZvQXNlZ3VyYWRvcmFzLnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb0FzZWd1cmFkb3Jhcy51c2VyQ2FuVXBkYXRlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkluZm9Bc2VndXJhZG9yYXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsInRoaXMuSW5mb0NsYXNpZmljYWNpb25lcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19jbGFzaWZpY2FjaW9uZXNcIik7XG5cbnRoaXMuSW5mb0NsYXNpZmljYWNpb25lcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkluZm9DbGFzaWZpY2FjaW9uZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvQ2xhc2lmaWNhY2lvbmVzLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLkluZm9EZXBhcnRhbWVudG9zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJpbmZvX2RlcGFydGFtZW50b3NcIik7XG5cbnRoaXMuSW5mb0RlcGFydGFtZW50b3MudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvRGVwYXJ0YW1lbnRvcy51c2VyQ2FuVXBkYXRlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkluZm9EZXBhcnRhbWVudG9zLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLkluZm9Fc3BlY2lhbGlkYWRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19lc3BlY2lhbGlkYWRlc1wiKTtcblxudGhpcy5JbmZvRXNwZWNpYWxpZGFkZXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvRXNwZWNpYWxpZGFkZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvRXNwZWNpYWxpZGFkZXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsInRoaXMuSW5mb1BhY2llbnRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19wYWNpZW50ZXNcIik7XG5cbnRoaXMuSW5mb1BhY2llbnRlcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkluZm9QYWNpZW50ZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvUGFjaWVudGVzLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLkluZm9QbGFuZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcImluZm9fcGxhbmVzXCIpO1xuXG50aGlzLkluZm9QbGFuZXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvUGxhbmVzLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb1BsYW5lcy51c2VyQ2FuUmVtb3ZlID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuIiwidGhpcy5JbmZvUHJvY2VkaW1pZW50b3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcImluZm9fcHJvY2VkaW1pZW50b3NcIik7XG5cbnRoaXMuSW5mb1Byb2NlZGltaWVudG9zLnVzZXJDYW5JbnNlcnQgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb1Byb2NlZGltaWVudG9zLnVzZXJDYW5VcGRhdGUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG5cbnRoaXMuSW5mb1Byb2NlZGltaWVudG9zLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJ0aGlzLkluZm9SZWZlcmlkb3JlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19yZWZlcmlkb3Jlc1wiKTtcblxudGhpcy5JbmZvUmVmZXJpZG9yZXMudXNlckNhbkluc2VydCA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvUmVmZXJpZG9yZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvUmVmZXJpZG9yZXMudXNlckNhblJlbW92ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcbiIsInRoaXMuSW5mb1NlY2Npb25lcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiaW5mb19zZWNjaW9uZXNcIik7XG5cbnRoaXMuSW5mb1NlY2Npb25lcy51c2VyQ2FuSW5zZXJ0ID0gZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0cmV0dXJuIHRydWU7XG59O1xuXG50aGlzLkluZm9TZWNjaW9uZXMudXNlckNhblVwZGF0ZSA9IGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdHJldHVybiB0cnVlO1xufTtcblxudGhpcy5JbmZvU2VjY2lvbmVzLnVzZXJDYW5SZW1vdmUgPSBmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRyZXR1cm4gdHJ1ZTtcbn07XG4iLCJcbi8qKlxuICogQGF1dGhvciBMZWFuZHJvIENhbWHDsW8gR3VlcnJlcm9cbiAqIEBlbWFpbCBkZXZlbG9wZXJAY2FzdGxlLXNvZnQuY29tXG4gKiBAY3JlYXRlIGRhdGUgMjAxOC0wNC0wMiAwOTo1NDo0MFxuICogQG1vZGlmeSBkYXRlIDIwMTgtMDQtMDIgMDk6NTQ6NDBcbiAqIEBkZXNjIEFnZW5kYSBSeCBkb2MgZGVmaW5pdGlvbiAtIGphdmFzY3JpcHRcbiovXG5cbkluZm9BZ2VuZGFSeC5hbGxvdyh7XG4gICAgaW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgdXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgcmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn0pO1xuXG5JbmZvQWdlbmRhUnguYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuICAgIGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuICAgIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG4gICAgZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuICAgIGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcbiAgICBpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5JbmZvQWdlbmRhUnguYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcbiAgICBtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcbiAgICBtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuICAgIG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5JbmZvQWdlbmRhUnguYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuICAgIG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuICAgIG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgbW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9BZ2VuZGFSeC5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7fSk7XG5cbkluZm9BZ2VuZGFSeC5hZnRlci5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHt9KTtcblxuSW5mb0FnZW5kYVJ4LmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHt9KTtcblxuSW5mb0FnZW5kYVJ4LmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge30pO1xuIiwiXG4vKipcbiAqIEBhdXRob3IgTGVhbmRybyBDYW1hw7FvIEd1ZXJyZXJvXG4gKiBAZW1haWwgZGV2ZWxvcGVyQGNhc3RsZS1zb2Z0LmNvbVxuICogQGNyZWF0ZSBkYXRlIDIwMTgtMDQtMDIgMDk6NTQ6NDBcbiAqIEBtb2RpZnkgZGF0ZSAyMDE4LTA0LTAyIDA5OjU0OjQwXG4gKiBAZGVzYyBBZ2VuZGEgU09QIGRvYyBkZWZpbml0aW9uIC0gamF2YXNjcmlwdFxuKi9cblxuSW5mb0FnZW5kYVNvcC5hbGxvdyh7XG4gICAgaW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgdXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgcmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn0pO1xuXG5JbmZvQWdlbmRhU29wLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcbiAgICBkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcbiAgICBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuICAgIGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcbiAgICBkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG4gICAgaWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuSW5mb0FnZW5kYVNvcC5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuICAgIG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuICAgIG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgbW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9BZ2VuZGFTb3AuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuICAgIG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuICAgIG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgbW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9BZ2VuZGFTb3AuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge30pO1xuXG5JbmZvQWdlbmRhU29wLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge30pO1xuXG5JbmZvQWdlbmRhU29wLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHt9KTtcblxuSW5mb0FnZW5kYVNvcC5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHt9KTtcbiIsIkluZm9Bc2VndXJhZG9yYXMuYWxsb3coe1xuXHRpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHR1cGRhdGU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHRyZW1vdmU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufSk7XG5cbkluZm9Bc2VndXJhZG9yYXMuYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9Bc2VndXJhZG9yYXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5JbmZvQXNlZ3VyYWRvcmFzLmJlZm9yZS51cHNlcnQoZnVuY3Rpb24odXNlcklkLCBzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHQvKkJFRk9SRV9VUFNFUlRfQ09ERSovXG59KTtcblxuSW5mb0FzZWd1cmFkb3Jhcy5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9Bc2VndXJhZG9yYXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9Bc2VndXJhZG9yYXMuYWZ0ZXIudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRcbn0pO1xuXG5JbmZvQXNlZ3VyYWRvcmFzLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiSW5mb0NsYXNpZmljYWNpb25lcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuSW5mb0NsYXNpZmljYWNpb25lcy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuXHRkb2MubW9kaWZpZWRBdCA9IGRvYy5jcmVhdGVkQXQ7XG5cdGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcblxuXHRcblx0aWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuSW5mb0NsYXNpZmljYWNpb25lcy5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdFxufSk7XG5cbkluZm9DbGFzaWZpY2FjaW9uZXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5JbmZvQ2xhc2lmaWNhY2lvbmVzLmJlZm9yZS5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuSW5mb0NsYXNpZmljYWNpb25lcy5hZnRlci5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuSW5mb0NsYXNpZmljYWNpb25lcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkluZm9DbGFzaWZpY2FjaW9uZXMuYWZ0ZXIucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG4iLCJJbmZvRGVwYXJ0YW1lbnRvcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuSW5mb0RlcGFydGFtZW50b3MuYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9EZXBhcnRhbWVudG9zLmJlZm9yZS51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0XG59KTtcblxuSW5mb0RlcGFydGFtZW50b3MuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5JbmZvRGVwYXJ0YW1lbnRvcy5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9EZXBhcnRhbWVudG9zLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5JbmZvRGVwYXJ0YW1lbnRvcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkluZm9EZXBhcnRhbWVudG9zLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiSW5mb0VzcGVjaWFsaWRhZGVzLmFsbG93KHtcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0dXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0cmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn0pO1xuXG5JbmZvRXNwZWNpYWxpZGFkZXMuYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9Fc3BlY2lhbGlkYWRlcy5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdFxufSk7XG5cbkluZm9Fc3BlY2lhbGlkYWRlcy5iZWZvcmUudXBzZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0LypCRUZPUkVfVVBTRVJUX0NPREUqL1xufSk7XG5cbkluZm9Fc3BlY2lhbGlkYWRlcy5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9Fc3BlY2lhbGlkYWRlcy5hZnRlci5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuSW5mb0VzcGVjaWFsaWRhZGVzLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0XG59KTtcblxuSW5mb0VzcGVjaWFsaWRhZGVzLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiSW5mb1BhY2llbnRlcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuSW5mb1BhY2llbnRlcy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGRvYy5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xuXHRkb2MubW9kaWZpZWRBdCA9IGRvYy5jcmVhdGVkQXQ7XG5cdGRvYy5tb2RpZmllZEJ5ID0gZG9jLmNyZWF0ZWRCeTtcblxuXHRcblx0aWYoIWRvYy5jcmVhdGVkQnkpIGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG59KTtcblxuSW5mb1BhY2llbnRlcy5iZWZvcmUudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdFxufSk7XG5cbkluZm9QYWNpZW50ZXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5JbmZvUGFjaWVudGVzLmJlZm9yZS5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuSW5mb1BhY2llbnRlcy5hZnRlci5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcblxuSW5mb1BhY2llbnRlcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkluZm9QYWNpZW50ZXMuYWZ0ZXIucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG4iLCJJbmZvUGxhbmVzLmFsbG93KHtcblx0aW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0dXBkYXRlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH0sXG5cblx0cmVtb3ZlOiBmdW5jdGlvbiAodXNlcklkLCBkb2MpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn0pO1xuXG5JbmZvUGxhbmVzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5JbmZvUGxhbmVzLmJlZm9yZS51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0XG59KTtcblxuSW5mb1BsYW5lcy5iZWZvcmUudXBzZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdG1vZGlmaWVyLiRzZXQgPSBtb2RpZmllci4kc2V0IHx8IHt9O1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQXQgPSBuZXcgRGF0ZSgpO1xuXHRtb2RpZmllci4kc2V0Lm1vZGlmaWVkQnkgPSB1c2VySWQ7XG5cblx0LypCRUZPUkVfVVBTRVJUX0NPREUqL1xufSk7XG5cbkluZm9QbGFuZXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5JbmZvUGxhbmVzLmFmdGVyLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5JbmZvUGxhbmVzLmFmdGVyLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0XG59KTtcblxuSW5mb1BsYW5lcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIkluZm9Qcm9jZWRpbWllbnRvcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuSW5mb1Byb2NlZGltaWVudG9zLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5JbmZvUHJvY2VkaW1pZW50b3MuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5JbmZvUHJvY2VkaW1pZW50b3MuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5JbmZvUHJvY2VkaW1pZW50b3MuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5JbmZvUHJvY2VkaW1pZW50b3MuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9Qcm9jZWRpbWllbnRvcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkluZm9Qcm9jZWRpbWllbnRvcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIkluZm9SZWZlcmlkb3Jlcy5hbGxvdyh7XG5cdGluc2VydDogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHVwZGF0ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jLCBmaWVsZHMsIG1vZGlmaWVyKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9LFxuXG5cdHJlbW92ZTogZnVuY3Rpb24gKHVzZXJJZCwgZG9jKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59KTtcblxuSW5mb1JlZmVyaWRvcmVzLmJlZm9yZS5pbnNlcnQoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0ZG9jLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG5cdGRvYy5jcmVhdGVkQnkgPSB1c2VySWQ7XG5cdGRvYy5tb2RpZmllZEF0ID0gZG9jLmNyZWF0ZWRBdDtcblx0ZG9jLm1vZGlmaWVkQnkgPSBkb2MuY3JlYXRlZEJ5O1xuXG5cdFxuXHRpZighZG9jLmNyZWF0ZWRCeSkgZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcbn0pO1xuXG5JbmZvUmVmZXJpZG9yZXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5JbmZvUmVmZXJpZG9yZXMuYmVmb3JlLnVwc2VydChmdW5jdGlvbih1c2VySWQsIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRtb2RpZmllci4kc2V0ID0gbW9kaWZpZXIuJHNldCB8fCB7fTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEF0ID0gbmV3IERhdGUoKTtcblx0bW9kaWZpZXIuJHNldC5tb2RpZmllZEJ5ID0gdXNlcklkO1xuXG5cdC8qQkVGT1JFX1VQU0VSVF9DT0RFKi9cbn0pO1xuXG5JbmZvUmVmZXJpZG9yZXMuYmVmb3JlLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuXG5JbmZvUmVmZXJpZG9yZXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9SZWZlcmlkb3Jlcy5hZnRlci51cGRhdGUoZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkTmFtZXMsIG1vZGlmaWVyLCBvcHRpb25zKSB7XG5cdFxufSk7XG5cbkluZm9SZWZlcmlkb3Jlcy5hZnRlci5yZW1vdmUoZnVuY3Rpb24odXNlcklkLCBkb2MpIHtcblx0XG59KTtcbiIsIkluZm9TZWNjaW9uZXMuYWxsb3coe1xuXHRpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHR1cGRhdGU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYywgZmllbGRzLCBtb2RpZmllcikge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fSxcblxuXHRyZW1vdmU6IGZ1bmN0aW9uICh1c2VySWQsIGRvYykge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufSk7XG5cbkluZm9TZWNjaW9uZXMuYmVmb3JlLmluc2VydChmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRkb2MuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcblx0ZG9jLmNyZWF0ZWRCeSA9IHVzZXJJZDtcblx0ZG9jLm1vZGlmaWVkQXQgPSBkb2MuY3JlYXRlZEF0O1xuXHRkb2MubW9kaWZpZWRCeSA9IGRvYy5jcmVhdGVkQnk7XG5cblx0XG5cdGlmKCFkb2MuY3JlYXRlZEJ5KSBkb2MuY3JlYXRlZEJ5ID0gdXNlcklkO1xufSk7XG5cbkluZm9TZWNjaW9uZXMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHRcbn0pO1xuXG5JbmZvU2VjY2lvbmVzLmJlZm9yZS51cHNlcnQoZnVuY3Rpb24odXNlcklkLCBzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0bW9kaWZpZXIuJHNldCA9IG1vZGlmaWVyLiRzZXQgfHwge307XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRBdCA9IG5ldyBEYXRlKCk7XG5cdG1vZGlmaWVyLiRzZXQubW9kaWZpZWRCeSA9IHVzZXJJZDtcblxuXHQvKkJFRk9SRV9VUFNFUlRfQ09ERSovXG59KTtcblxuSW5mb1NlY2Npb25lcy5iZWZvcmUucmVtb3ZlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9TZWNjaW9uZXMuYWZ0ZXIuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdFxufSk7XG5cbkluZm9TZWNjaW9uZXMuYWZ0ZXIudXBkYXRlKGZ1bmN0aW9uKHVzZXJJZCwgZG9jLCBmaWVsZE5hbWVzLCBtb2RpZmllciwgb3B0aW9ucykge1xuXHRcbn0pO1xuXG5JbmZvU2VjY2lvbmVzLmFmdGVyLnJlbW92ZShmdW5jdGlvbih1c2VySWQsIGRvYykge1xuXHRcbn0pO1xuIiwiUm91dGVyLm1hcChmdW5jdGlvbiAoKSB7XG5cbn0pO1xuIiwiXG4vKipcbiAqIEBhdXRob3IgTGVhbmRybyBDYW1hw7FvIEd1ZXJyZXJvXG4gKiBAZW1haWwgZGV2ZWxvcGVyQGNhc3RsZS1zb2Z0LmNvbVxuICogQGNyZWF0ZSBkYXRlIDIwMTgtMDQtMDIgMDk6NTk6MzFcbiAqIEBtb2RpZnkgZGF0ZSAyMDE4LTA0LTAyIDA5OjU5OjMxXG4gKiBAZGVzYyBBZ2VuZGEgUnggbWV0aG9kcyAtIGphdmFzY3JpcHRcbiovXG5cbk1ldGVvci5tZXRob2RzKHtcblx0XCJpbmZvQWdlbmRhUnhJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGNoZWNrKGRhdGEsIHtcblx0XHRcdHRpdGxlOiBTdHJpbmcsXG5cdFx0XHRzdGFydDogU3RyaW5nLFxuXHRcdFx0ZW5kOiBTdHJpbmcsXG5cdFx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0XHRndWVzdHM6IE51bWJlclxuXHRcdH0pO1xuXHRcdGlmKCFJbmZvQWdlbmRhUngudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlBST0hJQklETy5cIik7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBJbmZvQWdlbmRhUnguaW5zZXJ0KGRhdGEpO1xuXHRcdFx0fSBjYXRjaCAoZXhjZXB0aW9uKSB7XG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCAnJyArIGV4Y2VwdGlvbik7XG5cdFx0XHR9XG5cdFx0fVxuXHR9LFxuXHRcImluZm9BZ2VuZGFSeFVwZGF0ZVwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0Y2hlY2soZGF0YSwge1xuXHRcdFx0X2lkOiBTdHJpbmcsXG5cdFx0XHR0aXRsZTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcblx0XHRcdHN0YXJ0OiBTdHJpbmcsXG5cdFx0XHRlbmQ6IFN0cmluZyxcblx0XHRcdHR5cGU6IE1hdGNoLk9wdGlvbmFsKFN0cmluZyksXG5cdFx0XHRndWVzdHM6IE1hdGNoLk9wdGlvbmFsKE51bWJlcilcblx0XHR9KTtcblx0XHR2YXIgZG9jID0gSW5mb0FnZW5kYVJ4LmZpbmRPbmUoeyBfaWQ6IGRhdGEuX2lkIH0pO1xuXHRcdGlmKCFJbmZvQWdlbmRhUngudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiUFJPSElCSURPLlwiKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cmV0dXJuIEluZm9BZ2VuZGFSeC51cGRhdGUoeyBfaWQ6IGRhdGEuX2lkIH0sIHsgJHNldDogZGF0YSB9KTtcblx0XHRcdH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJycgKyBleGNlcHRpb24pO1xuXHRcdFx0fVxuXHRcdH1cblx0fSxcblx0XCJpbmZvQWdlbmRhUnhSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcbiAgICAgICAgY2hlY2soaWQsIFN0cmluZyk7XG5cdFx0dmFyIGRvYyA9IEluZm9BZ2VuZGFSeC5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb0FnZW5kYVJ4LnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlBST0hJQklETy5cIik7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBJbmZvQWdlbmRhUngucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0XHRcdH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJycgKyBleGNlcHRpb24pO1xuXHRcdFx0fVxuXHRcdH1cdFx0XG5cdH1cbn0pO1xuIiwiXG4vKipcbiAqIEBhdXRob3IgTGVhbmRybyBDYW1hw7FvIEd1ZXJyZXJvXG4gKiBAZW1haWwgZGV2ZWxvcGVyQGNhc3RsZS1zb2Z0LmNvbVxuICogQGNyZWF0ZSBkYXRlIDIwMTgtMDQtMDIgMDk6NTk6MzFcbiAqIEBtb2RpZnkgZGF0ZSAyMDE4LTA0LTAyIDA5OjU5OjMxXG4gKiBAZGVzYyBBZ2VuZGEgU29wIG1ldGhvZHMgLSBqYXZhc2NyaXB0XG4qL1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cdFwiaW5mb0FnZW5kYVNvcEluc2VydFwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0Y2hlY2soZGF0YSwge1xuXHRcdFx0dGl0bGU6IFN0cmluZyxcblx0XHRcdHN0YXJ0OiBTdHJpbmcsXG5cdFx0XHRlbmQ6IFN0cmluZyxcblx0XHRcdHR5cGU6IFN0cmluZyxcblx0XHRcdGd1ZXN0czogTnVtYmVyXG5cdFx0fSk7XG5cdFx0aWYoIUluZm9BZ2VuZGFTb3AudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlBST0hJQklETy5cIik7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBJbmZvQWdlbmRhU29wLmluc2VydChkYXRhKTtcblx0XHRcdH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJycgKyBleGNlcHRpb24pO1xuXHRcdFx0fVxuXHRcdH1cblx0fSxcblx0XCJpbmZvQWdlbmRhU29wVXBkYXRlXCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRjaGVjayhkYXRhLCB7XG5cdFx0XHRfaWQ6IFN0cmluZyxcblx0XHRcdHRpdGxlOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuXHRcdFx0c3RhcnQ6IFN0cmluZyxcblx0XHRcdGVuZDogU3RyaW5nLFxuXHRcdFx0dHlwZTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcblx0XHRcdGd1ZXN0czogTWF0Y2guT3B0aW9uYWwoTnVtYmVyKVxuXHRcdH0pO1xuXHRcdHZhciBkb2MgPSBJbmZvQWdlbmRhU29wLmZpbmRPbmUoeyBfaWQ6IGRhdGEuX2lkIH0pO1xuXHRcdGlmKCFJbmZvQWdlbmRhU29wLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIlBST0hJQklETy5cIik7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBJbmZvQWdlbmRhU29wLnVwZGF0ZSh7IF9pZDogZGF0YS5faWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHRcdFx0fSBjYXRjaCAoZXhjZXB0aW9uKSB7XG5cdFx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCAnJyArIGV4Y2VwdGlvbik7XG5cdFx0XHR9XG5cdFx0fVxuXHR9LFxuXHRcImluZm9BZ2VuZGFTb3BSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcbiAgICAgICAgY2hlY2soaWQsIFN0cmluZyk7XG5cdFx0dmFyIGRvYyA9IEluZm9BZ2VuZGFTb3AuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9BZ2VuZGFTb3AudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiUFJPSElCSURPLlwiKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cmV0dXJuIEluZm9BZ2VuZGFTb3AucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0XHRcdH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuXHRcdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJycgKyBleGNlcHRpb24pO1xuXHRcdFx0fVxuXHRcdH1cdFx0XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9Bc2VndXJhZG9yYXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFJbmZvQXNlZ3VyYWRvcmFzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBJbmZvQXNlZ3VyYWRvcmFzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9Bc2VndXJhZG9yYXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gSW5mb0FzZWd1cmFkb3Jhcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb0FzZWd1cmFkb3Jhcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9Bc2VndXJhZG9yYXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJpbmZvQXNlZ3VyYWRvcmFzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9Bc2VndXJhZG9yYXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9Bc2VndXJhZG9yYXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvQXNlZ3VyYWRvcmFzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9DbGFzaWZpY2FjaW9uZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFJbmZvQ2xhc2lmaWNhY2lvbmVzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBJbmZvQ2xhc2lmaWNhY2lvbmVzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9DbGFzaWZpY2FjaW9uZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gSW5mb0NsYXNpZmljYWNpb25lcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb0NsYXNpZmljYWNpb25lcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9DbGFzaWZpY2FjaW9uZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJpbmZvQ2xhc2lmaWNhY2lvbmVzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9DbGFzaWZpY2FjaW9uZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9DbGFzaWZpY2FjaW9uZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvQ2xhc2lmaWNhY2lvbmVzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9EZXBhcnRhbWVudG9zSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighSW5mb0RlcGFydGFtZW50b3MudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIEluZm9EZXBhcnRhbWVudG9zLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9EZXBhcnRhbWVudG9zVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9EZXBhcnRhbWVudG9zLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFJbmZvRGVwYXJ0YW1lbnRvcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9EZXBhcnRhbWVudG9zLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwiaW5mb0RlcGFydGFtZW50b3NSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gSW5mb0RlcGFydGFtZW50b3MuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9EZXBhcnRhbWVudG9zLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0SW5mb0RlcGFydGFtZW50b3MucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG5cdFwiaW5mb0VzcGVjaWFsaWRhZGVzSW5zZXJ0XCI6IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRpZighSW5mb0VzcGVjaWFsaWRhZGVzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBJbmZvRXNwZWNpYWxpZGFkZXMuaW5zZXJ0KGRhdGEpO1xuXHR9LFxuXG5cdFwiaW5mb0VzcGVjaWFsaWRhZGVzVXBkYXRlXCI6IGZ1bmN0aW9uKGlkLCBkYXRhKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9Fc3BlY2lhbGlkYWRlcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb0VzcGVjaWFsaWRhZGVzLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0SW5mb0VzcGVjaWFsaWRhZGVzLnVwZGF0ZSh7IF9pZDogaWQgfSwgeyAkc2V0OiBkYXRhIH0pO1xuXHR9LFxuXG5cdFwiaW5mb0VzcGVjaWFsaWRhZGVzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9Fc3BlY2lhbGlkYWRlcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb0VzcGVjaWFsaWRhZGVzLnVzZXJDYW5SZW1vdmUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0SW5mb0VzcGVjaWFsaWRhZGVzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9QYWNpZW50ZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFJbmZvUGFjaWVudGVzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBJbmZvUGFjaWVudGVzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9QYWNpZW50ZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gSW5mb1BhY2llbnRlcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb1BhY2llbnRlcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9QYWNpZW50ZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJpbmZvUGFjaWVudGVzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9QYWNpZW50ZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9QYWNpZW50ZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvUGFjaWVudGVzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9QbGFuZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFJbmZvUGxhbmVzLnVzZXJDYW5JbnNlcnQodGhpcy51c2VySWQsIGRhdGEpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdHJldHVybiBJbmZvUGxhbmVzLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9QbGFuZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gSW5mb1BsYW5lcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb1BsYW5lcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9QbGFuZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJpbmZvUGxhbmVzUmVtb3ZlXCI6IGZ1bmN0aW9uKGlkKSB7XG5cdFx0dmFyIGRvYyA9IEluZm9QbGFuZXMuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9QbGFuZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvUGxhbmVzLnJlbW92ZSh7IF9pZDogaWQgfSk7XG5cdH1cbn0pO1xuIiwiTWV0ZW9yLm1ldGhvZHMoe1xuXHRcImluZm9Qcm9jZWRpbWllbnRvc0luc2VydFwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0aWYoIUluZm9Qcm9jZWRpbWllbnRvcy51c2VyQ2FuSW5zZXJ0KHRoaXMudXNlcklkLCBkYXRhKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRyZXR1cm4gSW5mb1Byb2NlZGltaWVudG9zLmluc2VydChkYXRhKTtcblx0fSxcblxuXHRcImluZm9Qcm9jZWRpbWllbnRvc1VwZGF0ZVwiOiBmdW5jdGlvbihpZCwgZGF0YSkge1xuXHRcdHZhciBkb2MgPSBJbmZvUHJvY2VkaW1pZW50b3MuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9Qcm9jZWRpbWllbnRvcy51c2VyQ2FuVXBkYXRlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9Qcm9jZWRpbWllbnRvcy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogZGF0YSB9KTtcblx0fSxcblxuXHRcImluZm9Qcm9jZWRpbWllbnRvc1JlbW92ZVwiOiBmdW5jdGlvbihpZCkge1xuXHRcdHZhciBkb2MgPSBJbmZvUHJvY2VkaW1pZW50b3MuZmluZE9uZSh7IF9pZDogaWQgfSk7XG5cdFx0aWYoIUluZm9Qcm9jZWRpbWllbnRvcy51c2VyQ2FuUmVtb3ZlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9Qcm9jZWRpbWllbnRvcy5yZW1vdmUoeyBfaWQ6IGlkIH0pO1xuXHR9XG59KTtcbiIsIk1ldGVvci5tZXRob2RzKHtcblx0XCJpbmZvUmVmZXJpZG9yZXNJbnNlcnRcIjogZnVuY3Rpb24oZGF0YSkge1xuXHRcdGlmKCFJbmZvUmVmZXJpZG9yZXMudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIEluZm9SZWZlcmlkb3Jlcy5pbnNlcnQoZGF0YSk7XG5cdH0sXG5cblx0XCJpbmZvUmVmZXJpZG9yZXNVcGRhdGVcIjogZnVuY3Rpb24oaWQsIGRhdGEpIHtcblx0XHR2YXIgZG9jID0gSW5mb1JlZmVyaWRvcmVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFJbmZvUmVmZXJpZG9yZXMudXNlckNhblVwZGF0ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvUmVmZXJpZG9yZXMudXBkYXRlKHsgX2lkOiBpZCB9LCB7ICRzZXQ6IGRhdGEgfSk7XG5cdH0sXG5cblx0XCJpbmZvUmVmZXJpZG9yZXNSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gSW5mb1JlZmVyaWRvcmVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFJbmZvUmVmZXJpZG9yZXMudXNlckNhblJlbW92ZSh0aGlzLnVzZXJJZCwgZG9jKSkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiRm9yYmlkZGVuLlwiKTtcblx0XHR9XG5cblx0XHRJbmZvUmVmZXJpZG9yZXMucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJNZXRlb3IubWV0aG9kcyh7XG5cdFwiaW5mb1NlY2Npb25lc0luc2VydFwiOiBmdW5jdGlvbihkYXRhKSB7XG5cdFx0aWYoIUluZm9TZWNjaW9uZXMudXNlckNhbkluc2VydCh0aGlzLnVzZXJJZCwgZGF0YSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIEluZm9TZWNjaW9uZXMuaW5zZXJ0KGRhdGEpO1xuXHR9LFxuXG5cdFwiaW5mb1NlY2Npb25lc1VwZGF0ZVwiOiBmdW5jdGlvbihpZCwgZGF0YSkge1xuXHRcdHZhciBkb2MgPSBJbmZvU2VjY2lvbmVzLmZpbmRPbmUoeyBfaWQ6IGlkIH0pO1xuXHRcdGlmKCFJbmZvU2VjY2lvbmVzLnVzZXJDYW5VcGRhdGUodGhpcy51c2VySWQsIGRvYykpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkZvcmJpZGRlbi5cIik7XG5cdFx0fVxuXG5cdFx0SW5mb1NlY2Npb25lcy51cGRhdGUoeyBfaWQ6IGlkIH0sIHsgJHNldDogZGF0YSB9KTtcblx0fSxcblxuXHRcImluZm9TZWNjaW9uZXNSZW1vdmVcIjogZnVuY3Rpb24oaWQpIHtcblx0XHR2YXIgZG9jID0gSW5mb1NlY2Npb25lcy5maW5kT25lKHsgX2lkOiBpZCB9KTtcblx0XHRpZighSW5mb1NlY2Npb25lcy51c2VyQ2FuUmVtb3ZlKHRoaXMudXNlcklkLCBkb2MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJGb3JiaWRkZW4uXCIpO1xuXHRcdH1cblxuXHRcdEluZm9TZWNjaW9uZXMucmVtb3ZlKHsgX2lkOiBpZCB9KTtcblx0fVxufSk7XG4iLCJcbi8qKlxuICogQGF1dGhvciBMZWFuZHJvIENhbWHDsW8gR3VlcnJlcm9cbiAqIEBlbWFpbCBkZXZlbG9wZXJAY2FzdGxlLXNvZnQuY29tXG4gKiBAY3JlYXRlIGRhdGUgMjAxOC0wNC0wMiAxMTowODoyOVxuICogQG1vZGlmeSBkYXRlIDIwMTgtMDQtMDIgMTE6MDg6MjlcbiAqIEBkZXNjIEFnZW5kYSBSeCBwdWJsaXNoIGZ1bmN0aW9ucyAtIGphdmFzY3JpcHRcbiovXG5cbk1ldGVvci5wdWJsaXNoKFwiaW5mb19hZ2VuZGFfcnhfbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9BZ2VuZGFSeC5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJpbmZvX2FnZW5kYV9yeF9udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb0FnZW5kYVJ4LmZpbmQoe19pZDpudWxsfSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiaW5mb19hZ2VuZGFfcnhcIiwgZnVuY3Rpb24oaW5mb0V2ZW50UnhJZCkge1xuXHRyZXR1cm4gSW5mb0FnZW5kYVJ4LmZpbmQoe19pZDppbmZvRXZlbnRSeElkfSwge30pO1xufSk7XG4iLCJcbi8qKlxuICogQGF1dGhvciBMZWFuZHJvIENhbWHDsW8gR3VlcnJlcm9cbiAqIEBlbWFpbCBkZXZlbG9wZXJAY2FzdGxlLXNvZnQuY29tXG4gKiBAY3JlYXRlIGRhdGUgMjAxOC0wNC0wMiAxMTowODoyOVxuICogQG1vZGlmeSBkYXRlIDIwMTgtMDQtMDIgMTE6MDg6MjlcbiAqIEBkZXNjIEFnZW5kYSBTb3AgcHVibGlzaCBmdW5jdGlvbnMgLSBqYXZhc2NyaXB0XG4qL1xuXG5NZXRlb3IucHVibGlzaChcImluZm9fYWdlbmRhX1NvcF9saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb0FnZW5kYVNvcC5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJpbmZvX2FnZW5kYV9Tb3BfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9BZ2VuZGFTb3AuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJpbmZvX2FnZW5kYV9Tb3BcIiwgZnVuY3Rpb24oaW5mb0V2ZW50U29wSWQpIHtcblx0cmV0dXJuIEluZm9BZ2VuZGFTb3AuZmluZCh7X2lkOmluZm9FdmVudFNvcElkfSwge30pO1xufSk7XG4iLCJNZXRlb3IucHVibGlzaChcImFzZWd1cmFkb3JhX2xpc3RcIiwgZnVuY3Rpb24oKSB7XG5cdHJldHVybiBJbmZvQXNlZ3VyYWRvcmFzLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImFzZWd1cmFkb3Jhc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb0FzZWd1cmFkb3Jhcy5maW5kKHtfaWQ6bnVsbH0sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImFzZWd1cmFkb3JhXCIsIGZ1bmN0aW9uKGFzZWd1cmFkb3JhSWQpIHtcblx0cmV0dXJuIEluZm9Bc2VndXJhZG9yYXMuZmluZCh7X2lkOmFzZWd1cmFkb3JhSWR9LCB7fSk7XG59KTtcblxuIiwiTWV0ZW9yLnB1Ymxpc2goXCJjbGFzaWZpY2FjaW9uX2xpc3RcIiwgZnVuY3Rpb24oKSB7XG5cdHJldHVybiBJbmZvQ2xhc2lmaWNhY2lvbmVzLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImNsYXNpZmljYWNpb25lc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb0NsYXNpZmljYWNpb25lcy5maW5kKHtfaWQ6bnVsbH0sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImNsYXNpZmljYWNpb25cIiwgZnVuY3Rpb24oY2xhc2lmaWNhY2lvbklkKSB7XG5cdHJldHVybiBJbmZvQ2xhc2lmaWNhY2lvbmVzLmZpbmQoe19pZDpjbGFzaWZpY2FjaW9uSWR9LCB7fSk7XG59KTtcblxuIiwiTWV0ZW9yLnB1Ymxpc2goXCJkZXBhcnRhbWVudG9fbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9EZXBhcnRhbWVudG9zLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcImRlcGFydGFtZW50b3NfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9EZXBhcnRhbWVudG9zLmZpbmQoe19pZDpudWxsfSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiZGVwYXJ0YW1lbnRvXCIsIGZ1bmN0aW9uKGRlcGFydGFtZW50b0lkKSB7XG5cdHJldHVybiBJbmZvRGVwYXJ0YW1lbnRvcy5maW5kKHtfaWQ6ZGVwYXJ0YW1lbnRvSWR9LCB7fSk7XG59KTtcblxuIiwiTWV0ZW9yLnB1Ymxpc2goXCJlc3BlY2lhbGlkYWRfbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9Fc3BlY2lhbGlkYWRlcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJlc3BlY2lhbGlkYWRlc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb0VzcGVjaWFsaWRhZGVzLmZpbmQoe19pZDpudWxsfSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwiZXNwZWNpYWxpZGFkXCIsIGZ1bmN0aW9uKGVzcGVjaWFsaWRhZElkKSB7XG5cdHJldHVybiBJbmZvRXNwZWNpYWxpZGFkZXMuZmluZCh7X2lkOmVzcGVjaWFsaWRhZElkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwicGFjaWVudGVzXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1BhY2llbnRlcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwYWNpZW50ZV9saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1BhY2llbnRlcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwYWNpZW50ZXNfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9QYWNpZW50ZXMuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwYWNpZW50ZVwiLCBmdW5jdGlvbihwYWNpZW50ZUlkKSB7XG5cdHJldHVybiBJbmZvUGFjaWVudGVzLmZpbmQoe19pZDpwYWNpZW50ZUlkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwicGxhbl9saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1BsYW5lcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwbGFuZXNfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9QbGFuZXMuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwbGFuXCIsIGZ1bmN0aW9uKHBsYW5JZCkge1xuXHRyZXR1cm4gSW5mb1BsYW5lcy5maW5kKHtfaWQ6cGxhbklkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwicHJvY2VkaW1pZW50b19saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1Byb2NlZGltaWVudG9zLmZpbmQoe30sIHt9KTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInByb2NlZGltaWVudG9zX251bGxcIiwgZnVuY3Rpb24oKSB7XG5cdHJldHVybiBJbmZvUHJvY2VkaW1pZW50b3MuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJwcm9jZWRpbWllbnRvXCIsIGZ1bmN0aW9uKHByb2NlZGltaWVudG9JZCkge1xuXHRyZXR1cm4gSW5mb1Byb2NlZGltaWVudG9zLmZpbmQoe19pZDpwcm9jZWRpbWllbnRvSWR9LCB7fSk7XG59KTtcblxuIiwiTWV0ZW9yLnB1Ymxpc2goXCJyZWZlcmlkb3JfbGlzdFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9SZWZlcmlkb3Jlcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJyZWZlcmlkb3Jlc19udWxsXCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1JlZmVyaWRvcmVzLmZpbmQoe19pZDpudWxsfSwge30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKFwicmVmZXJpZG9yXCIsIGZ1bmN0aW9uKHJlZmVyaWRvcklkKSB7XG5cdHJldHVybiBJbmZvUmVmZXJpZG9yZXMuZmluZCh7X2lkOnJlZmVyaWRvcklkfSwge30pO1xufSk7XG5cbiIsIk1ldGVvci5wdWJsaXNoKFwic2VjY2lvbl9saXN0XCIsIGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gSW5mb1NlY2Npb25lcy5maW5kKHt9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJzZWNjaW9uZXNfbnVsbFwiLCBmdW5jdGlvbigpIHtcblx0cmV0dXJuIEluZm9TZWNjaW9uZXMuZmluZCh7X2lkOm51bGx9LCB7fSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goXCJzZWNjaW9uXCIsIGZ1bmN0aW9uKHNlY2Npb25JZCkge1xuXHRyZXR1cm4gSW5mb1NlY2Npb25lcy5maW5kKHtfaWQ6c2VjY2lvbklkfSwge30pO1xufSk7XG5cbiIsInZhciB2ZXJpZnlFbWFpbCA9IHRydWU7XG5cbkFjY291bnRzLmNvbmZpZyh7IHNlbmRWZXJpZmljYXRpb25FbWFpbDogdmVyaWZ5RW1haWwgfSk7XG5cbkFjY291bnRzLmVtYWlsVGVtcGxhdGVzLnNpdGVOYW1lID0gJ0NNTS1XZWInO1xuQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuZnJvbSA9ICdDTU0tV2ViIEFkbWluIDxzdXBwb3J0QGNhc3RsZS1zb2Z0LmNvbT4nO1xuXG4vKkFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmVucm9sbEFjY291bnQuc3ViamVjdCA9ICh1c2VyKSA9PiB7XG4gIHJldHVybiAnQmllbnZlbmlkQCBhIENNTS1XZWIsICR7dXNlci5wcm9maWxlLm5hbWV9Jztcbn07XG5cbkFjY291bnRzLmVtYWlsVGVtcGxhdGVzLmVucm9sbEFjY291bnQudGV4dCA9ICh1c2VyLCB1cmwpID0+IHtcbiAgcmV0dXJuICdQYXJhIHZlcmlmaWNhciBzdSBkaXJlY2Npb24gZGUgY29ycmVvIGhhZ2EgY2xpY2sgc29icmUgZWwgc2lndWllbnRlIGVubGFjZS5cXG5cXG4nXG4gICAgKyB1cmw7XG59O1xuXG5BY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5yZXNldFBhc3N3b3JkLmZyb20gPSAoKSA9PiB7XG4gIC8vIE92ZXJyaWRlcyB0aGUgdmFsdWUgc2V0IGluIGBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5mcm9tYCB3aGVuIHJlc2V0dGluZ1xuICAvLyBwYXNzd29yZHMuXG4gIHJldHVybiAnQXdlc29tZVNpdGUgUGFzc3dvcmQgUmVzZXQgPG5vLXJlcGx5QGV4YW1wbGUuY29tPic7XG59OyovXG5cbkFjY291bnRzLmVtYWlsVGVtcGxhdGVzLnZlcmlmeUVtYWlsID0ge1xuICAgc3ViamVjdCgpIHtcbiAgICAgIHJldHVybiBcIkNvbW8gdmVyaWZpY2FyIHN1IGRpcmVjY2lvbiBkZSBjb3JyZW8gZW4gYXBwLm1hcmJlbGxhY20ubmV0XCI7XG4gICB9LFxuICAgdGV4dCh1c2VyLCB1cmwpIHtcbiAgICAgIHJldHVybiAnSG9sYSAnICsgdXNlci5wcm9maWxlLm5hbWUgKyAnISxcXG5cXG4nXG4gICAgICArICdWZXJpZmlxdWUgc3UgZGlyZWNjaW9uIGRlIGNvcnJlbyBlbiBlbCBzaWd1aWVudGUgZW5sYWNlOlxcblxcbidcbiAgICAgICsgdXJsICsgJ1xcblxcbidcbiAgICAgICsgJ1BvciBGYXZvciB5IEdyYWNpYXMsXFxuXFxuJ1xuICAgICAgKyAnRWwgRXF1aXBvIGRlIENNTS1XZWIuJztcbiAgIH1cbn07XG5cbk1ldGVvci5zdGFydHVwKGZ1bmN0aW9uKCkge1xuXHQvLyByZWFkIGVudmlyb25tZW50IHZhcmlhYmxlcyBmcm9tIE1ldGVvci5zZXR0aW5nc1xuXHRpZihNZXRlb3Iuc2V0dGluZ3MgJiYgTWV0ZW9yLnNldHRpbmdzLmVudiAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5lbnYpKSB7XG5cdFx0Zm9yKHZhciB2YXJpYWJsZU5hbWUgaW4gTWV0ZW9yLnNldHRpbmdzLmVudikge1xuXHRcdFx0cHJvY2Vzcy5lbnZbdmFyaWFibGVOYW1lXSA9IE1ldGVvci5zZXR0aW5ncy5lbnZbdmFyaWFibGVOYW1lXTtcblx0XHR9XG5cdH1cblxuXHQvL1xuXHQvLyBTZXR1cCBPQXV0aCBsb2dpbiBzZXJ2aWNlIGNvbmZpZ3VyYXRpb24gKHJlYWQgZnJvbSBNZXRlb3Iuc2V0dGluZ3MpXG5cdC8vXG5cdC8vIFlvdXIgc2V0dGluZ3MgZmlsZSBzaG91bGQgbG9vayBsaWtlIHRoaXM6XG5cdC8vXG5cdC8vIHtcblx0Ly8gICAgIFwib2F1dGhcIjoge1xuXHQvLyAgICAgICAgIFwiZ29vZ2xlXCI6IHtcblx0Ly8gICAgICAgICAgICAgXCJjbGllbnRJZFwiOiBcInlvdXJDbGllbnRJZFwiLFxuXHQvLyAgICAgICAgICAgICBcInNlY3JldFwiOiBcInlvdXJTZWNyZXRcIlxuXHQvLyAgICAgICAgIH0sXG5cdC8vICAgICAgICAgXCJnaXRodWJcIjoge1xuXHQvLyAgICAgICAgICAgICBcImNsaWVudElkXCI6IFwieW91ckNsaWVudElkXCIsXG5cdC8vICAgICAgICAgICAgIFwic2VjcmV0XCI6IFwieW91clNlY3JldFwiXG5cdC8vICAgICAgICAgfVxuXHQvLyAgICAgfVxuXHQvLyB9XG5cdC8vXG5cblx0aWYoQWNjb3VudHMgJiYgQWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbiAmJiBNZXRlb3Iuc2V0dGluZ3MgJiYgTWV0ZW9yLnNldHRpbmdzLm9hdXRoICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoKSkge1xuXHRcdC8vIGdvb2dsZVxuXHRcdGlmKE1ldGVvci5zZXR0aW5ncy5vYXV0aC5nb29nbGUgJiYgXy5pc09iamVjdChNZXRlb3Iuc2V0dGluZ3Mub2F1dGguZ29vZ2xlKSkge1xuXHRcdFx0Ly8gcmVtb3ZlIG9sZCBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLnJlbW92ZSh7XG5cdFx0XHRcdHNlcnZpY2U6IFwiZ29vZ2xlXCJcblx0XHRcdH0pO1xuXG5cdFx0XHR2YXIgc2V0dGluZ3NPYmplY3QgPSBNZXRlb3Iuc2V0dGluZ3Mub2F1dGguZ29vZ2xlO1xuXHRcdFx0c2V0dGluZ3NPYmplY3Quc2VydmljZSA9IFwiZ29vZ2xlXCI7XG5cblx0XHRcdC8vIGFkZCBuZXcgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5pbnNlcnQoc2V0dGluZ3NPYmplY3QpO1xuXHRcdH1cblx0XHQvLyBnaXRodWJcblx0XHRpZihNZXRlb3Iuc2V0dGluZ3Mub2F1dGguZ2l0aHViICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmdpdGh1YikpIHtcblx0XHRcdC8vIHJlbW92ZSBvbGQgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5yZW1vdmUoe1xuXHRcdFx0XHRzZXJ2aWNlOiBcImdpdGh1YlwiXG5cdFx0XHR9KTtcblxuXHRcdFx0dmFyIHNldHRpbmdzT2JqZWN0ID0gTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmdpdGh1Yjtcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcImdpdGh1YlwiO1xuXG5cdFx0XHQvLyBhZGQgbmV3IGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24uaW5zZXJ0KHNldHRpbmdzT2JqZWN0KTtcblx0XHR9XG5cdFx0Ly8gbGlua2VkaW5cblx0XHRpZihNZXRlb3Iuc2V0dGluZ3Mub2F1dGgubGlua2VkaW4gJiYgXy5pc09iamVjdChNZXRlb3Iuc2V0dGluZ3Mub2F1dGgubGlua2VkaW4pKSB7XG5cdFx0XHQvLyByZW1vdmUgb2xkIGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24ucmVtb3ZlKHtcblx0XHRcdFx0c2VydmljZTogXCJsaW5rZWRpblwiXG5cdFx0XHR9KTtcblxuXHRcdFx0dmFyIHNldHRpbmdzT2JqZWN0ID0gTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmxpbmtlZGluO1xuXHRcdFx0c2V0dGluZ3NPYmplY3Quc2VydmljZSA9IFwibGlua2VkaW5cIjtcblxuXHRcdFx0Ly8gYWRkIG5ldyBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLmluc2VydChzZXR0aW5nc09iamVjdCk7XG5cdFx0fVxuXHRcdC8vIGZhY2Vib29rXG5cdFx0aWYoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmZhY2Vib29rICYmIF8uaXNPYmplY3QoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLmZhY2Vib29rKSkge1xuXHRcdFx0Ly8gcmVtb3ZlIG9sZCBjb25maWd1cmF0aW9uXG5cdFx0XHRBY2NvdW50cy5sb2dpblNlcnZpY2VDb25maWd1cmF0aW9uLnJlbW92ZSh7XG5cdFx0XHRcdHNlcnZpY2U6IFwiZmFjZWJvb2tcIlxuXHRcdFx0fSk7XG5cblx0XHRcdHZhciBzZXR0aW5nc09iamVjdCA9IE1ldGVvci5zZXR0aW5ncy5vYXV0aC5mYWNlYm9vaztcblx0XHRcdHNldHRpbmdzT2JqZWN0LnNlcnZpY2UgPSBcImZhY2Vib29rXCI7XG5cblx0XHRcdC8vIGFkZCBuZXcgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5pbnNlcnQoc2V0dGluZ3NPYmplY3QpO1xuXHRcdH1cblx0XHQvLyB0d2l0dGVyXG5cdFx0aWYoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLnR3aXR0ZXIgJiYgXy5pc09iamVjdChNZXRlb3Iuc2V0dGluZ3Mub2F1dGgudHdpdHRlcikpIHtcblx0XHRcdC8vIHJlbW92ZSBvbGQgY29uZmlndXJhdGlvblxuXHRcdFx0QWNjb3VudHMubG9naW5TZXJ2aWNlQ29uZmlndXJhdGlvbi5yZW1vdmUoe1xuXHRcdFx0XHRzZXJ2aWNlOiBcInR3aXR0ZXJcIlxuXHRcdFx0fSk7XG5cblx0XHRcdHZhciBzZXR0aW5nc09iamVjdCA9IE1ldGVvci5zZXR0aW5ncy5vYXV0aC50d2l0dGVyO1xuXHRcdFx0c2V0dGluZ3NPYmplY3Quc2VydmljZSA9IFwidHdpdHRlclwiO1xuXG5cdFx0XHQvLyBhZGQgbmV3IGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24uaW5zZXJ0KHNldHRpbmdzT2JqZWN0KTtcblx0XHR9XG5cdFx0Ly8gbWV0ZW9yXG5cdFx0aWYoTWV0ZW9yLnNldHRpbmdzLm9hdXRoLm1ldGVvciAmJiBfLmlzT2JqZWN0KE1ldGVvci5zZXR0aW5ncy5vYXV0aC5tZXRlb3IpKSB7XG5cdFx0XHQvLyByZW1vdmUgb2xkIGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24ucmVtb3ZlKHtcblx0XHRcdFx0c2VydmljZTogXCJtZXRlb3ItZGV2ZWxvcGVyXCJcblx0XHRcdH0pO1xuXG5cdFx0XHR2YXIgc2V0dGluZ3NPYmplY3QgPSBNZXRlb3Iuc2V0dGluZ3Mub2F1dGgubWV0ZW9yO1xuXHRcdFx0c2V0dGluZ3NPYmplY3Quc2VydmljZSA9IFwibWV0ZW9yLWRldmVsb3BlclwiO1xuXG5cdFx0XHQvLyBhZGQgbmV3IGNvbmZpZ3VyYXRpb25cblx0XHRcdEFjY291bnRzLmxvZ2luU2VydmljZUNvbmZpZ3VyYXRpb24uaW5zZXJ0KHNldHRpbmdzT2JqZWN0KTtcblx0XHR9XG5cdH1cblxuXHRcbn0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cdFwiY3JlYXRlVXNlckFjY291bnRcIjogZnVuY3Rpb24ob3B0aW9ucykge1xuXHRcdGlmKCFVc2Vycy5pc0FkbWluKE1ldGVvci51c2VySWQoKSkpIHtcblx0XHRcdHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBcIkFDQ0VTTyBERU5FR0FETy5cIik7XG5cdFx0fVxuXG5cdFx0dmFyIHVzZXJPcHRpb25zID0ge307XG5cdFx0aWYob3B0aW9ucy51c2VybmFtZSkgdXNlck9wdGlvbnMudXNlcm5hbWUgPSBvcHRpb25zLnVzZXJuYW1lO1xuXHRcdGlmKG9wdGlvbnMuZW1haWwpIHVzZXJPcHRpb25zLmVtYWlsID0gb3B0aW9ucy5lbWFpbDtcblx0XHRpZihvcHRpb25zLnBhc3N3b3JkKSB1c2VyT3B0aW9ucy5wYXNzd29yZCA9IG9wdGlvbnMucGFzc3dvcmQ7XG5cdFx0aWYob3B0aW9ucy5wcm9maWxlKSB1c2VyT3B0aW9ucy5wcm9maWxlID0gb3B0aW9ucy5wcm9maWxlO1xuXHRcdGlmKG9wdGlvbnMucHJvZmlsZSAmJiBvcHRpb25zLnByb2ZpbGUuZW1haWwpIHVzZXJPcHRpb25zLmVtYWlsID0gb3B0aW9ucy5wcm9maWxlLmVtYWlsO1xuXG5cdFx0QWNjb3VudHMuY3JlYXRlVXNlcih1c2VyT3B0aW9ucyk7XG5cdH0sXG5cdFwidXBkYXRlVXNlckFjY291bnRcIjogZnVuY3Rpb24odXNlcklkLCBvcHRpb25zKSB7XG5cdFx0Ly8gb25seSBhZG1pbiBvciB1c2VycyBvd24gcHJvZmlsZVxuXHRcdGlmKCEoVXNlcnMuaXNBZG1pbihNZXRlb3IudXNlcklkKCkpIHx8IHVzZXJJZCA9PSBNZXRlb3IudXNlcklkKCkpKSB7XG5cdFx0XHR0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgXCJBQ0NFU08gREVORUdBRE8uXCIpO1xuXHRcdH1cblxuXHRcdC8vIG5vbi1hZG1pbiB1c2VyIGNhbiBjaGFuZ2Ugb25seSBwcm9maWxlXG5cdFx0aWYoIVVzZXJzLmlzQWRtaW4oTWV0ZW9yLnVzZXJJZCgpKSkge1xuXHRcdFx0dmFyIGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcblx0XHRcdGlmKGtleXMubGVuZ3RoICE9PSAxIHx8ICFvcHRpb25zLnByb2ZpbGUpIHtcblx0XHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiQUNDRVNPIERFTkVHQURPLlwiKTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHR2YXIgdXNlck9wdGlvbnMgPSB7fTtcblx0XHRpZihvcHRpb25zLnVzZXJuYW1lKSB1c2VyT3B0aW9ucy51c2VybmFtZSA9IG9wdGlvbnMudXNlcm5hbWU7XG5cdFx0aWYob3B0aW9ucy5lbWFpbCkgdXNlck9wdGlvbnMuZW1haWwgPSBvcHRpb25zLmVtYWlsO1xuXHRcdGlmKG9wdGlvbnMucGFzc3dvcmQpIHVzZXJPcHRpb25zLnBhc3N3b3JkID0gb3B0aW9ucy5wYXNzd29yZDtcblx0XHRpZihvcHRpb25zLnByb2ZpbGUpIHVzZXJPcHRpb25zLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGU7XG5cblx0XHRpZihvcHRpb25zLnByb2ZpbGUgJiYgb3B0aW9ucy5wcm9maWxlLmVtYWlsKSB1c2VyT3B0aW9ucy5lbWFpbCA9IG9wdGlvbnMucHJvZmlsZS5lbWFpbDtcblx0XHRpZihvcHRpb25zLnJvbGVzKSB1c2VyT3B0aW9ucy5yb2xlcyA9IG9wdGlvbnMucm9sZXM7XG5cblx0XHRpZih1c2VyT3B0aW9ucy5lbWFpbCkge1xuXHRcdFx0dmFyIGVtYWlsID0gdXNlck9wdGlvbnMuZW1haWw7XG5cdFx0XHRkZWxldGUgdXNlck9wdGlvbnMuZW1haWw7XG5cdFx0XHR2YXIgdXNlckRhdGEgPSBVc2Vycy5maW5kT25lKHRoaXMudXNlcklkKTtcblx0XHRcdGlmKHVzZXJEYXRhLmVtYWlscyAmJiAhdXNlckRhdGEuZW1haWxzLmZpbmQoZnVuY3Rpb24obWFpbCkgeyByZXR1cm4gbWFpbC5hZGRyZXNzID09IGVtYWlsOyB9KSkge1xuXHRcdFx0XHR1c2VyT3B0aW9ucy5lbWFpbHMgPSBbeyBhZGRyZXNzOiBlbWFpbCB9XTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHR2YXIgcGFzc3dvcmQgPSBcIlwiO1xuXHRcdGlmKHVzZXJPcHRpb25zLnBhc3N3b3JkKSB7XG5cdFx0XHRwYXNzd29yZCA9IHVzZXJPcHRpb25zLnBhc3N3b3JkO1xuXHRcdFx0ZGVsZXRlIHVzZXJPcHRpb25zLnBhc3N3b3JkO1xuXHRcdH1cblxuXHRcdGlmKHVzZXJPcHRpb25zKSB7XG5cdFx0XHRmb3IodmFyIGtleSBpbiB1c2VyT3B0aW9ucykge1xuXHRcdFx0XHR2YXIgb2JqID0gdXNlck9wdGlvbnNba2V5XTtcblx0XHRcdFx0aWYoXy5pc09iamVjdChvYmopKSB7XG5cdFx0XHRcdFx0Zm9yKHZhciBrIGluIG9iaikge1xuXHRcdFx0XHRcdFx0dXNlck9wdGlvbnNba2V5ICsgXCIuXCIgKyBrXSA9IG9ialtrXTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZGVsZXRlIHVzZXJPcHRpb25zW2tleV07XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdFVzZXJzLnVwZGF0ZSh1c2VySWQsIHsgJHNldDogdXNlck9wdGlvbnMgfSk7XG5cdFx0fVxuXG5cdFx0aWYocGFzc3dvcmQpIHtcblx0XHRcdEFjY291bnRzLnNldFBhc3N3b3JkKHVzZXJJZCwgcGFzc3dvcmQpO1xuXHRcdH1cblx0fSxcblxuXHRcInNlbmRNYWlsXCI6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcblx0XHR0aGlzLnVuYmxvY2soKTtcblxuXHRcdEVtYWlsLnNlbmQob3B0aW9ucyk7XG5cdH1cbn0pO1xuXG5BY2NvdW50cy5vbkNyZWF0ZVVzZXIoZnVuY3Rpb24gKG9wdGlvbnMsIHVzZXIpIHtcblx0dXNlci5yb2xlcyA9IFtcInVzZXJcIl07XG5cblx0aWYob3B0aW9ucy5wcm9maWxlKSB7XG5cdFx0dXNlci5wcm9maWxlID0gb3B0aW9ucy5wcm9maWxlO1xuXHR9XG5cblx0aWYoIVVzZXJzLmZpbmRPbmUoeyByb2xlczogXCJhZG1pblwiIH0pICYmIHVzZXIucm9sZXMuaW5kZXhPZihcImFkbWluXCIpIDwgMCkge1xuXHRcdHVzZXIucm9sZXMgPSBbXCJhZG1pblwiXTtcblx0IH1cblxuXHRyZXR1cm4gdXNlcjtcbn0pO1xuXG5BY2NvdW50cy52YWxpZGF0ZUxvZ2luQXR0ZW1wdChmdW5jdGlvbihpbmZvKSB7XG5cblx0Ly8gcmVqZWN0IHVzZXJzIHdpdGggcm9sZSBcImJsb2NrZWRcIlxuXHRpZihpbmZvLnVzZXIgJiYgVXNlcnMuaXNJblJvbGUoaW5mby51c2VyLl9pZCwgXCJibG9ja2VkXCIpKSB7XG5cdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsIFwiU1UgQ1VFTlRBIEVTVEEgQkxPUVVFQURBLlwiKTtcblx0fVxuXG4gIGlmKHZlcmlmeUVtYWlsICYmIGluZm8udXNlciAmJiBpbmZvLnVzZXIuZW1haWxzICYmIGluZm8udXNlci5lbWFpbHMubGVuZ3RoICYmICFpbmZvLnVzZXIuZW1haWxzWzBdLnZlcmlmaWVkICkge1xuXHRcdFx0dGhyb3cgbmV3IE1ldGVvci5FcnJvcig0OTksIFwiQ09SUkVPIE5PIFZFUklGSUNBRE8uXCIpO1xuICB9XG5cblx0cmV0dXJuIHRydWU7XG59KTtcblxuXG5Vc2Vycy5iZWZvcmUuaW5zZXJ0KGZ1bmN0aW9uKHVzZXJJZCwgZG9jKSB7XG5cdGlmKGRvYy5lbWFpbHMgJiYgZG9jLmVtYWlsc1swXSAmJiBkb2MuZW1haWxzWzBdLmFkZHJlc3MpIHtcblx0XHRkb2MucHJvZmlsZSA9IGRvYy5wcm9maWxlIHx8IHt9O1xuXHRcdGRvYy5wcm9maWxlLmVtYWlsID0gZG9jLmVtYWlsc1swXS5hZGRyZXNzO1xuXHR9IGVsc2Uge1xuXHRcdC8vIG9hdXRoXG5cdFx0aWYoZG9jLnNlcnZpY2VzKSB7XG5cdFx0XHQvLyBnb29nbGUgZS1tYWlsXG5cdFx0XHRpZihkb2Muc2VydmljZXMuZ29vZ2xlICYmIGRvYy5zZXJ2aWNlcy5nb29nbGUuZW1haWwpIHtcblx0XHRcdFx0ZG9jLnByb2ZpbGUgPSBkb2MucHJvZmlsZSB8fCB7fTtcblx0XHRcdFx0ZG9jLnByb2ZpbGUuZW1haWwgPSBkb2Muc2VydmljZXMuZ29vZ2xlLmVtYWlsO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Ly8gZ2l0aHViIGUtbWFpbFxuXHRcdFx0XHRpZihkb2Muc2VydmljZXMuZ2l0aHViICYmIGRvYy5zZXJ2aWNlcy5naXRodWIuYWNjZXNzVG9rZW4pIHtcblx0XHRcdFx0XHR2YXIgZ2l0aHViID0gbmV3IEdpdEh1Yih7XG5cdFx0XHRcdFx0XHR2ZXJzaW9uOiBcIjMuMC4wXCIsXG5cdFx0XHRcdFx0XHR0aW1lb3V0OiA1MDAwXG5cdFx0XHRcdFx0fSk7XG5cblx0XHRcdFx0XHRnaXRodWIuYXV0aGVudGljYXRlKHtcblx0XHRcdFx0XHRcdHR5cGU6IFwib2F1dGhcIixcblx0XHRcdFx0XHRcdHRva2VuOiBkb2Muc2VydmljZXMuZ2l0aHViLmFjY2Vzc1Rva2VuXG5cdFx0XHRcdFx0fSk7XG5cblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0dmFyIHJlc3VsdCA9IGdpdGh1Yi51c2VyLmdldEVtYWlscyh7fSk7XG5cdFx0XHRcdFx0XHR2YXIgZW1haWwgPSBfLmZpbmRXaGVyZShyZXN1bHQsIHsgcHJpbWFyeTogdHJ1ZSB9KTtcblx0XHRcdFx0XHRcdGlmKCFlbWFpbCAmJiByZXN1bHQubGVuZ3RoICYmIF8uaXNTdHJpbmcocmVzdWx0WzBdKSkge1xuXHRcdFx0XHRcdFx0XHRlbWFpbCA9IHsgZW1haWw6IHJlc3VsdFswXSB9O1xuXHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRpZihlbWFpbCkge1xuXHRcdFx0XHRcdFx0XHRkb2MucHJvZmlsZSA9IGRvYy5wcm9maWxlIHx8IHt9O1xuXHRcdFx0XHRcdFx0XHRkb2MucHJvZmlsZS5lbWFpbCA9IGVtYWlsLmVtYWlsO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH0gY2F0Y2goZSkge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdC8vIGxpbmtlZGluIGVtYWlsXG5cdFx0XHRcdFx0aWYoZG9jLnNlcnZpY2VzLmxpbmtlZGluICYmIGRvYy5zZXJ2aWNlcy5saW5rZWRpbi5lbWFpbEFkZHJlc3MpIHtcblx0XHRcdFx0XHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0XHRcdFx0XHRkb2MucHJvZmlsZS5uYW1lID0gZG9jLnNlcnZpY2VzLmxpbmtlZGluLmZpcnN0TmFtZSArIFwiIFwiICsgZG9jLnNlcnZpY2VzLmxpbmtlZGluLmxhc3ROYW1lO1xuXHRcdFx0XHRcdFx0ZG9jLnByb2ZpbGUuZW1haWwgPSBkb2Muc2VydmljZXMubGlua2VkaW4uZW1haWxBZGRyZXNzO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRpZihkb2Muc2VydmljZXMuZmFjZWJvb2sgJiYgZG9jLnNlcnZpY2VzLmZhY2Vib29rLmVtYWlsKSB7XG5cdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlLmVtYWlsID0gZG9jLnNlcnZpY2VzLmZhY2Vib29rLmVtYWlsO1xuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0aWYoZG9jLnNlcnZpY2VzLnR3aXR0ZXIgJiYgZG9jLnNlcnZpY2VzLnR3aXR0ZXIuZW1haWwpIHtcblx0XHRcdFx0XHRcdFx0XHRkb2MucHJvZmlsZSA9IGRvYy5wcm9maWxlIHx8IHt9O1xuXHRcdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlLmVtYWlsID0gZG9jLnNlcnZpY2VzLnR3aXR0ZXIuZW1haWw7XG5cdFx0XHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRcdFx0aWYoZG9jLnNlcnZpY2VzW1wibWV0ZW9yLWRldmVsb3BlclwiXSAmJiBkb2Muc2VydmljZXNbXCJtZXRlb3ItZGV2ZWxvcGVyXCJdLmVtYWlscyAmJiBkb2Muc2VydmljZXNbXCJtZXRlb3ItZGV2ZWxvcGVyXCJdLmVtYWlscy5sZW5ndGgpIHtcblx0XHRcdFx0XHRcdFx0XHRcdGRvYy5wcm9maWxlID0gZG9jLnByb2ZpbGUgfHwge307XG5cdFx0XHRcdFx0XHRcdFx0XHRkb2MucHJvZmlsZS5lbWFpbCA9IGRvYy5zZXJ2aWNlc1tcIm1ldGVvci1kZXZlbG9wZXJcIl0uZW1haWxzWzBdLmFkZHJlc3M7XG5cdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59KTtcblxuVXNlcnMuYmVmb3JlLnVwZGF0ZShmdW5jdGlvbih1c2VySWQsIGRvYywgZmllbGROYW1lcywgbW9kaWZpZXIsIG9wdGlvbnMpIHtcblx0aWYobW9kaWZpZXIuJHNldCAmJiBtb2RpZmllci4kc2V0LmVtYWlscyAmJiBtb2RpZmllci4kc2V0LmVtYWlscy5sZW5ndGggJiYgbW9kaWZpZXIuJHNldC5lbWFpbHNbMF0uYWRkcmVzcykge1xuXHRcdG1vZGlmaWVyLiRzZXQucHJvZmlsZS5lbWFpbCA9IG1vZGlmaWVyLiRzZXQuZW1haWxzWzBdLmFkZHJlc3M7XG5cdH1cbn0pO1xuXG5BY2NvdW50cy5vbkxvZ2luKGZ1bmN0aW9uIChpbmZvKSB7XG5cdFxufSk7XG5cbkFjY291bnRzLnVybHMucmVzZXRQYXNzd29yZCA9IGZ1bmN0aW9uICh0b2tlbikge1xuXHRyZXR1cm4gTWV0ZW9yLmFic29sdXRlVXJsKCdyZXNldF9wYXNzd29yZC8nICsgdG9rZW4pO1xufTtcblxuQWNjb3VudHMudXJscy52ZXJpZnlFbWFpbCA9IGZ1bmN0aW9uICh0b2tlbikge1xuXHRyZXR1cm4gTWV0ZW9yLmFic29sdXRlVXJsKCd2ZXJpZnlfZW1haWwvJyArIHRva2VuKTtcbn07XG4iXX0=
