(function () {



/* Exports */
Package._define("fullcalendar:fullcalendar");

})();
