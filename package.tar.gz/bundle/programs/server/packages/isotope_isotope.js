(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Isotope;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/isotope_isotope/packages/isotope_isotope.js              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("isotope:isotope", {
  Isotope: Isotope
});

})();
