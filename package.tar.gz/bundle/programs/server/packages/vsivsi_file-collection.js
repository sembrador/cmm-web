(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var check = Package.check.check;
var Match = Package.check.Match;

/* Package-scope variables */
var __coffeescriptShare, FileCollection;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS.coffee.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.defaultChunkSize = 2 * 1024 * 1024 - 1024;

share.defaultRoot = 'fs';

share.resumableBase = '/_resumable';

share.insert_func = function(file, chunkSize) {
  var id, ref, ref1, ref2, ref3, subFile;
  if (file == null) {
    file = {};
  }
  try {
    id = new Mongo.ObjectID("" + file._id);
  } catch (_error) {
    id = new Mongo.ObjectID();
  }
  subFile = {};
  subFile._id = id;
  subFile.length = 0;
  subFile.md5 = 'd41d8cd98f00b204e9800998ecf8427e';
  subFile.uploadDate = new Date();
  subFile.chunkSize = chunkSize;
  subFile.filename = (ref = file.filename) != null ? ref : '';
  subFile.metadata = (ref1 = file.metadata) != null ? ref1 : {};
  subFile.aliases = (ref2 = file.aliases) != null ? ref2 : [];
  subFile.contentType = (ref3 = file.contentType) != null ? ref3 : 'application/octet-stream';
  return subFile;
};

share.reject_file_modifier = function(modifier) {
  var forbidden, required;
  forbidden = Match.OneOf(Match.ObjectIncluding({
    _id: Match.Any
  }), Match.ObjectIncluding({
    length: Match.Any
  }), Match.ObjectIncluding({
    chunkSize: Match.Any
  }), Match.ObjectIncluding({
    md5: Match.Any
  }), Match.ObjectIncluding({
    uploadDate: Match.Any
  }));
  required = Match.OneOf(Match.ObjectIncluding({
    _id: Match.Any
  }), Match.ObjectIncluding({
    length: Match.Any
  }), Match.ObjectIncluding({
    chunkSize: Match.Any
  }), Match.ObjectIncluding({
    md5: Match.Any
  }), Match.ObjectIncluding({
    uploadDate: Match.Any
  }), Match.ObjectIncluding({
    metadata: Match.Any
  }), Match.ObjectIncluding({
    aliases: Match.Any
  }), Match.ObjectIncluding({
    filename: Match.Any
  }), Match.ObjectIncluding({
    contentType: Match.Any
  }));
  return Match.test(modifier, Match.OneOf(Match.ObjectIncluding({
    $set: forbidden
  }), Match.ObjectIncluding({
    $unset: required
  }), Match.ObjectIncluding({
    $inc: forbidden
  }), Match.ObjectIncluding({
    $mul: forbidden
  }), Match.ObjectIncluding({
    $bit: forbidden
  }), Match.ObjectIncluding({
    $min: forbidden
  }), Match.ObjectIncluding({
    $max: forbidden
  }), Match.ObjectIncluding({
    $rename: required
  }), Match.ObjectIncluding({
    $currentDate: forbidden
  }), Match.Where(function(pat) {
    return !Match.test(pat, Match.OneOf(Match.ObjectIncluding({
      $inc: Match.Any
    }), Match.ObjectIncluding({
      $set: Match.Any
    }), Match.ObjectIncluding({
      $unset: Match.Any
    }), Match.ObjectIncluding({
      $addToSet: Match.Any
    }), Match.ObjectIncluding({
      $pop: Match.Any
    }), Match.ObjectIncluding({
      $pullAll: Match.Any
    }), Match.ObjectIncluding({
      $pull: Match.Any
    }), Match.ObjectIncluding({
      $pushAll: Match.Any
    }), Match.ObjectIncluding({
      $push: Match.Any
    }), Match.ObjectIncluding({
      $bit: Match.Any
    })));
  })));
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/server_shared.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var through2;

if (Meteor.isServer) {
  through2 = Npm.require('through2');
  share.defaultResponseHeaders = {
    'Content-Type': 'text/plain'
  };
  share.check_allow_deny = function(type, userId, file, fields) {
    var checkRules, result;
    checkRules = function(rules) {
      var func, i, len, ref, res;
      res = false;
      ref = rules[type];
      for (i = 0, len = ref.length; i < len; i++) {
        func = ref[i];
        if (!res) {
          res = func(userId, file, fields);
        }
      }
      return res;
    };
    result = !checkRules(this.denys) && checkRules(this.allows);
    return result;
  };
  share.bind_env = function(func) {
    if (func != null) {
      return Meteor.bindEnvironment(func, function(err) {
        throw err;
      });
    } else {
      return func;
    }
  };
  share.safeObjectID = function(s) {
    if (s != null ? s.match(/^[0-9a-f]{24}$/i) : void 0) {
      return new Mongo.ObjectID(s);
    } else {
      return null;
    }
  };
  share.streamChunker = function(size) {
    var makeFuncs;
    if (size == null) {
      size = share.defaultChunkSize;
    }
    makeFuncs = function(size) {
      var bufferList, flush, total, transform;
      bufferList = [new Buffer(0)];
      total = 0;
      flush = function(cb) {
        var lastBuffer, newBuffer, outSize, outputBuffer;
        outSize = total > size ? size : total;
        if (outSize > 0) {
          outputBuffer = Buffer.concat(bufferList, outSize);
          this.push(outputBuffer);
          total -= outSize;
        }
        lastBuffer = bufferList.pop();
        newBuffer = lastBuffer.slice(lastBuffer.length - total);
        bufferList = [newBuffer];
        if (total < size) {
          return cb();
        } else {
          return flush.bind(this)(cb);
        }
      };
      transform = function(chunk, enc, cb) {
        bufferList.push(chunk);
        total += chunk.length;
        if (total < size) {
          return cb();
        } else {
          return flush.bind(this)(cb);
        }
      };
      return [transform, flush];
    };
    return through2.apply(this, makeFuncs(size));
  };
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS_server.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var dicer, express, fs, grid, gridLocks, mongodb, path,                
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

if (Meteor.isServer) {
  mongodb = Npm.require('mongodb');
  grid = Npm.require('gridfs-locking-stream');
  gridLocks = Npm.require('gridfs-locks');
  fs = Npm.require('fs');
  path = Npm.require('path');
  dicer = Npm.require('dicer');
  express = Npm.require('express');
  FileCollection = (function(superClass) {
    extend(FileCollection, superClass);

    function FileCollection(root, options) {
      var indexOptions, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, self;
      this.root = root != null ? root : share.defaultRoot;
      if (options == null) {
        options = {};
      }
      if (!(this instanceof FileCollection)) {
        return new FileCollection(this.root, options);
      }
      if (!(this instanceof Mongo.Collection)) {
        throw new Meteor.Error('The global definition of Mongo.Collection has changed since the file-collection package was loaded. Please ensure that any packages that redefine Mongo.Collection are loaded before file-collection.');
      }
      if (Mongo.Collection !== Mongo.Collection.prototype.constructor) {
        throw new Meteor.Error('The global definition of Mongo.Collection has been patched by another package, and the prototype constructor has been left in an inconsistent state. Please see this link for a workaround: https://github.com/vsivsi/meteor-file-sample-app/issues/2#issuecomment-120780592');
      }
      if (typeof this.root === 'object') {
        options = this.root;
        this.root = share.defaultRoot;
      }
      this.chunkSize = (ref = options.chunkSize) != null ? ref : share.defaultChunkSize;
      this.db = Meteor.wrapAsync(mongodb.MongoClient.connect)(process.env.MONGO_URL, {});
      this.lockOptions = {
        timeOut: (ref1 = (ref2 = options.locks) != null ? ref2.timeOut : void 0) != null ? ref1 : 360,
        lockExpiration: (ref3 = (ref4 = options.locks) != null ? ref4.lockExpiration : void 0) != null ? ref3 : 90,
        pollingInterval: (ref5 = (ref6 = options.locks) != null ? ref6.pollingInterval : void 0) != null ? ref5 : 5
      };
      this.locks = gridLocks.LockCollection(this.db, {
        root: this.root,
        timeOut: this.lockOptions.timeOut,
        lockExpiration: this.lockOptions.lockExpiration,
        pollingInterval: this.lockOptions.pollingInterval
      });
      this.gfs = new grid(this.db, mongodb, this.root);
      this.baseURL = (ref7 = options.baseURL) != null ? ref7 : "/gridfs/" + this.root;
      if (options.resumable || options.http) {
        share.setupHttpAccess.bind(this)(options);
      }
      this.allows = {
        read: [],
        insert: [],
        write: [],
        remove: []
      };
      this.denys = {
        read: [],
        insert: [],
        write: [],
        remove: []
      };
      FileCollection.__super__.constructor.call(this, this.root + '.files', {
        idGeneration: 'MONGO'
      });
      if (options.resumable) {
        indexOptions = {};
        if (typeof options.resumableIndexName === 'string') {
          indexOptions.name = options.resumableIndexName;
        }
        this.db.collection(this.root + ".files").ensureIndex({
          'metadata._Resumable.resumableIdentifier': 1,
          'metadata._Resumable.resumableChunkNumber': 1,
          length: 1
        }, indexOptions);
      }
      this.maxUploadSize = (ref8 = options.maxUploadSize) != null ? ref8 : -1;
      FileCollection.__super__.allow.bind(this)({
        insert: (function(_this) {
          return function(userId, file) {
            return true;
          };
        })(this),
        remove: (function(_this) {
          return function(userId, file) {
            return true;
          };
        })(this)
      });
      FileCollection.__super__.deny.bind(this)({
        insert: (function(_this) {
          return function(userId, file) {
            check(file, {
              _id: Mongo.ObjectID,
              length: Match.Where(function(x) {
                check(x, Match.Integer);
                return x === 0;
              }),
              md5: Match.Where(function(x) {
                check(x, String);
                return x === 'd41d8cd98f00b204e9800998ecf8427e';
              }),
              uploadDate: Date,
              chunkSize: Match.Where(function(x) {
                check(x, Match.Integer);
                return x === _this.chunkSize;
              }),
              filename: String,
              contentType: String,
              aliases: [String],
              metadata: Object
            });
            if (file.chunkSize !== _this.chunkSize) {
              console.warn("Invalid chunksize");
              return true;
            }
            if (share.check_allow_deny.bind(_this)('insert', userId, file)) {
              return false;
            }
            return true;
          };
        })(this),
        update: (function(_this) {
          return function(userId, file, fields) {
            return true;
          };
        })(this),
        remove: (function(_this) {
          return function(userId, file) {
            return true;
          };
        })(this)
      });
      self = this;
      Meteor.server.method_handlers[this._prefix + "remove"] = function(selector) {
        var file;
        check(selector, Object);
        if (!LocalCollection._selectorIsIdPerhapsAsObject(selector)) {
          throw new Meteor.Error(403, "Not permitted. Untrusted code may only remove documents by ID.");
        }
        file = self.findOne(selector);
        if (file) {
          if (share.check_allow_deny.bind(self)('remove', this.userId, file)) {
            return self.remove(file);
          } else {
            throw new Meteor.Error(403, "Access denied");
          }
        } else {
          return 0;
        }
      };
    }

    FileCollection.prototype.allow = function(allowOptions) {
      var func, results, type;
      results = [];
      for (type in allowOptions) {
        func = allowOptions[type];
        if (!(type in this.allows)) {
          throw new Meteor.Error("Unrecognized allow rule type '" + type + "'.");
        }
        if (typeof func !== 'function') {
          throw new Meteor.Error("Allow rule " + type + " must be a valid function.");
        }
        results.push(this.allows[type].push(func));
      }
      return results;
    };

    FileCollection.prototype.deny = function(denyOptions) {
      var func, results, type;
      results = [];
      for (type in denyOptions) {
        func = denyOptions[type];
        if (!(type in this.denys)) {
          throw new Meteor.Error("Unrecognized deny rule type '" + type + "'.");
        }
        if (typeof func !== 'function') {
          throw new Meteor.Error("Deny rule " + type + " must be a valid function.");
        }
        results.push(this.denys[type].push(func));
      }
      return results;
    };

    FileCollection.prototype.insert = function(file, callback) {
      if (file == null) {
        file = {};
      }
      if (callback == null) {
        callback = void 0;
      }
      file = share.insert_func(file, this.chunkSize);
      return FileCollection.__super__.insert.call(this, file, callback);
    };

    FileCollection.prototype.update = function(selector, modifier, options, callback) {
      var err;
      if (options == null) {
        options = {};
      }
      if (callback == null) {
        callback = void 0;
      }
      if ((callback == null) && typeof options === 'function') {
        callback = options;
        options = {};
      }
      if (options.upsert != null) {
        err = new Meteor.Error("Update does not support the upsert option");
        if (callback != null) {
          return callback(err);
        } else {
          throw err;
        }
      }
      if (share.reject_file_modifier(modifier) && !options.force) {
        err = new Meteor.Error("Modifying gridFS read-only document elements is a very bad idea!");
        if (callback != null) {
          return callback(err);
        } else {
          throw err;
        }
      } else {
        return FileCollection.__super__.update.call(this, selector, modifier, options, callback);
      }
    };

    FileCollection.prototype.upsert = function(selector, modifier, options, callback) {
      var err;
      if (options == null) {
        options = {};
      }
      if (callback == null) {
        callback = void 0;
      }
      if ((callback == null) && typeof options === 'function') {
        callback = options;
      }
      err = new Meteor.Error("File Collections do not support 'upsert'");
      if (callback != null) {
        return callback(err);
      } else {
        throw err;
      }
    };

    FileCollection.prototype.upsertStream = function(file, options, callback) {
      var cbCalled, found, mods, writeStream;
      if (options == null) {
        options = {};
      }
      if (callback == null) {
        callback = void 0;
      }
      if ((callback == null) && typeof options === 'function') {
        callback = options;
        options = {};
      }
      callback = share.bind_env(callback);
      cbCalled = false;
      mods = {};
      if (file.filename != null) {
        mods.filename = file.filename;
      }
      if (file.aliases != null) {
        mods.aliases = file.aliases;
      }
      if (file.contentType != null) {
        mods.contentType = file.contentType;
      }
      if (file.metadata != null) {
        mods.metadata = file.metadata;
      }
      if (options.autoRenewLock == null) {
        options.autoRenewLock = true;
      }
      if (options.mode === 'w+') {
        throw new Meteor.Error("The ability to append file data in upsertStream() was removed in version 1.0.0");
      }
      if (file._id) {
        found = this.findOne({
          _id: file._id
        });
      }
      if (!(file._id && found)) {
        file._id = this.insert(mods);
      } else if (Object.keys(mods).length > 0) {
        this.update({
          _id: file._id
        }, {
          $set: mods
        });
      }
      writeStream = Meteor.wrapAsync(this.gfs.createWriteStream.bind(this.gfs))({
        root: this.root,
        _id: mongodb.ObjectID("" + file._id),
        mode: 'w',
        timeOut: this.lockOptions.timeOut,
        lockExpiration: this.lockOptions.lockExpiration,
        pollingInterval: this.lockOptions.pollingInterval
      });
      if (writeStream) {
        if (options.autoRenewLock) {
          writeStream.on('expires-soon', (function(_this) {
            return function() {
              return writeStream.renewLock(function(e, d) {
                if (e || !d) {
                  return console.warn("Automatic Write Lock Renewal Failed: " + file._id, e);
                }
              });
            };
          })(this));
        }
        if (callback != null) {
          writeStream.on('close', function(retFile) {
            if (retFile) {
              retFile._id = new Mongo.ObjectID(retFile._id.toHexString());
              return callback(null, retFile);
            }
          });
          writeStream.on('error', function(err) {
            return callback(err);
          });
        }
        return writeStream;
      }
      return null;
    };

    FileCollection.prototype.findOneStream = function(selector, options, callback) {
      var file, opts, range, readStream, ref, ref1, ref2, ref3;
      if (options == null) {
        options = {};
      }
      if (callback == null) {
        callback = void 0;
      }
      if ((callback == null) && typeof options === 'function') {
        callback = options;
        options = {};
      }
      callback = share.bind_env(callback);
      opts = {};
      if (options.sort != null) {
        opts.sort = options.sort;
      }
      if (options.skip != null) {
        opts.skip = options.skip;
      }
      file = this.findOne(selector, opts);
      if (file) {
        if (options.autoRenewLock == null) {
          options.autoRenewLock = true;
        }
        range = {
          start: (ref = (ref1 = options.range) != null ? ref1.start : void 0) != null ? ref : 0,
          end: (ref2 = (ref3 = options.range) != null ? ref3.end : void 0) != null ? ref2 : file.length - 1
        };
        readStream = Meteor.wrapAsync(this.gfs.createReadStream.bind(this.gfs))({
          root: this.root,
          _id: mongodb.ObjectID("" + file._id),
          timeOut: this.lockOptions.timeOut,
          lockExpiration: this.lockOptions.lockExpiration,
          pollingInterval: this.lockOptions.pollingInterval,
          range: {
            startPos: range.start,
            endPos: range.end
          }
        });
        if (readStream) {
          if (options.autoRenewLock) {
            readStream.on('expires-soon', (function(_this) {
              return function() {
                return readStream.renewLock(function(e, d) {
                  if (e || !d) {
                    return console.warn("Automatic Read Lock Renewal Failed: " + file._id, e);
                  }
                });
              };
            })(this));
          }
          if (callback != null) {
            readStream.on('close', function() {
              return callback(null, file);
            });
            readStream.on('error', function(err) {
              return callback(err);
            });
          }
          return readStream;
        }
      }
      return null;
    };

    FileCollection.prototype.remove = function(selector, callback) {
      var err, ret;
      if (callback == null) {
        callback = void 0;
      }
      callback = share.bind_env(callback);
      if (selector != null) {
        ret = 0;
        this.find(selector).forEach((function(_this) {
          return function(file) {
            var res;
            res = Meteor.wrapAsync(_this.gfs.remove.bind(_this.gfs))({
              _id: mongodb.ObjectID("" + file._id),
              root: _this.root,
              timeOut: _this.lockOptions.timeOut,
              lockExpiration: _this.lockOptions.lockExpiration,
              pollingInterval: _this.lockOptions.pollingInterval
            });
            return ret += res ? 1 : 0;
          };
        })(this));
        (callback != null) && callback(null, ret);
        return ret;
      } else {
        err = new Meteor.Error("Remove with an empty selector is not supported");
        if (callback != null) {
          callback(err);
        } else {
          throw err;
        }
      }
    };

    FileCollection.prototype.importFile = function(filePath, file, callback) {
      var readStream, writeStream;
      callback = share.bind_env(callback);
      filePath = path.normalize(filePath);
      if (file == null) {
        file = {};
      }
      if (file.filename == null) {
        file.filename = path.basename(filePath);
      }
      readStream = fs.createReadStream(filePath);
      readStream.on('error', share.bind_env(callback));
      writeStream = this.upsertStream(file);
      return readStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env(function(d) {
        return callback(null, d);
      })).on('error', share.bind_env(callback));
    };

    FileCollection.prototype.exportFile = function(selector, filePath, callback) {
      var readStream, writeStream;
      callback = share.bind_env(callback);
      filePath = path.normalize(filePath);
      readStream = this.findOneStream(selector);
      writeStream = fs.createWriteStream(filePath);
      return readStream.pipe(writeStream).on('finish', share.bind_env(callback)).on('error', share.bind_env(callback));
    };

    return FileCollection;

  })(Mongo.Collection);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/resumable_server.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var async, check_order, dicer, express, grid, gridLocks, mongodb, resumable_get_handler, resumable_get_lookup, resumable_post_handler, resumable_post_lookup;

if (Meteor.isServer) {
  express = Npm.require('express');
  mongodb = Npm.require('mongodb');
  grid = Npm.require('gridfs-locking-stream');
  gridLocks = Npm.require('gridfs-locks');
  dicer = Npm.require('dicer');
  async = Npm.require('async');
  check_order = function(file, callback) {
    var fileId, lock;
    fileId = mongodb.ObjectID("" + file.metadata._Resumable.resumableIdentifier);
    lock = gridLocks.Lock(fileId, this.locks, {}).obtainWriteLock();
    lock.on('locked', (function(_this) {
      return function() {
        var cursor, files;
        files = _this.db.collection(_this.root + ".files");
        cursor = files.find({
          'metadata._Resumable.resumableIdentifier': file.metadata._Resumable.resumableIdentifier,
          length: {
            $ne: 0
          }
        }, {
          fields: {
            length: 1,
            metadata: 1
          },
          sort: {
            'metadata._Resumable.resumableChunkNumber': 1
          }
        });
        return cursor.count(function(err, count) {
          var chunks;
          if (err) {
            lock.releaseLock();
            return callback(err);
          }
          if (!(count >= 1)) {
            cursor.close();
            lock.releaseLock();
            return callback();
          }
          if (count !== file.metadata._Resumable.resumableTotalChunks) {
            cursor.close();
            lock.releaseLock();
            return callback();
          }
          chunks = _this.db.collection(_this.root + ".chunks");
          cursor.batchSize(file.metadata._Resumable.resumableTotalChunks + 1);
          return cursor.toArray(function(err, parts) {
            if (err) {
              lock.releaseLock();
              return callback(err);
            }
            return async.eachLimit(parts, 5, function(part, cb) {
              var partId, partlock;
              if (err) {
                console.error("Error from cursor.next()", err);
                cb(err);
              }
              if (!part) {
                return cb(new Meteor.Error("Received null part"));
              }
              partId = mongodb.ObjectID("" + part._id);
              partlock = gridLocks.Lock(partId, _this.locks, {}).obtainWriteLock();
              partlock.on('locked', function() {
                return async.series([
                  function(cb) {
                    return chunks.update({
                      files_id: partId,
                      n: 0
                    }, {
                      $set: {
                        files_id: fileId,
                        n: part.metadata._Resumable.resumableChunkNumber - 1
                      }
                    }, cb);
                  }, function(cb) {
                    return files.remove({
                      _id: partId
                    }, cb);
                  }
                ], function(err, res) {
                  if (err) {
                    return cb(err);
                  }
                  if (part.metadata._Resumable.resumableChunkNumber !== part.metadata._Resumable.resumableTotalChunks) {
                    partlock.removeLock();
                    return cb();
                  } else {
                    return chunks.update({
                      files_id: partId,
                      n: 1
                    }, {
                      $set: {
                        files_id: fileId,
                        n: part.metadata._Resumable.resumableChunkNumber
                      }
                    }, function(err, res) {
                      partlock.removeLock();
                      if (err) {
                        return cb(err);
                      }
                      return cb();
                    });
                  }
                });
              });
              partlock.on('timed-out', function() {
                return cb(new Meteor.Error('Partlock timed out!'));
              });
              partlock.on('expired', function() {
                return cb(new Meteor.Error('Partlock expired!'));
              });
              return partlock.on('error', function(err) {
                console.error("Error obtaining partlock " + part._id, err);
                return cb(err);
              });
            }, function(err) {
              var md5Command;
              if (err) {
                lock.releaseLock();
                return callback(err);
              }
              md5Command = {
                filemd5: fileId,
                root: "" + _this.root
              };
              return _this.db.command(md5Command, function(err, results) {
                if (err) {
                  lock.releaseLock();
                  return callback(err);
                }
                return files.update({
                  _id: fileId
                }, {
                  $set: {
                    length: file.metadata._Resumable.resumableTotalSize,
                    md5: results.md5
                  }
                }, (function(_this) {
                  return function(err, res) {
                    lock.releaseLock();
                    return callback(err);
                  };
                })(this));
              });
            });
          });
        });
      };
    })(this));
    lock.on('expires-soon', function() {
      return lock.renewLock().once('renewed', function(ld) {
        if (!ld) {
          return console.warn("Resumable upload lock renewal failed!");
        }
      });
    });
    lock.on('expired', function() {
      return callback(new Meteor.Error("File Lock expired"));
    });
    lock.on('timed-out', function() {
      return callback(new Meteor.Error("File Lock timed out"));
    });
    return lock.on('error', function(err) {
      return callback(err);
    });
  };
  resumable_post_lookup = function(params, query, multipart) {
    var ref;
    return {
      _id: share.safeObjectID(multipart != null ? (ref = multipart.params) != null ? ref.resumableIdentifier : void 0 : void 0)
    };
  };
  resumable_post_handler = function(req, res, next) {
    var chunkQuery, findResult, ref, ref1, resumable, writeStream;
    if (!((ref = req.multipart) != null ? (ref1 = ref.params) != null ? ref1.resumableIdentifier : void 0 : void 0)) {
      console.error("Missing resumable.js multipart information");
      res.writeHead(501, share.defaultResponseHeaders);
      res.end();
      return;
    }
    resumable = req.multipart.params;
    resumable.resumableTotalSize = parseInt(resumable.resumableTotalSize);
    resumable.resumableTotalChunks = parseInt(resumable.resumableTotalChunks);
    resumable.resumableChunkNumber = parseInt(resumable.resumableChunkNumber);
    resumable.resumableChunkSize = parseInt(resumable.resumableChunkSize);
    resumable.resumableCurrentChunkSize = parseInt(resumable.resumableCurrentChunkSize);
    if (req.maxUploadSize > 0) {
      if (!(resumable.resumableTotalSize <= req.maxUploadSize)) {
        res.writeHead(413, share.defaultResponseHeaders);
        res.end();
        return;
      }
    }
    if (!((req.gridFS.chunkSize === resumable.resumableChunkSize) && (resumable.resumableChunkNumber <= resumable.resumableTotalChunks) && (resumable.resumableTotalSize / resumable.resumableChunkSize <= resumable.resumableTotalChunks + 1) && (resumable.resumableCurrentChunkSize === resumable.resumableChunkSize) || ((resumable.resumableChunkNumber === resumable.resumableTotalChunks) && (resumable.resumableCurrentChunkSize < 2 * resumable.resumableChunkSize)))) {
      res.writeHead(501, share.defaultResponseHeaders);
      res.end();
      return;
    }
    chunkQuery = {
      length: resumable.resumableCurrentChunkSize,
      'metadata._Resumable.resumableIdentifier': resumable.resumableIdentifier,
      'metadata._Resumable.resumableChunkNumber': resumable.resumableChunkNumber
    };
    findResult = this.findOne(chunkQuery, {
      fields: {
        _id: 1
      }
    });
    if (findResult) {
      res.writeHead(200, share.defaultResponseHeaders);
      return res.end();
    } else {
      req.gridFS.metadata._Resumable = resumable;
      writeStream = this.upsertStream({
        filename: "_Resumable_" + resumable.resumableIdentifier + "_" + resumable.resumableChunkNumber + "_" + resumable.resumableTotalChunks,
        metadata: req.gridFS.metadata
      });
      if (!writeStream) {
        res.writeHead(404, share.defaultResponseHeaders);
        res.end();
        return;
      }
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env((function(_this) {
        return function(retFile) {
          if (retFile) {
            return check_order.bind(_this)(req.gridFS, function(err) {
              if (err) {
                console.error("Error reassembling chunks of resumable.js upload", err);
                res.writeHead(500, share.defaultResponseHeaders);
              } else {
                res.writeHead(200, share.defaultResponseHeaders);
              }
              return res.end();
            });
          } else {
            console.error("Missing retFile on pipe close");
            res.writeHead(500, share.defaultResponseHeaders);
            return res.end();
          }
        };
      })(this))).on('error', share.bind_env((function(_this) {
        return function(err) {
          console.error("Piping Error!", err);
          res.writeHead(500, share.defaultResponseHeaders);
          return res.end();
        };
      })(this)));
    }
  };
  resumable_get_lookup = function(params, query) {
    var q;
    q = {
      _id: share.safeObjectID(query.resumableIdentifier)
    };
    return q;
  };
  resumable_get_handler = function(req, res, next) {
    var chunkQuery, query, result;
    query = req.query;
    chunkQuery = {
      $or: [
        {
          _id: share.safeObjectID(query.resumableIdentifier),
          length: parseInt(query.resumableTotalSize)
        }, {
          length: parseInt(query.resumableCurrentChunkSize),
          'metadata._Resumable.resumableIdentifier': query.resumableIdentifier,
          'metadata._Resumable.resumableChunkNumber': parseInt(query.resumableChunkNumber)
        }
      ]
    };
    result = this.findOne(chunkQuery, {
      fields: {
        _id: 1
      }
    });
    if (result) {
      res.writeHead(200, share.defaultResponseHeaders);
    } else {
      res.writeHead(204, share.defaultResponseHeaders);
    }
    return res.end();
  };
  share.resumablePaths = [
    {
      method: 'head',
      path: share.resumableBase,
      lookup: resumable_get_lookup,
      handler: resumable_get_handler
    }, {
      method: 'post',
      path: share.resumableBase,
      lookup: resumable_post_lookup,
      handler: resumable_post_handler
    }, {
      method: 'get',
      path: share.resumableBase,
      lookup: resumable_get_lookup,
      handler: resumable_get_handler
    }
  ];
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/http_access_server.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var build_access_point, cookieParser, del, dice_multipart, dicer, express, find_mime_boundary, get, grid, gridLocks, handle_auth, lookup_userId_by_token, mongodb, post, put;

if (Meteor.isServer) {
  express = Npm.require('express');
  cookieParser = Npm.require('cookie-parser');
  mongodb = Npm.require('mongodb');
  grid = Npm.require('gridfs-locking-stream');
  gridLocks = Npm.require('gridfs-locks');
  dicer = Npm.require('dicer');
  find_mime_boundary = function(req) {
    var RE_BOUNDARY, result;
    RE_BOUNDARY = /^multipart\/.+?(?:; boundary=(?:(?:"(.+)")|(?:([^\s]+))))$/i;
    result = RE_BOUNDARY.exec(req.headers['content-type']);
    return (result != null ? result[1] : void 0) || (result != null ? result[2] : void 0);
  };
  dice_multipart = function(req, res, next) {
    var boundary, count, d, fileName, fileStream, fileType, handleFailure, params, responseSent;
    next = share.bind_env(next);
    if (!(req.method === 'POST' && !req.diced)) {
      next();
      return;
    }
    req.diced = true;
    responseSent = false;
    handleFailure = function(msg, err, retCode) {
      if (err == null) {
        err = "";
      }
      if (retCode == null) {
        retCode = 500;
      }
      console.error(msg + " \n", err);
      if (!responseSent) {
        responseSent = true;
        res.writeHead(retCode, share.defaultResponseHeaders);
        return res.end();
      }
    };
    boundary = find_mime_boundary(req);
    if (!boundary) {
      handleFailure("No MIME multipart boundary found for dicer");
      return;
    }
    params = {};
    count = 0;
    fileStream = null;
    fileType = 'text/plain';
    fileName = 'blob';
    d = new dicer({
      boundary: boundary
    });
    d.on('part', function(p) {
      p.on('header', function(header) {
        var RE_FILE, RE_PARAM, data, k, param, re, ref, v;
        RE_FILE = /^form-data; name="file"; filename="([^"]+)"/;
        RE_PARAM = /^form-data; name="([^"]+)"/;
        for (k in header) {
          v = header[k];
          if (k === 'content-type') {
            fileType = v;
          }
          if (k === 'content-disposition') {
            if (re = RE_FILE.exec(v)) {
              fileStream = p;
              fileName = re[1];
            } else if (param = (ref = RE_PARAM.exec(v)) != null ? ref[1] : void 0) {
              data = '';
              count++;
              p.on('data', function(d) {
                return data += d.toString();
              });
              p.on('end', function() {
                count--;
                params[param] = data;
                if (count === 0 && fileStream) {
                  req.multipart = {
                    fileStream: fileStream,
                    fileName: fileName,
                    fileType: fileType,
                    params: params
                  };
                  responseSent = true;
                  return next();
                }
              });
            } else {
              console.warn("Dicer part", v);
            }
          }
        }
        if (count === 0 && fileStream) {
          req.multipart = {
            fileStream: fileStream,
            fileName: fileName,
            fileType: fileType,
            params: params
          };
          responseSent = true;
          return next();
        }
      });
      return p.on('error', function(err) {
        return handleFailure('Error in Dicer while parsing multipart:', err);
      });
    });
    d.on('error', function(err) {
      return handleFailure('Error in Dicer while parsing parts:', err);
    });
    d.on('finish', function() {
      if (!fileStream) {
        return handleFailure("Error in Dicer, no file found in POST");
      }
    });
    return req.pipe(d);
  };
  post = function(req, res, next) {
    var stream;
    if (req.multipart.fileType) {
      req.gridFS.contentType = req.multipart.fileType;
    }
    if (req.multipart.fileName) {
      req.gridFS.filename = req.multipart.fileName;
    }
    stream = this.upsertStream(req.gridFS);
    if (stream) {
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {
        if (retFile) {
          res.writeHead(200, share.defaultResponseHeaders);
          return res.end();
        }
      }).on('error', function(err) {
        res.writeHead(500, share.defaultResponseHeaders);
        return res.end();
      });
    } else {
      res.writeHead(410, share.defaultResponseHeaders);
      return res.end();
    }
  };
  get = function(req, res, next) {
    var chunksize, end, filename, h, headers, parts, ref, ref1, since, start, statusCode, stream, v;
    headers = {};
    ref = share.defaultResponseHeaders;
    for (h in ref) {
      v = ref[h];
      headers[h] = v;
    }
    if (req.headers['if-modified-since']) {
      since = Date.parse(req.headers['if-modified-since']);
      if (since && req.gridFS.uploadDate && (req.headers['if-modified-since'] === req.gridFS.uploadDate.toUTCString() || since >= req.gridFS.uploadDate.getTime())) {
        res.writeHead(304, headers);
        res.end();
        return;
      }
    }
    if (req.headers['range']) {
      statusCode = 206;
      parts = req.headers["range"].replace(/bytes=/, "").split("-");
      start = parseInt(parts[0], 10);
      end = (parts[1] ? parseInt(parts[1], 10) : req.gridFS.length - 1);
      if ((start < 0) || (end >= req.gridFS.length) || (start > end) || isNaN(start) || isNaN(end)) {
        headers['Content-Range'] = 'bytes ' + '*/' + req.gridFS.length;
        res.writeHead(416, headers);
        res.end();
        return;
      }
      chunksize = (end - start) + 1;
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + req.gridFS.length;
      headers['Accept-Ranges'] = 'bytes';
      headers['Content-Type'] = req.gridFS.contentType;
      headers['Content-Length'] = chunksize;
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();
      if (req.method !== 'HEAD') {
        stream = this.findOneStream({
          _id: req.gridFS._id
        }, {
          range: {
            start: start,
            end: end
          }
        });
      }
    } else {
      statusCode = 200;
      headers['Content-Type'] = req.gridFS.contentType;
      headers['Content-MD5'] = req.gridFS.md5;
      headers['Content-Length'] = req.gridFS.length;
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();
      if (req.method !== 'HEAD') {
        stream = this.findOneStream({
          _id: req.gridFS._id
        });
      }
    }
    if ((req.query.download && req.query.download.toLowerCase() === 'true') || req.query.filename) {
      filename = encodeURIComponent((ref1 = req.query.filename) != null ? ref1 : req.gridFS.filename);
      headers['Content-Disposition'] = "attachment; filename=\"" + filename + "\"; filename*=UTF-8''" + filename;
    }
    if (req.query.cache && !isNaN(parseInt(req.query.cache))) {
      headers['Cache-Control'] = "max-age=" + parseInt(req.query.cache) + ", private";
    }
    if (req.method === 'HEAD') {
      res.writeHead(204, headers);
      res.end();
      return;
    }
    if (stream) {
      res.writeHead(statusCode, headers);
      return stream.pipe(res).on('close', function() {
        return res.end();
      }).on('error', function(err) {
        res.writeHead(500, share.defaultResponseHeaders);
        return res.end(err);
      });
    } else {
      res.writeHead(410, share.defaultResponseHeaders);
      return res.end();
    }
  };
  put = function(req, res, next) {
    var stream;
    if (req.headers['content-type']) {
      req.gridFS.contentType = req.headers['content-type'];
    }
    stream = this.upsertStream(req.gridFS);
    if (stream) {
      return req.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {
        if (retFile) {
          res.writeHead(200, share.defaultResponseHeaders);
          return res.end();
        } else {

        }
      }).on('error', function(err) {
        res.writeHead(500, share.defaultResponseHeaders);
        return res.end(err);
      });
    } else {
      res.writeHead(404, share.defaultResponseHeaders);
      return res.end(req.url + " Not found!");
    }
  };
  del = function(req, res, next) {
    this.remove(req.gridFS);
    res.writeHead(204, share.defaultResponseHeaders);
    return res.end();
  };
  build_access_point = function(http) {
    var i, len, r;
    for (i = 0, len = http.length; i < len; i++) {
      r = http[i];
      if (r.method.toUpperCase() === 'POST') {
        this.router.post(r.path, dice_multipart);
      }
      this.router[r.method](r.path, (function(_this) {
        return function(r) {
          return function(req, res, next) {
            var lookup, opts, ref, ref1, ref2;
            if (((ref = req.params) != null ? ref._id : void 0) != null) {
              req.params._id = share.safeObjectID(req.params._id);
            }
            if (((ref1 = req.query) != null ? ref1._id : void 0) != null) {
              req.query._id = share.safeObjectID(req.query._id);
            }
            lookup = (ref2 = r.lookup) != null ? ref2.bind(_this)(req.params || {}, req.query || {}, req.multipart) : void 0;
            if (lookup == null) {
              res.writeHead(500, share.defaultResponseHeaders);
              res.end();
            } else {
              req.gridFS = _this.findOne(lookup);
              if (!req.gridFS) {
                res.writeHead(404, share.defaultResponseHeaders);
                res.end();
                return;
              }
              switch (req.method) {
                case 'HEAD':
                case 'GET':
                  if (!share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS)) {
                    res.writeHead(403, share.defaultResponseHeaders);
                    res.end();
                    return;
                  }
                  break;
                case 'POST':
                case 'PUT':
                  req.maxUploadSize = _this.maxUploadSize;
                  if (!(opts = share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS))) {
                    res.writeHead(403, share.defaultResponseHeaders);
                    res.end();
                    return;
                  }
                  if ((opts.maxUploadSize != null) && typeof opts.maxUploadSize === 'number') {
                    req.maxUploadSize = opts.maxUploadSize;
                  }
                  if (req.maxUploadSize > 0) {
                    if (req.headers['content-length'] == null) {
                      res.writeHead(411, share.defaultResponseHeaders);
                      res.end();
                      return;
                    }
                    if (!(parseInt(req.headers['content-length']) <= req.maxUploadSize)) {
                      res.writeHead(413, share.defaultResponseHeaders);
                      res.end();
                      return;
                    }
                  }
                  break;
                case 'DELETE':
                  if (!share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS)) {
                    res.writeHead(403, share.defaultResponseHeaders);
                    res.end();
                    return;
                  }
                  break;
                case 'OPTIONS':
                  if (!(share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS))) {
                    res.writeHead(403, share.defaultResponseHeaders);
                    res.end();
                    return;
                  }
                  break;
                default:
                  res.writeHead(500, share.defaultResponseHeaders);
                  res.end();
                  return;
              }
              return next();
            }
          };
        };
      })(this)(r));
      if (typeof r.handler === 'function') {
        this.router[r.method](r.path, r.handler.bind(this));
      }
    }
    return this.router.route('/*').head(get.bind(this)).get(get.bind(this)).put(put.bind(this)).post(post.bind(this))["delete"](del.bind(this)).all(function(req, res, next) {
      res.writeHead(500, share.defaultResponseHeaders);
      return res.end();
    });
  };
  lookup_userId_by_token = function(authToken) {
    var ref, userDoc;
    userDoc = (ref = Meteor.users) != null ? ref.findOne({
      'services.resume.loginTokens': {
        $elemMatch: {
          hashedToken: typeof Accounts !== "undefined" && Accounts !== null ? Accounts._hashLoginToken(authToken) : void 0
        }
      }
    }) : void 0;
    return (userDoc != null ? userDoc._id : void 0) || null;
  };
  handle_auth = function(req, res, next) {
    var ref, ref1;
    if (req.meteorUserId == null) {
      if (((ref = req.headers) != null ? ref['x-auth-token'] : void 0) != null) {
        req.meteorUserId = lookup_userId_by_token(req.headers['x-auth-token']);
      } else if (((ref1 = req.cookies) != null ? ref1['X-Auth-Token'] : void 0) != null) {
        req.meteorUserId = lookup_userId_by_token(req.cookies['X-Auth-Token']);
      } else {
        req.meteorUserId = null;
      }
    }
    return next();
  };
  share.setupHttpAccess = function(options) {
    var h, i, len, otherHandlers, r, ref, ref1, resumableHandlers;
    if (options.resumable) {
      if (options.http == null) {
        options.http = [];
      }
      resumableHandlers = [];
      otherHandlers = [];
      ref = options.http;
      for (i = 0, len = ref.length; i < len; i++) {
        h = ref[i];
        if (h.path === share.resumableBase) {
          resumableHandlers.push(h);
        } else {
          otherHandlers.push(h);
        }
      }
      resumableHandlers = resumableHandlers.concat(share.resumablePaths);
      options.http = resumableHandlers.concat(otherHandlers);
    }
    if (((ref1 = options.http) != null ? ref1.length : void 0) > 0) {
      r = express.Router();
      r.use(express.query());
      r.use(cookieParser());
      r.use(handle_auth);
      WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(r));
      this.router = express.Router();
      build_access_point.bind(this)(options.http, this.router);
      return WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(this.router));
    }
  };
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("vsivsi:file-collection", {
  FileCollection: FileCollection
});

})();

//# sourceURL=meteor://💻app/packages/vsivsi_file-collection.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdnNpdnNpX2ZpbGUtY29sbGVjdGlvbi9zcmMvZ3JpZEZTLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdnNpdnNpX2ZpbGUtY29sbGVjdGlvbi9zcmMvc2VydmVyX3NoYXJlZC5jb2ZmZWUiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3ZzaXZzaV9maWxlLWNvbGxlY3Rpb24vc3JjL2dyaWRGU19zZXJ2ZXIuY29mZmVlIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy92c2l2c2lfZmlsZS1jb2xsZWN0aW9uL3NyYy9yZXN1bWFibGVfc2VydmVyLmNvZmZlZSIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvdnNpdnNpX2ZpbGUtY29sbGVjdGlvbi9zcmMvaHR0cF9hY2Nlc3Nfc2VydmVyLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTUEsS0FBSyxDQUFDLGdCQUFOLEdBQXlCLElBQUUsSUFBRixHQUFPLElBQVAsR0FBYyxJQUF2Qzs7QUFBQSxLQUNLLENBQUMsV0FBTixHQUFvQixJQURwQjs7QUFBQSxLQUdLLENBQUMsYUFBTixHQUFzQixhQUh0Qjs7QUFBQSxLQUtLLENBQUMsV0FBTixHQUFvQixTQUFDLElBQUQsRUFBWSxTQUFaO0FBQ2pCOztJQURrQixPQUFPO0dBQ3pCO0FBQUE7QUFDRyxTQUFTLFNBQUssQ0FBQyxRQUFOLENBQWUsS0FBRyxJQUFJLENBQUMsR0FBdkIsQ0FBVCxDQURIO0dBQUE7QUFHRyxTQUFTLFNBQUssQ0FBQyxRQUFOLEVBQVQsQ0FISDtHQUFBO0FBQUEsRUFJQSxVQUFVLEVBSlY7QUFBQSxFQUtBLE9BQU8sQ0FBQyxHQUFSLEdBQWMsRUFMZDtBQUFBLEVBTUEsT0FBTyxDQUFDLE1BQVIsR0FBaUIsQ0FOakI7QUFBQSxFQU9BLE9BQU8sQ0FBQyxHQUFSLEdBQWMsa0NBUGQ7QUFBQSxFQVFBLE9BQU8sQ0FBQyxVQUFSLEdBQXlCLFVBUnpCO0FBQUEsRUFTQSxPQUFPLENBQUMsU0FBUixHQUFvQixTQVRwQjtBQUFBLEVBVUEsT0FBTyxDQUFDLFFBQVIseUNBQW1DLEVBVm5DO0FBQUEsRUFXQSxPQUFPLENBQUMsUUFBUiwyQ0FBbUMsRUFYbkM7QUFBQSxFQVlBLE9BQU8sQ0FBQyxPQUFSLDBDQUFpQyxFQVpqQztBQUFBLEVBYUEsT0FBTyxDQUFDLFdBQVIsOENBQXlDLDBCQWJ6QztBQWNBLFNBQU8sT0FBUCxDQWZpQjtBQUFBLENBTHBCOztBQUFBLEtBc0JLLENBQUMsb0JBQU4sR0FBNkIsU0FBQyxRQUFEO0FBRTFCO0FBQUEsY0FBWSxLQUFLLENBQUMsS0FBTixDQUNULEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxLQUFZLEtBQUssQ0FBQyxHQUFwQjtHQUF0QixDQURTLEVBRVQsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFFBQVksS0FBSyxDQUFDLEdBQXBCO0dBQXRCLENBRlMsRUFHVCxLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsV0FBWSxLQUFLLENBQUMsR0FBcEI7R0FBdEIsQ0FIUyxFQUlULEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxLQUFZLEtBQUssQ0FBQyxHQUFwQjtHQUF0QixDQUpTLEVBS1QsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFlBQVksS0FBSyxDQUFDLEdBQXBCO0dBQXRCLENBTFMsQ0FBWjtBQUFBLEVBUUEsV0FBVyxLQUFLLENBQUMsS0FBTixDQUNSLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxLQUFhLEtBQUssQ0FBQyxHQUFyQjtHQUF0QixDQURRLEVBRVIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFFBQWEsS0FBSyxDQUFDLEdBQXJCO0dBQXRCLENBRlEsRUFHUixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsV0FBYSxLQUFLLENBQUMsR0FBckI7R0FBdEIsQ0FIUSxFQUlSLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxLQUFhLEtBQUssQ0FBQyxHQUFyQjtHQUF0QixDQUpRLEVBS1IsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFlBQWEsS0FBSyxDQUFDLEdBQXJCO0dBQXRCLENBTFEsRUFNUixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsVUFBYSxLQUFLLENBQUMsR0FBckI7R0FBdEIsQ0FOUSxFQU9SLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxTQUFhLEtBQUssQ0FBQyxHQUFyQjtHQUF0QixDQVBRLEVBUVIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFVBQWEsS0FBSyxDQUFDLEdBQXJCO0dBQXRCLENBUlEsRUFTUixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsYUFBYSxLQUFLLENBQUMsR0FBckI7R0FBdEIsQ0FUUSxDQVJYO0FBb0JBLFNBQU8sS0FBSyxDQUFDLElBQU4sQ0FBVyxRQUFYLEVBQXFCLEtBQUssQ0FBQyxLQUFOLENBQ3pCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxNQUFNLFNBQVI7R0FBdEIsQ0FEeUIsRUFFekIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFFBQVEsUUFBVjtHQUF0QixDQUZ5QixFQUd6QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsTUFBTSxTQUFSO0dBQXRCLENBSHlCLEVBSXpCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxNQUFNLFNBQVI7R0FBdEIsQ0FKeUIsRUFLekIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLE1BQU0sU0FBUjtHQUF0QixDQUx5QixFQU16QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsTUFBTSxTQUFSO0dBQXRCLENBTnlCLEVBT3pCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsSUFBRSxNQUFNLFNBQVI7R0FBdEIsQ0FQeUIsRUFRekIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxJQUFFLFNBQVMsUUFBWDtHQUF0QixDQVJ5QixFQVN6QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLElBQUUsY0FBYyxTQUFoQjtHQUF0QixDQVR5QixFQVV6QixLQUFLLENBQUMsS0FBTixDQUFZLFNBQUMsR0FBRDtBQUNWLFdBQU8sTUFBUyxDQUFDLElBQU4sQ0FBVyxHQUFYLEVBQWdCLEtBQUssQ0FBQyxLQUFOLENBQ3pCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsTUFBRSxNQUFNLEtBQUssQ0FBQyxHQUFkO0tBQXRCLENBRHlCLEVBRXpCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsTUFBRSxNQUFNLEtBQUssQ0FBQyxHQUFkO0tBQXRCLENBRnlCLEVBR3pCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsTUFBRSxRQUFRLEtBQUssQ0FBQyxHQUFoQjtLQUF0QixDQUh5QixFQUl6QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLE1BQUUsV0FBVyxLQUFLLENBQUMsR0FBbkI7S0FBdEIsQ0FKeUIsRUFLekIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxNQUFFLE1BQU0sS0FBSyxDQUFDLEdBQWQ7S0FBdEIsQ0FMeUIsRUFNekIsS0FBSyxDQUFDLGVBQU4sQ0FBc0I7QUFBQSxNQUFFLFVBQVUsS0FBSyxDQUFDLEdBQWxCO0tBQXRCLENBTnlCLEVBT3pCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsTUFBRSxPQUFPLEtBQUssQ0FBQyxHQUFmO0tBQXRCLENBUHlCLEVBUXpCLEtBQUssQ0FBQyxlQUFOLENBQXNCO0FBQUEsTUFBRSxVQUFVLEtBQUssQ0FBQyxHQUFsQjtLQUF0QixDQVJ5QixFQVN6QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLE1BQUUsT0FBTyxLQUFLLENBQUMsR0FBZjtLQUF0QixDQVR5QixFQVV6QixLQUFLLENBQUMsZUFBTixDQUFzQjtBQUFBLE1BQUUsTUFBTSxLQUFLLENBQUMsR0FBZDtLQUF0QixDQVZ5QixDQUFoQixDQUFYLENBRFU7RUFBQSxDQUFaLENBVnlCLENBQXJCLENBQVAsQ0F0QjBCO0FBQUEsQ0F0QjdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBOztBQUFBLElBQUcsTUFBTSxDQUFDLFFBQVY7QUFFRyxhQUFXLEdBQUcsQ0FBQyxPQUFKLENBQVksVUFBWixDQUFYO0FBQUEsRUFFQSxLQUFLLENBQUMsc0JBQU4sR0FDRztBQUFBLG9CQUFnQixZQUFoQjtHQUhIO0FBQUEsRUFLQSxLQUFLLENBQUMsZ0JBQU4sR0FBeUIsU0FBQyxJQUFELEVBQU8sTUFBUCxFQUFlLElBQWYsRUFBcUIsTUFBckI7QUFFdEI7QUFBQSxpQkFBYSxTQUFDLEtBQUQ7QUFDVjtBQUFBLFlBQU0sS0FBTjtBQUNBO0FBQUE7c0JBQUE7WUFBNkI7QUFDMUIsZ0JBQU0sS0FBSyxNQUFMLEVBQWEsSUFBYixFQUFtQixNQUFuQixDQUFOO1NBREg7QUFBQSxPQURBO0FBR0EsYUFBTyxHQUFQLENBSlU7SUFBQSxDQUFiO0FBQUEsSUFNQSxTQUFTLFdBQUksQ0FBVyxJQUFDLE1BQVosQ0FBSixJQUEyQixXQUFXLElBQUMsT0FBWixDQU5wQztBQU9BLFdBQU8sTUFBUCxDQVRzQjtFQUFBLENBTHpCO0FBQUEsRUFnQkEsS0FBSyxDQUFDLFFBQU4sR0FBaUIsU0FBQyxJQUFEO0FBQ2QsUUFBRyxZQUFIO0FBQ0csYUFBTyxNQUFNLENBQUMsZUFBUCxDQUF1QixJQUF2QixFQUE2QixTQUFDLEdBQUQ7QUFBUyxjQUFNLEdBQU4sQ0FBVDtNQUFBLENBQTdCLENBQVAsQ0FESDtLQUFBO0FBR0csYUFBTyxJQUFQLENBSEg7S0FEYztFQUFBLENBaEJqQjtBQUFBLEVBc0JBLEtBQUssQ0FBQyxZQUFOLEdBQXFCLFNBQUMsQ0FBRDtBQUNsQixvQkFBRyxDQUFDLENBQUUsS0FBSCxDQUFTLGlCQUFULFVBQUg7YUFDTyxTQUFLLENBQUMsUUFBTixDQUFlLENBQWYsRUFEUDtLQUFBO2FBR0csS0FISDtLQURrQjtFQUFBLENBdEJyQjtBQUFBLEVBNEJBLEtBQUssQ0FBQyxhQUFOLEdBQXNCLFNBQUMsSUFBRDtBQUNuQjs7TUFEb0IsT0FBTyxLQUFLLENBQUM7S0FDakM7QUFBQSxnQkFBWSxTQUFDLElBQUQ7QUFDVDtBQUFBLG1CQUFhLENBQU0sV0FBTyxDQUFQLENBQU4sQ0FBYjtBQUFBLE1BQ0EsUUFBUSxDQURSO0FBQUEsTUFFQSxRQUFRLFNBQUMsRUFBRDtBQUNMO0FBQUEsa0JBQWEsUUFBUSxJQUFYLEdBQXFCLElBQXJCLEdBQStCLEtBQXpDO0FBQ0EsWUFBRyxVQUFVLENBQWI7QUFDRyx5QkFBZSxNQUFNLENBQUMsTUFBUCxDQUFjLFVBQWQsRUFBMEIsT0FBMUIsQ0FBZjtBQUFBLFVBQ0EsSUFBSSxDQUFDLElBQUwsQ0FBVSxZQUFWLENBREE7QUFBQSxVQUVBLFNBQVMsT0FGVCxDQURIO1NBREE7QUFBQSxRQUtBLGFBQWEsVUFBVSxDQUFDLEdBQVgsRUFMYjtBQUFBLFFBTUEsWUFBWSxVQUFVLENBQUMsS0FBWCxDQUFpQixVQUFVLENBQUMsTUFBWCxHQUFvQixLQUFyQyxDQU5aO0FBQUEsUUFPQSxhQUFhLENBQUUsU0FBRixDQVBiO0FBUUEsWUFBRyxRQUFRLElBQVg7aUJBQ0csS0FESDtTQUFBO2lCQUdHLEtBQUssQ0FBQyxJQUFOLENBQVcsSUFBWCxFQUFpQixFQUFqQixFQUhIO1NBVEs7TUFBQSxDQUZSO0FBQUEsTUFlQSxZQUFZLFNBQUMsS0FBRCxFQUFRLEdBQVIsRUFBYSxFQUFiO0FBQ1Qsa0JBQVUsQ0FBQyxJQUFYLENBQWdCLEtBQWhCO0FBQUEsUUFDQSxTQUFTLEtBQUssQ0FBQyxNQURmO0FBRUEsWUFBRyxRQUFRLElBQVg7aUJBQ0csS0FESDtTQUFBO2lCQUdHLEtBQUssQ0FBQyxJQUFOLENBQVcsSUFBWCxFQUFpQixFQUFqQixFQUhIO1NBSFM7TUFBQSxDQWZaO0FBc0JBLGFBQU8sQ0FBQyxTQUFELEVBQVksS0FBWixDQUFQLENBdkJTO0lBQUEsQ0FBWjtBQXdCQSxXQUFPLFFBQVEsQ0FBQyxLQUFULENBQWUsSUFBZixFQUFxQixVQUFVLElBQVYsQ0FBckIsQ0FBUCxDQXpCbUI7RUFBQSxDQTVCdEIsQ0FGSDtDQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0VBQUE7NkJBQUE7O0FBQUEsSUFBRyxNQUFNLENBQUMsUUFBVjtBQUVHLFlBQVUsR0FBRyxDQUFDLE9BQUosQ0FBWSxTQUFaLENBQVY7QUFBQSxFQUNBLE9BQU8sR0FBRyxDQUFDLE9BQUosQ0FBWSx1QkFBWixDQURQO0FBQUEsRUFFQSxZQUFZLEdBQUcsQ0FBQyxPQUFKLENBQVksY0FBWixDQUZaO0FBQUEsRUFHQSxLQUFLLEdBQUcsQ0FBQyxPQUFKLENBQVksSUFBWixDQUhMO0FBQUEsRUFJQSxPQUFPLEdBQUcsQ0FBQyxPQUFKLENBQVksTUFBWixDQUpQO0FBQUEsRUFLQSxRQUFRLEdBQUcsQ0FBQyxPQUFKLENBQVksT0FBWixDQUxSO0FBQUEsRUFNQSxVQUFVLEdBQUcsQ0FBQyxPQUFKLENBQVksU0FBWixDQU5WO0FBQUEsRUFRTTtBQUVIOztBQUFhLDRCQUFDLElBQUQsRUFBNEIsT0FBNUI7QUFDVjtBQUFBLE1BRFcsSUFBQyx1QkFBRCxPQUFRLEtBQUssQ0FBQyxXQUN6Qjs7UUFEc0MsVUFBVTtPQUNoRDtBQUFBLFlBQU8sZ0JBQWEsY0FBcEI7QUFDRyxlQUFXLG1CQUFlLElBQUMsS0FBaEIsRUFBc0IsT0FBdEIsQ0FBWCxDQURIO09BQUE7QUFHQSxZQUFPLGdCQUFhLEtBQUssQ0FBQyxVQUExQjtBQUNHLGNBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSx1TUFBYixDQUFWLENBREg7T0FIQTtBQU1BLFVBQU8sS0FBSyxDQUFDLFVBQU4sS0FBb0IsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsV0FBdEQ7QUFDRSxjQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsOFFBQWIsQ0FBVixDQURGO09BTkE7QUFTQSxVQUFHLFdBQVEsS0FBUixLQUFnQixRQUFuQjtBQUNHLGtCQUFVLElBQUMsS0FBWDtBQUFBLFFBQ0EsSUFBQyxLQUFELEdBQVEsS0FBSyxDQUFDLFdBRGQsQ0FESDtPQVRBO0FBQUEsTUFhQSxJQUFDLFVBQUQsNkNBQWlDLEtBQUssQ0FBQyxnQkFidkM7QUFBQSxNQWVBLElBQUMsR0FBRCxHQUFNLE1BQU0sQ0FBQyxTQUFQLENBQWlCLE9BQU8sQ0FBQyxXQUFXLENBQUMsT0FBckMsRUFBOEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUExRCxFQUFvRSxFQUFwRSxDQWZOO0FBQUEsTUFpQkEsSUFBQyxZQUFELEdBQ0c7QUFBQSxrR0FBa0MsR0FBbEM7QUFBQSxRQUNBLHdHQUFnRCxFQURoRDtBQUFBLFFBRUEsMEdBQWtELENBRmxEO09BbEJIO0FBQUEsTUFzQkEsSUFBQyxNQUFELEdBQVMsU0FBUyxDQUFDLGNBQVYsQ0FBeUIsSUFBQyxHQUExQixFQUNOO0FBQUEsY0FBTSxJQUFDLEtBQVA7QUFBQSxRQUNBLFNBQVMsSUFBQyxZQUFXLENBQUMsT0FEdEI7QUFBQSxRQUVBLGdCQUFnQixJQUFDLFlBQVcsQ0FBQyxjQUY3QjtBQUFBLFFBR0EsaUJBQWlCLElBQUMsWUFBVyxDQUFDLGVBSDlCO09BRE0sQ0F0QlQ7QUFBQSxNQTRCQSxJQUFDLElBQUQsR0FBVyxTQUFLLElBQUMsR0FBTixFQUFVLE9BQVYsRUFBbUIsSUFBQyxLQUFwQixDQTVCWDtBQUFBLE1BOEJBLElBQUMsUUFBRCw2Q0FBNkIsYUFBVyxJQUFDLEtBOUJ6QztBQWlDQSxVQUFHLE9BQU8sQ0FBQyxTQUFSLElBQXFCLE9BQU8sQ0FBQyxJQUFoQztBQUNHLGFBQUssQ0FBQyxlQUFlLENBQUMsSUFBdEIsQ0FBMkIsSUFBM0IsRUFBOEIsT0FBOUIsRUFESDtPQWpDQTtBQUFBLE1BcUNBLElBQUMsT0FBRCxHQUFVO0FBQUEsUUFBRSxNQUFNLEVBQVI7QUFBQSxRQUFZLFFBQVEsRUFBcEI7QUFBQSxRQUF3QixPQUFPLEVBQS9CO0FBQUEsUUFBbUMsUUFBUSxFQUEzQztPQXJDVjtBQUFBLE1Bc0NBLElBQUMsTUFBRCxHQUFTO0FBQUEsUUFBRSxNQUFNLEVBQVI7QUFBQSxRQUFZLFFBQVEsRUFBcEI7QUFBQSxRQUF3QixPQUFPLEVBQS9CO0FBQUEsUUFBbUMsUUFBUSxFQUEzQztPQXRDVDtBQUFBLE1BeUNBLGdEQUFNLElBQUMsS0FBRCxHQUFRLFFBQWQsRUFBd0I7QUFBQSxRQUFFLGNBQWMsT0FBaEI7T0FBeEIsQ0F6Q0E7QUE0Q0EsVUFBRyxPQUFPLENBQUMsU0FBWDtBQUNHLHVCQUFlLEVBQWY7QUFDQSxZQUFHLGNBQWMsQ0FBQyxrQkFBZixLQUFxQyxRQUF4QztBQUNHLHNCQUFZLENBQUMsSUFBYixHQUFvQixPQUFPLENBQUMsa0JBQTVCLENBREg7U0FEQTtBQUFBLFFBSUEsSUFBQyxHQUFFLENBQUMsVUFBSixDQUFrQixJQUFDLEtBQUYsR0FBTyxRQUF4QixDQUFnQyxDQUFDLFdBQWpDLENBQTZDO0FBQUEsVUFDdkMsMkNBQTJDLENBREo7QUFBQSxVQUV2Qyw0Q0FBNEMsQ0FGTDtBQUFBLFVBR3ZDLFFBQVEsQ0FIK0I7U0FBN0MsRUFJTSxZQUpOLENBSkEsQ0FESDtPQTVDQTtBQUFBLE1BdURBLElBQUMsY0FBRCxtREFBeUMsRUF2RHpDO0FBQUEsTUFtRUEsY0FBYyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBL0IsQ0FBb0MsSUFBcEMsRUFHRztBQUFBLGdCQUFRO2lCQUFBLFNBQUMsTUFBRCxFQUFTLElBQVQ7bUJBQWtCLEtBQWxCO1VBQUE7UUFBQSxRQUFSO0FBQUEsUUFDQSxRQUFRO2lCQUFBLFNBQUMsTUFBRCxFQUFTLElBQVQ7bUJBQWtCLEtBQWxCO1VBQUE7UUFBQSxRQURSO09BSEgsQ0FuRUE7QUFBQSxNQXlFQSxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUE5QixDQUFtQyxJQUFuQyxFQUVHO0FBQUEsZ0JBQVE7aUJBQUEsU0FBQyxNQUFELEVBQVMsSUFBVDtBQUdMLGtCQUFNLElBQU4sRUFDRztBQUFBLG1CQUFLLEtBQUssQ0FBQyxRQUFYO0FBQUEsY0FDQSxRQUFRLEtBQUssQ0FBQyxLQUFOLENBQVksU0FBQyxDQUFEO0FBQ2pCLHNCQUFNLENBQU4sRUFBUyxLQUFLLENBQUMsT0FBZjt1QkFDQSxNQUFLLEVBRlk7Y0FBQSxDQUFaLENBRFI7QUFBQSxjQUlBLEtBQUssS0FBSyxDQUFDLEtBQU4sQ0FBWSxTQUFDLENBQUQ7QUFDZCxzQkFBTSxDQUFOLEVBQVMsTUFBVDt1QkFDQSxNQUFLLG1DQUZTO2NBQUEsQ0FBWixDQUpMO0FBQUEsY0FPQSxZQUFZLElBUFo7QUFBQSxjQVFBLFdBQVcsS0FBSyxDQUFDLEtBQU4sQ0FBWSxTQUFDLENBQUQ7QUFDcEIsc0JBQU0sQ0FBTixFQUFTLEtBQUssQ0FBQyxPQUFmO3VCQUNBLE1BQUssS0FBQyxXQUZjO2NBQUEsQ0FBWixDQVJYO0FBQUEsY0FXQSxVQUFVLE1BWFY7QUFBQSxjQVlBLGFBQWEsTUFaYjtBQUFBLGNBYUEsU0FBUyxDQUFFLE1BQUYsQ0FiVDtBQUFBLGNBY0EsVUFBVSxNQWRWO2FBREg7QUFrQkEsZ0JBQU8sSUFBSSxDQUFDLFNBQUwsS0FBa0IsS0FBQyxVQUExQjtBQUNHLHFCQUFPLENBQUMsSUFBUixDQUFhLG1CQUFiO0FBQ0EscUJBQU8sSUFBUCxDQUZIO2FBbEJBO0FBdUJBLGdCQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUF2QixDQUE0QixLQUE1QixFQUErQixRQUEvQixFQUF5QyxNQUF6QyxFQUFpRCxJQUFqRCxDQUFIO0FBQ0cscUJBQU8sS0FBUCxDQURIO2FBdkJBO0FBMEJBLG1CQUFPLElBQVAsQ0E3Qks7VUFBQTtRQUFBLFFBQVI7QUFBQSxRQStCQSxRQUFRO2lCQUFBLFNBQUMsTUFBRCxFQUFTLElBQVQsRUFBZSxNQUFmO0FBTUwsbUJBQU8sSUFBUCxDQU5LO1VBQUE7UUFBQSxRQS9CUjtBQUFBLFFBdUNBLFFBQVE7aUJBQUEsU0FBQyxNQUFELEVBQVMsSUFBVDtBQUdMLG1CQUFPLElBQVAsQ0FISztVQUFBO1FBQUEsUUF2Q1I7T0FGSCxDQXpFQTtBQUFBLE1BdUhBLE9BQU8sSUF2SFA7QUFBQSxNQXlIQSxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWdCLENBQUcsSUFBQyxRQUFGLEdBQVUsUUFBWixDQUE5QixHQUFxRCxTQUFDLFFBQUQ7QUFFbEQ7QUFBQSxjQUFNLFFBQU4sRUFBZ0IsTUFBaEI7QUFFQSw0QkFBc0IsQ0FBQyw0QkFBaEIsQ0FBNkMsUUFBN0MsQ0FBUDtBQUNHLGdCQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsR0FBYixFQUFrQixnRUFBbEIsQ0FBVixDQURIO1NBRkE7QUFBQSxRQUtBLE9BQU8sSUFBSSxDQUFDLE9BQUwsQ0FBYSxRQUFiLENBTFA7QUFNQSxZQUFHLElBQUg7QUFDRyxjQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUF2QixDQUE0QixJQUE1QixFQUFrQyxRQUFsQyxFQUE0QyxJQUFJLENBQUMsTUFBakQsRUFBeUQsSUFBekQsQ0FBSDtBQUNHLG1CQUFPLElBQUksQ0FBQyxNQUFMLENBQVksSUFBWixDQUFQLENBREg7V0FBQTtBQUdHLGtCQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsR0FBYixFQUFrQixlQUFsQixDQUFWLENBSEg7V0FESDtTQUFBO0FBTUcsaUJBQU8sQ0FBUCxDQU5IO1NBUmtEO01BQUEsQ0F6SHJELENBRFU7SUFBQSxDQUFiOztBQUFBLDZCQTJJQSxRQUFPLFNBQUMsWUFBRDtBQUNKO0FBQUE7V0FBQTtrQ0FBQTtBQUNHLGNBQU8sUUFBUSxJQUFDLE9BQWhCO0FBQ0csZ0JBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxtQ0FBaUMsSUFBakMsR0FBc0MsSUFBbkQsQ0FBVixDQURIO1NBQUE7QUFFQSxZQUFPLGdCQUFlLFVBQXRCO0FBQ0csZ0JBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxnQkFBYyxJQUFkLEdBQW1CLDRCQUFoQyxDQUFWLENBREg7U0FGQTtBQUFBLHFCQUlBLElBQUMsT0FBTyxNQUFLLENBQUMsSUFBZCxDQUFtQixJQUFuQixFQUpBLENBREg7QUFBQTtxQkFESTtJQUFBLENBM0lQOztBQUFBLDZCQW9KQSxPQUFNLFNBQUMsV0FBRDtBQUNIO0FBQUE7V0FBQTtpQ0FBQTtBQUNHLGNBQU8sUUFBUSxJQUFDLE1BQWhCO0FBQ0csZ0JBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxrQ0FBZ0MsSUFBaEMsR0FBcUMsSUFBbEQsQ0FBVixDQURIO1NBQUE7QUFFQSxZQUFPLGdCQUFlLFVBQXRCO0FBQ0csZ0JBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxlQUFhLElBQWIsR0FBa0IsNEJBQS9CLENBQVYsQ0FESDtTQUZBO0FBQUEscUJBSUEsSUFBQyxNQUFNLE1BQUssQ0FBQyxJQUFiLENBQWtCLElBQWxCLEVBSkEsQ0FESDtBQUFBO3FCQURHO0lBQUEsQ0FwSk47O0FBQUEsNkJBNEpBLFNBQVEsU0FBQyxJQUFELEVBQVksUUFBWjs7UUFBQyxPQUFPO09BQ2I7O1FBRGlCLFdBQVc7T0FDNUI7QUFBQSxhQUFPLEtBQUssQ0FBQyxXQUFOLENBQWtCLElBQWxCLEVBQXdCLElBQUMsVUFBekIsQ0FBUDthQUNBLDJDQUFNLElBQU4sRUFBWSxRQUFaLEVBRks7SUFBQSxDQTVKUjs7QUFBQSw2QkFxS0EsU0FBUSxTQUFDLFFBQUQsRUFBVyxRQUFYLEVBQXFCLE9BQXJCLEVBQW1DLFFBQW5DO0FBQ0w7O1FBRDBCLFVBQVU7T0FDcEM7O1FBRHdDLFdBQVc7T0FDbkQ7QUFBQSxVQUFPLGtCQUFKLElBQWtCLG1CQUFrQixVQUF2QztBQUNHLG1CQUFXLE9BQVg7QUFBQSxRQUNBLFVBQVUsRUFEVixDQURIO09BQUE7QUFJQSxVQUFHLHNCQUFIO0FBQ0csY0FBVSxVQUFNLENBQUMsS0FBUCxDQUFhLDJDQUFiLENBQVY7QUFDQSxZQUFHLGdCQUFIO0FBQ0csaUJBQU8sU0FBUyxHQUFULENBQVAsQ0FESDtTQUFBO0FBR0csZ0JBQU0sR0FBTixDQUhIO1NBRkg7T0FKQTtBQVdBLFVBQUcsS0FBSyxDQUFDLG9CQUFOLENBQTJCLFFBQTNCLEtBQXlDLFFBQVcsQ0FBQyxLQUF4RDtBQUNHLGNBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxrRUFBYixDQUFWO0FBQ0EsWUFBRyxnQkFBSDtBQUNHLGlCQUFPLFNBQVMsR0FBVCxDQUFQLENBREg7U0FBQTtBQUdHLGdCQUFNLEdBQU4sQ0FISDtTQUZIO09BQUE7ZUFPRywyQ0FBTSxRQUFOLEVBQWdCLFFBQWhCLEVBQTBCLE9BQTFCLEVBQW1DLFFBQW5DLEVBUEg7T0FaSztJQUFBLENBcktSOztBQUFBLDZCQTBMQSxTQUFRLFNBQUMsUUFBRCxFQUFXLFFBQVgsRUFBcUIsT0FBckIsRUFBbUMsUUFBbkM7QUFDTDs7UUFEMEIsVUFBVTtPQUNwQzs7UUFEd0MsV0FBVztPQUNuRDtBQUFBLFVBQU8sa0JBQUosSUFBa0IsbUJBQWtCLFVBQXZDO0FBQ0csbUJBQVcsT0FBWCxDQURIO09BQUE7QUFBQSxNQUVBLE1BQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSwwQ0FBYixDQUZWO0FBR0EsVUFBRyxnQkFBSDtlQUNHLFNBQVMsR0FBVCxFQURIO09BQUE7QUFHRyxjQUFNLEdBQU4sQ0FISDtPQUpLO0lBQUEsQ0ExTFI7O0FBQUEsNkJBbU1BLGVBQWMsU0FBQyxJQUFELEVBQU8sT0FBUCxFQUFxQixRQUFyQjtBQUNYOztRQURrQixVQUFVO09BQzVCOztRQURnQyxXQUFXO09BQzNDO0FBQUEsVUFBTyxrQkFBSixJQUFrQixtQkFBa0IsVUFBdkM7QUFDRyxtQkFBVyxPQUFYO0FBQUEsUUFDQSxVQUFVLEVBRFYsQ0FESDtPQUFBO0FBQUEsTUFHQSxXQUFXLEtBQUssQ0FBQyxRQUFOLENBQWUsUUFBZixDQUhYO0FBQUEsTUFJQSxXQUFXLEtBSlg7QUFBQSxNQUtBLE9BQU8sRUFMUDtBQU1BLFVBQWlDLHFCQUFqQztBQUFBLFlBQUksQ0FBQyxRQUFMLEdBQWdCLElBQUksQ0FBQyxRQUFyQjtPQU5BO0FBT0EsVUFBK0Isb0JBQS9CO0FBQUEsWUFBSSxDQUFDLE9BQUwsR0FBZSxJQUFJLENBQUMsT0FBcEI7T0FQQTtBQVFBLFVBQXVDLHdCQUF2QztBQUFBLFlBQUksQ0FBQyxXQUFMLEdBQW1CLElBQUksQ0FBQyxXQUF4QjtPQVJBO0FBU0EsVUFBaUMscUJBQWpDO0FBQUEsWUFBSSxDQUFDLFFBQUwsR0FBZ0IsSUFBSSxDQUFDLFFBQXJCO09BVEE7O1FBV0EsT0FBTyxDQUFDLGdCQUFpQjtPQVh6QjtBQWFBLFVBQUcsT0FBTyxDQUFDLElBQVIsS0FBZ0IsSUFBbkI7QUFDRyxjQUFVLFVBQU0sQ0FBQyxLQUFQLENBQWEsZ0ZBQWIsQ0FBVixDQURIO09BYkE7QUFpQkEsVUFBRyxJQUFJLENBQUMsR0FBUjtBQUNHLGdCQUFRLElBQUMsUUFBRCxDQUFTO0FBQUEsVUFBQyxLQUFLLElBQUksQ0FBQyxHQUFYO1NBQVQsQ0FBUixDQURIO09BakJBO0FBb0JBLFlBQU8sSUFBSSxDQUFDLEdBQUwsSUFBYSxLQUFwQjtBQUNHLFlBQUksQ0FBQyxHQUFMLEdBQVcsSUFBQyxPQUFELENBQVEsSUFBUixDQUFYLENBREg7T0FBQSxNQUVLLElBQUcsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaLENBQWlCLENBQUMsTUFBbEIsR0FBMkIsQ0FBOUI7QUFDRixZQUFDLE9BQUQsQ0FBUTtBQUFBLFVBQUUsS0FBSyxJQUFJLENBQUMsR0FBWjtTQUFSLEVBQTJCO0FBQUEsVUFBRSxNQUFNLElBQVI7U0FBM0IsRUFERTtPQXRCTDtBQUFBLE1BeUJBLGNBQWMsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBQyxJQUFHLENBQUMsaUJBQWlCLENBQUMsSUFBdkIsQ0FBNEIsSUFBQyxJQUE3QixDQUFqQixFQUNYO0FBQUEsY0FBTSxJQUFDLEtBQVA7QUFBQSxRQUNBLEtBQUssT0FBTyxDQUFDLFFBQVIsQ0FBaUIsS0FBRyxJQUFJLENBQUMsR0FBekIsQ0FETDtBQUFBLFFBRUEsTUFBTSxHQUZOO0FBQUEsUUFHQSxTQUFTLElBQUMsWUFBVyxDQUFDLE9BSHRCO0FBQUEsUUFJQSxnQkFBZ0IsSUFBQyxZQUFXLENBQUMsY0FKN0I7QUFBQSxRQUtBLGlCQUFpQixJQUFDLFlBQVcsQ0FBQyxlQUw5QjtPQURXLENBekJkO0FBaUNBLFVBQUcsV0FBSDtBQUVHLFlBQUcsT0FBTyxDQUFDLGFBQVg7QUFDRyxxQkFBVyxDQUFDLEVBQVosQ0FBZSxjQUFmLEVBQStCO21CQUFBO3FCQUM1QixXQUFXLENBQUMsU0FBWixDQUFzQixTQUFDLENBQUQsRUFBSSxDQUFKO0FBQ25CLG9CQUFHLEtBQUssRUFBUjt5QkFDRyxPQUFPLENBQUMsSUFBUixDQUFhLDBDQUF3QyxJQUFJLENBQUMsR0FBMUQsRUFBaUUsQ0FBakUsRUFESDtpQkFEbUI7Y0FBQSxDQUF0QixFQUQ0QjtZQUFBO1VBQUEsUUFBL0IsRUFESDtTQUFBO0FBTUEsWUFBRyxnQkFBSDtBQUNHLHFCQUFXLENBQUMsRUFBWixDQUFlLE9BQWYsRUFBd0IsU0FBQyxPQUFEO0FBQ3JCLGdCQUFHLE9BQUg7QUFDRyxxQkFBTyxDQUFDLEdBQVIsR0FBa0IsU0FBSyxDQUFDLFFBQU4sQ0FBZSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVosRUFBZixDQUFsQjtxQkFDQSxTQUFTLElBQVQsRUFBZSxPQUFmLEVBRkg7YUFEcUI7VUFBQSxDQUF4QjtBQUFBLFVBSUEsV0FBVyxDQUFDLEVBQVosQ0FBZSxPQUFmLEVBQXdCLFNBQUMsR0FBRDttQkFDckIsU0FBUyxHQUFULEVBRHFCO1VBQUEsQ0FBeEIsQ0FKQSxDQURIO1NBTkE7QUFjQSxlQUFPLFdBQVAsQ0FoQkg7T0FqQ0E7QUFtREEsYUFBTyxJQUFQLENBcERXO0lBQUEsQ0FuTWQ7O0FBQUEsNkJBeVBBLGdCQUFlLFNBQUMsUUFBRCxFQUFXLE9BQVgsRUFBeUIsUUFBekI7QUFDWjs7UUFEdUIsVUFBVTtPQUNqQzs7UUFEcUMsV0FBVztPQUNoRDtBQUFBLFVBQU8sa0JBQUosSUFBa0IsbUJBQWtCLFVBQXZDO0FBQ0csbUJBQVcsT0FBWDtBQUFBLFFBQ0EsVUFBVSxFQURWLENBREg7T0FBQTtBQUFBLE1BSUEsV0FBVyxLQUFLLENBQUMsUUFBTixDQUFlLFFBQWYsQ0FKWDtBQUFBLE1BS0EsT0FBTyxFQUxQO0FBTUEsVUFBNEIsb0JBQTVCO0FBQUEsWUFBSSxDQUFDLElBQUwsR0FBWSxPQUFPLENBQUMsSUFBcEI7T0FOQTtBQU9BLFVBQTRCLG9CQUE1QjtBQUFBLFlBQUksQ0FBQyxJQUFMLEdBQVksT0FBTyxDQUFDLElBQXBCO09BUEE7QUFBQSxNQVFBLE9BQU8sSUFBQyxRQUFELENBQVMsUUFBVCxFQUFtQixJQUFuQixDQVJQO0FBVUEsVUFBRyxJQUFIOztVQUNHLE9BQU8sQ0FBQyxnQkFBaUI7U0FBekI7QUFBQSxRQUdBLFFBQ0c7QUFBQSw4RkFBOEIsQ0FBOUI7QUFBQSxVQUNBLGtGQUEwQixJQUFJLENBQUMsTUFBTCxHQUFjLENBRHhDO1NBSkg7QUFBQSxRQU9BLGFBQWEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBQyxJQUFHLENBQUMsZ0JBQWdCLENBQUMsSUFBdEIsQ0FBMkIsSUFBQyxJQUE1QixDQUFqQixFQUNWO0FBQUEsZ0JBQU0sSUFBQyxLQUFQO0FBQUEsVUFDQSxLQUFLLE9BQU8sQ0FBQyxRQUFSLENBQWlCLEtBQUcsSUFBSSxDQUFDLEdBQXpCLENBREw7QUFBQSxVQUVBLFNBQVMsSUFBQyxZQUFXLENBQUMsT0FGdEI7QUFBQSxVQUdBLGdCQUFnQixJQUFDLFlBQVcsQ0FBQyxjQUg3QjtBQUFBLFVBSUEsaUJBQWlCLElBQUMsWUFBVyxDQUFDLGVBSjlCO0FBQUEsVUFLQSxPQUNFO0FBQUEsc0JBQVUsS0FBSyxDQUFDLEtBQWhCO0FBQUEsWUFDQSxRQUFRLEtBQUssQ0FBQyxHQURkO1dBTkY7U0FEVSxDQVBiO0FBaUJBLFlBQUcsVUFBSDtBQUNHLGNBQUcsT0FBTyxDQUFDLGFBQVg7QUFDRyxzQkFBVSxDQUFDLEVBQVgsQ0FBYyxjQUFkLEVBQThCO3FCQUFBO3VCQUMzQixVQUFVLENBQUMsU0FBWCxDQUFxQixTQUFDLENBQUQsRUFBSSxDQUFKO0FBQ2xCLHNCQUFHLEtBQUssRUFBUjsyQkFDRyxPQUFPLENBQUMsSUFBUixDQUFhLHlDQUF1QyxJQUFJLENBQUMsR0FBekQsRUFBZ0UsQ0FBaEUsRUFESDttQkFEa0I7Z0JBQUEsQ0FBckIsRUFEMkI7Y0FBQTtZQUFBLFFBQTlCLEVBREg7V0FBQTtBQU1BLGNBQUcsZ0JBQUg7QUFDRyxzQkFBVSxDQUFDLEVBQVgsQ0FBYyxPQUFkLEVBQXVCO3FCQUNwQixTQUFTLElBQVQsRUFBZSxJQUFmLEVBRG9CO1lBQUEsQ0FBdkI7QUFBQSxZQUVBLFVBQVUsQ0FBQyxFQUFYLENBQWMsT0FBZCxFQUF1QixTQUFDLEdBQUQ7cUJBQ3BCLFNBQVMsR0FBVCxFQURvQjtZQUFBLENBQXZCLENBRkEsQ0FESDtXQU5BO0FBV0EsaUJBQU8sVUFBUCxDQVpIO1NBbEJIO09BVkE7QUEwQ0EsYUFBTyxJQUFQLENBM0NZO0lBQUEsQ0F6UGY7O0FBQUEsNkJBc1NBLFNBQVEsU0FBQyxRQUFELEVBQVcsUUFBWDtBQUNMOztRQURnQixXQUFXO09BQzNCO0FBQUEsaUJBQVcsS0FBSyxDQUFDLFFBQU4sQ0FBZSxRQUFmLENBQVg7QUFDQSxVQUFHLGdCQUFIO0FBQ0csY0FBTSxDQUFOO0FBQUEsUUFDQSxJQUFDLEtBQUQsQ0FBTSxRQUFOLENBQWUsQ0FBQyxPQUFoQixDQUF3QjtpQkFBQSxTQUFDLElBQUQ7QUFDckI7QUFBQSxrQkFBTSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFDLElBQUcsQ0FBQyxNQUFNLENBQUMsSUFBWixDQUFpQixLQUFDLElBQWxCLENBQWpCLEVBQ0g7QUFBQSxtQkFBSyxPQUFPLENBQUMsUUFBUixDQUFpQixLQUFHLElBQUksQ0FBQyxHQUF6QixDQUFMO0FBQUEsY0FDQSxNQUFNLEtBQUMsS0FEUDtBQUFBLGNBRUEsU0FBUyxLQUFDLFlBQVcsQ0FBQyxPQUZ0QjtBQUFBLGNBR0EsZ0JBQWdCLEtBQUMsWUFBVyxDQUFDLGNBSDdCO0FBQUEsY0FJQSxpQkFBaUIsS0FBQyxZQUFXLENBQUMsZUFKOUI7YUFERyxDQUFOO21CQU1BLE9BQVUsR0FBSCxHQUFZLENBQVosR0FBbUIsRUFQTDtVQUFBO1FBQUEsUUFBeEIsQ0FEQTtBQUFBLFFBU0Esc0JBQWMsU0FBUyxJQUFULEVBQWUsR0FBZixDQVRkO0FBVUEsZUFBTyxHQUFQLENBWEg7T0FBQTtBQWFHLGNBQVUsVUFBTSxDQUFDLEtBQVAsQ0FBYSxnREFBYixDQUFWO0FBQ0EsWUFBRyxnQkFBSDtVQUNHLFNBQVMsR0FBVCxFQURIO1NBQUE7QUFJRyxnQkFBTSxHQUFOLENBSkg7U0FkSDtPQUZLO0lBQUEsQ0F0U1I7O0FBQUEsNkJBNFRBLGFBQVksU0FBQyxRQUFELEVBQVcsSUFBWCxFQUFpQixRQUFqQjtBQUNUO0FBQUEsaUJBQVcsS0FBSyxDQUFDLFFBQU4sQ0FBZSxRQUFmLENBQVg7QUFBQSxNQUNBLFdBQVcsSUFBSSxDQUFDLFNBQUwsQ0FBZSxRQUFmLENBRFg7O1FBRUEsT0FBUTtPQUZSOztRQUdBLElBQUksQ0FBQyxXQUFZLElBQUksQ0FBQyxRQUFMLENBQWMsUUFBZDtPQUhqQjtBQUFBLE1BSUEsYUFBYSxFQUFFLENBQUMsZ0JBQUgsQ0FBb0IsUUFBcEIsQ0FKYjtBQUFBLE1BS0EsVUFBVSxDQUFDLEVBQVgsQ0FBYyxPQUFkLEVBQXVCLEtBQUssQ0FBQyxRQUFOLENBQWUsUUFBZixDQUF2QixDQUxBO0FBQUEsTUFNQSxjQUFjLElBQUMsYUFBRCxDQUFjLElBQWQsQ0FOZDthQU9BLFVBQVUsQ0FBQyxJQUFYLENBQWdCLEtBQUssQ0FBQyxhQUFOLENBQW9CLElBQUMsVUFBckIsQ0FBaEIsQ0FBZ0QsQ0FBQyxJQUFqRCxDQUFzRCxXQUF0RCxDQUNHLENBQUMsRUFESixDQUNPLE9BRFAsRUFDZ0IsS0FBSyxDQUFDLFFBQU4sQ0FBZSxTQUFDLENBQUQ7ZUFBTyxTQUFTLElBQVQsRUFBZSxDQUFmLEVBQVA7TUFBQSxDQUFmLENBRGhCLENBRUcsQ0FBQyxFQUZKLENBRU8sT0FGUCxFQUVnQixLQUFLLENBQUMsUUFBTixDQUFlLFFBQWYsQ0FGaEIsRUFSUztJQUFBLENBNVRaOztBQUFBLDZCQXdVQSxhQUFZLFNBQUMsUUFBRCxFQUFXLFFBQVgsRUFBcUIsUUFBckI7QUFDVDtBQUFBLGlCQUFXLEtBQUssQ0FBQyxRQUFOLENBQWUsUUFBZixDQUFYO0FBQUEsTUFDQSxXQUFXLElBQUksQ0FBQyxTQUFMLENBQWUsUUFBZixDQURYO0FBQUEsTUFFQSxhQUFhLElBQUMsY0FBRCxDQUFlLFFBQWYsQ0FGYjtBQUFBLE1BR0EsY0FBYyxFQUFFLENBQUMsaUJBQUgsQ0FBcUIsUUFBckIsQ0FIZDthQUlBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLFdBQWhCLENBQ0csQ0FBQyxFQURKLENBQ08sUUFEUCxFQUNpQixLQUFLLENBQUMsUUFBTixDQUFlLFFBQWYsQ0FEakIsQ0FFRyxDQUFDLEVBRkosQ0FFTyxPQUZQLEVBRWdCLEtBQUssQ0FBQyxRQUFOLENBQWUsUUFBZixDQUZoQixFQUxTO0lBQUEsQ0F4VVo7OzBCQUFBOztLQUYwQixLQUFLLENBQUMsV0FSbkMsQ0FGSDtDQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBOztBQUFBLElBQUcsTUFBTSxDQUFDLFFBQVY7QUFFRyxZQUFVLEdBQUcsQ0FBQyxPQUFKLENBQVksU0FBWixDQUFWO0FBQUEsRUFDQSxVQUFVLEdBQUcsQ0FBQyxPQUFKLENBQVksU0FBWixDQURWO0FBQUEsRUFFQSxPQUFPLEdBQUcsQ0FBQyxPQUFKLENBQVksdUJBQVosQ0FGUDtBQUFBLEVBR0EsWUFBWSxHQUFHLENBQUMsT0FBSixDQUFZLGNBQVosQ0FIWjtBQUFBLEVBSUEsUUFBUSxHQUFHLENBQUMsT0FBSixDQUFZLE9BQVosQ0FKUjtBQUFBLEVBS0EsUUFBUSxHQUFHLENBQUMsT0FBSixDQUFZLE9BQVosQ0FMUjtBQUFBLEVBVUEsY0FBYyxTQUFDLElBQUQsRUFBTyxRQUFQO0FBQ1g7QUFBQSxhQUFTLE9BQU8sQ0FBQyxRQUFSLENBQWlCLEtBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsbUJBQTdDLENBQVQ7QUFBQSxJQUNBLE9BQU8sU0FBUyxDQUFDLElBQVYsQ0FBZSxNQUFmLEVBQXVCLElBQUMsTUFBeEIsRUFBK0IsRUFBL0IsQ0FBa0MsQ0FBQyxlQUFuQyxFQURQO0FBQUEsSUFFQSxJQUFJLENBQUMsRUFBTCxDQUFRLFFBQVIsRUFBa0I7YUFBQTtBQUVmO0FBQUEsZ0JBQVEsS0FBQyxHQUFFLENBQUMsVUFBSixDQUFrQixLQUFDLEtBQUYsR0FBTyxRQUF4QixDQUFSO0FBQUEsUUFFQSxTQUFTLEtBQUssQ0FBQyxJQUFOLENBQ047QUFBQSxVQUNHLDJDQUEyQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxtQkFEdkU7QUFBQSxVQUVHLFFBQ0c7QUFBQSxpQkFBSyxDQUFMO1dBSE47U0FETSxFQU1OO0FBQUEsVUFDRyxRQUNHO0FBQUEsb0JBQVEsQ0FBUjtBQUFBLFlBQ0EsVUFBVSxDQURWO1dBRk47QUFBQSxVQUlHLE1BQ0c7QUFBQSx3REFBNEMsQ0FBNUM7V0FMTjtTQU5NLENBRlQ7ZUFpQkEsTUFBTSxDQUFDLEtBQVAsQ0FBYSxTQUFDLEdBQUQsRUFBTSxLQUFOO0FBQ1Y7QUFBQSxjQUFHLEdBQUg7QUFDRyxnQkFBSSxDQUFDLFdBQUw7QUFDQSxtQkFBTyxTQUFTLEdBQVQsQ0FBUCxDQUZIO1dBQUE7QUFJQSxnQkFBTyxTQUFTLENBQWhCO0FBQ0csa0JBQU0sQ0FBQyxLQUFQO0FBQUEsWUFDQSxJQUFJLENBQUMsV0FBTCxFQURBO0FBRUEsbUJBQU8sVUFBUCxDQUhIO1dBSkE7QUFTQSxjQUFPLFVBQVMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQXpDO0FBQ0csa0JBQU0sQ0FBQyxLQUFQO0FBQUEsWUFDQSxJQUFJLENBQUMsV0FBTCxFQURBO0FBRUEsbUJBQU8sVUFBUCxDQUhIO1dBVEE7QUFBQSxVQWVBLFNBQVMsS0FBQyxHQUFFLENBQUMsVUFBSixDQUFrQixLQUFDLEtBQUYsR0FBTyxTQUF4QixDQWZUO0FBQUEsVUFpQkEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQXpCLEdBQWdELENBQWpFLENBakJBO2lCQW1CQSxNQUFNLENBQUMsT0FBUCxDQUFlLFNBQUMsR0FBRCxFQUFNLEtBQU47QUFFWixnQkFBRyxHQUFIO0FBQ0csa0JBQUksQ0FBQyxXQUFMO0FBQ0EscUJBQU8sU0FBUyxHQUFULENBQVAsQ0FGSDthQUFBO21CQUlBLEtBQUssQ0FBQyxTQUFOLENBQWdCLEtBQWhCLEVBQXVCLENBQXZCLEVBQ0csU0FBQyxJQUFELEVBQU8sRUFBUDtBQUNHO0FBQUEsa0JBQUcsR0FBSDtBQUNHLHVCQUFPLENBQUMsS0FBUixDQUFjLDBCQUFkLEVBQTBDLEdBQTFDO0FBQUEsZ0JBQ0EsR0FBRyxHQUFILENBREEsQ0FESDtlQUFBO0FBR0E7QUFBQSx1QkFBTyxHQUFPLFVBQU0sQ0FBQyxLQUFQLENBQWEsb0JBQWIsQ0FBUCxDQUFQO2VBSEE7QUFBQSxjQUlBLFNBQVMsT0FBTyxDQUFDLFFBQVIsQ0FBaUIsS0FBRyxJQUFJLENBQUMsR0FBekIsQ0FKVDtBQUFBLGNBS0EsV0FBVyxTQUFTLENBQUMsSUFBVixDQUFlLE1BQWYsRUFBdUIsS0FBQyxNQUF4QixFQUErQixFQUEvQixDQUFrQyxDQUFDLGVBQW5DLEVBTFg7QUFBQSxjQU1BLFFBQVEsQ0FBQyxFQUFULENBQVksUUFBWixFQUFzQjt1QkFDbkIsS0FBSyxDQUFDLE1BQU4sQ0FBYTtrQkFFUCxTQUFDLEVBQUQ7MkJBQVEsTUFBTSxDQUFDLE1BQVAsQ0FBYztBQUFBLHNCQUFFLFVBQVUsTUFBWjtBQUFBLHNCQUFvQixHQUFHLENBQXZCO3FCQUFkLEVBQ0w7QUFBQSxzQkFBRSxNQUFNO0FBQUEsd0JBQUUsVUFBVSxNQUFaO0FBQUEsd0JBQW9CLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQXpCLEdBQWdELENBQXZFO3VCQUFSO3FCQURLLEVBRUwsRUFGSyxFQUFSO2tCQUFBLENBRk8sRUFNUCxTQUFDLEVBQUQ7MkJBQVEsS0FBSyxDQUFDLE1BQU4sQ0FBYTtBQUFBLHNCQUFFLEtBQUssTUFBUDtxQkFBYixFQUE4QixFQUE5QixFQUFSO2tCQUFBLENBTk87aUJBQWIsRUFRRyxTQUFDLEdBQUQsRUFBTSxHQUFOO0FBQ0csc0JBQWlCLEdBQWpCO0FBQUEsMkJBQU8sR0FBRyxHQUFILENBQVA7bUJBQUE7QUFDQSxzQkFBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxvQkFBekIsS0FBaUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQWpGO0FBQ0csNEJBQVEsQ0FBQyxVQUFUOzJCQUNBLEtBRkg7bUJBQUE7MkJBS0csTUFBTSxDQUFDLE1BQVAsQ0FBYztBQUFBLHNCQUFFLFVBQVUsTUFBWjtBQUFBLHNCQUFvQixHQUFHLENBQXZCO3FCQUFkLEVBQ0c7QUFBQSxzQkFBRSxNQUFNO0FBQUEsd0JBQUUsVUFBVSxNQUFaO0FBQUEsd0JBQW9CLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQWhEO3VCQUFSO3FCQURILEVBRUcsU0FBQyxHQUFELEVBQU0sR0FBTjtBQUNHLDhCQUFRLENBQUMsVUFBVDtBQUNBLDBCQUFpQixHQUFqQjtBQUFBLCtCQUFPLEdBQUcsR0FBSCxDQUFQO3VCQURBOzZCQUVBLEtBSEg7b0JBQUEsQ0FGSCxFQUxIO21CQUZIO2dCQUFBLENBUkgsRUFEbUI7Y0FBQSxDQUF0QixDQU5BO0FBQUEsY0E0QkEsUUFBUSxDQUFDLEVBQVQsQ0FBWSxXQUFaLEVBQXlCO3VCQUFNLEdBQU8sVUFBTSxDQUFDLEtBQVAsQ0FBYSxxQkFBYixDQUFQLEVBQU47Y0FBQSxDQUF6QixDQTVCQTtBQUFBLGNBNkJBLFFBQVEsQ0FBQyxFQUFULENBQVksU0FBWixFQUF1Qjt1QkFBTSxHQUFPLFVBQU0sQ0FBQyxLQUFQLENBQWEsbUJBQWIsQ0FBUCxFQUFOO2NBQUEsQ0FBdkIsQ0E3QkE7cUJBOEJBLFFBQVEsQ0FBQyxFQUFULENBQVksT0FBWixFQUFxQixTQUFDLEdBQUQ7QUFDbEIsdUJBQU8sQ0FBQyxLQUFSLENBQWMsOEJBQTRCLElBQUksQ0FBQyxHQUEvQyxFQUFzRCxHQUF0RDt1QkFDQSxHQUFHLEdBQUgsRUFGa0I7Y0FBQSxDQUFyQixFQS9CSDtZQUFBLENBREgsRUFtQ0csU0FBQyxHQUFEO0FBQ0c7QUFBQSxrQkFBRyxHQUFIO0FBQ0csb0JBQUksQ0FBQyxXQUFMO0FBQ0EsdUJBQU8sU0FBUyxHQUFULENBQVAsQ0FGSDtlQUFBO0FBQUEsY0FJQSxhQUNFO0FBQUEseUJBQVMsTUFBVDtBQUFBLGdCQUNBLE1BQU0sS0FBRyxLQUFDLEtBRFY7ZUFMRjtxQkFRQSxLQUFDLEdBQUUsQ0FBQyxPQUFKLENBQVksVUFBWixFQUF3QixTQUFDLEdBQUQsRUFBTSxPQUFOO0FBQ3RCLG9CQUFHLEdBQUg7QUFDRyxzQkFBSSxDQUFDLFdBQUw7QUFDQSx5QkFBTyxTQUFTLEdBQVQsQ0FBUCxDQUZIO2lCQUFBO3VCQUlBLEtBQUssQ0FBQyxNQUFOLENBQWE7QUFBQSxrQkFBRSxLQUFLLE1BQVA7aUJBQWIsRUFBOEI7QUFBQSxrQkFBRSxNQUFNO0FBQUEsb0JBQUUsUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxrQkFBbkM7QUFBQSxvQkFBdUQsS0FBSyxPQUFPLENBQUMsR0FBcEU7bUJBQVI7aUJBQTlCLEVBQ0c7eUJBQUEsU0FBQyxHQUFELEVBQU0sR0FBTjtBQUNHLHdCQUFJLENBQUMsV0FBTDsyQkFDQSxTQUFTLEdBQVQsRUFGSDtrQkFBQTtnQkFBQSxRQURILEVBTHNCO2NBQUEsQ0FBeEIsRUFUSDtZQUFBLENBbkNILEVBTlk7VUFBQSxDQUFmLEVBcEJVO1FBQUEsQ0FBYixFQW5CZTtNQUFBO0lBQUEsUUFBbEIsQ0FGQTtBQUFBLElBcUdBLElBQUksQ0FBQyxFQUFMLENBQVEsY0FBUixFQUF3QjthQUNyQixJQUFJLENBQUMsU0FBTCxFQUFnQixDQUFDLElBQWpCLENBQXNCLFNBQXRCLEVBQWlDLFNBQUMsRUFBRDtBQUM5QjtpQkFDRyxPQUFPLENBQUMsSUFBUixDQUFhLHVDQUFiLEVBREg7U0FEOEI7TUFBQSxDQUFqQyxFQURxQjtJQUFBLENBQXhCLENBckdBO0FBQUEsSUF5R0EsSUFBSSxDQUFDLEVBQUwsQ0FBUSxTQUFSLEVBQW1CO2FBQU0sU0FBYSxVQUFNLENBQUMsS0FBUCxDQUFhLG1CQUFiLENBQWIsRUFBTjtJQUFBLENBQW5CLENBekdBO0FBQUEsSUEwR0EsSUFBSSxDQUFDLEVBQUwsQ0FBUSxXQUFSLEVBQXFCO2FBQU0sU0FBYSxVQUFNLENBQUMsS0FBUCxDQUFhLHFCQUFiLENBQWIsRUFBTjtJQUFBLENBQXJCLENBMUdBO1dBMkdBLElBQUksQ0FBQyxFQUFMLENBQVEsT0FBUixFQUFpQixTQUFDLEdBQUQ7YUFBUyxTQUFTLEdBQVQsRUFBVDtJQUFBLENBQWpCLEVBNUdXO0VBQUEsQ0FWZDtBQUFBLEVBMEhBLHdCQUF3QixTQUFDLE1BQUQsRUFBUyxLQUFULEVBQWdCLFNBQWhCO0FBQ3JCO0FBQUEsV0FBTztBQUFBLE1BQUUsS0FBSyxLQUFLLENBQUMsWUFBTiwyREFBb0MsQ0FBRSxxQ0FBdEMsQ0FBUDtLQUFQLENBRHFCO0VBQUEsQ0ExSHhCO0FBQUEsRUE2SEEseUJBQXlCLFNBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxJQUFYO0FBR3RCO0FBQUEsNEVBQTRCLENBQUUsc0NBQTlCO0FBQ0csYUFBTyxDQUFDLEtBQVIsQ0FBYyw0Q0FBZDtBQUFBLE1BQ0EsR0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekIsQ0FEQTtBQUFBLE1BRUEsR0FBRyxDQUFDLEdBQUosRUFGQTtBQUdBLGFBSkg7S0FBQTtBQUFBLElBTUEsWUFBWSxHQUFHLENBQUMsU0FBUyxDQUFDLE1BTjFCO0FBQUEsSUFPQSxTQUFTLENBQUMsa0JBQVYsR0FBK0IsU0FBUyxTQUFTLENBQUMsa0JBQW5CLENBUC9CO0FBQUEsSUFRQSxTQUFTLENBQUMsb0JBQVYsR0FBaUMsU0FBUyxTQUFTLENBQUMsb0JBQW5CLENBUmpDO0FBQUEsSUFTQSxTQUFTLENBQUMsb0JBQVYsR0FBaUMsU0FBUyxTQUFTLENBQUMsb0JBQW5CLENBVGpDO0FBQUEsSUFVQSxTQUFTLENBQUMsa0JBQVYsR0FBK0IsU0FBUyxTQUFTLENBQUMsa0JBQW5CLENBVi9CO0FBQUEsSUFXQSxTQUFTLENBQUMseUJBQVYsR0FBc0MsU0FBUyxTQUFTLENBQUMseUJBQW5CLENBWHRDO0FBYUEsUUFBRyxHQUFHLENBQUMsYUFBSixHQUFvQixDQUF2QjtBQUNHLFlBQU8sU0FBUyxDQUFDLGtCQUFWLElBQWdDLEdBQUcsQ0FBQyxhQUEzQztBQUNHLFdBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO0FBQUEsUUFDQSxHQUFHLENBQUMsR0FBSixFQURBO0FBRUEsZUFISDtPQURIO0tBYkE7QUFvQkEsVUFBUSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBWCxLQUF3QixTQUFTLENBQUMsa0JBQW5DLEtBQ0EsQ0FBQyxTQUFTLENBQUMsb0JBQVYsSUFBa0MsU0FBUyxDQUFDLG9CQUE3QyxDQURBLElBRUEsQ0FBQyxTQUFTLENBQUMsa0JBQVYsR0FBNkIsU0FBUyxDQUFDLGtCQUF2QyxJQUE2RCxTQUFTLENBQUMsb0JBQVYsR0FBK0IsQ0FBN0YsQ0FGQSxJQUdBLENBQUMsU0FBUyxDQUFDLHlCQUFWLEtBQXVDLFNBQVMsQ0FBQyxrQkFBbEQsQ0FIQSxJQUlBLENBQUMsQ0FBQyxTQUFTLENBQUMsb0JBQVYsS0FBa0MsU0FBUyxDQUFDLG9CQUE3QyxLQUNBLENBQUMsU0FBUyxDQUFDLHlCQUFWLEdBQXNDLElBQUUsU0FBUyxDQUFDLGtCQUFuRCxDQURELENBSkQsQ0FBUDtBQU9HLFNBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO0FBQUEsTUFDQSxHQUFHLENBQUMsR0FBSixFQURBO0FBRUEsYUFUSDtLQXBCQTtBQUFBLElBK0JBLGFBQ0c7QUFBQSxjQUFRLFNBQVMsQ0FBQyx5QkFBbEI7QUFBQSxNQUNBLDJDQUEyQyxTQUFTLENBQUMsbUJBRHJEO0FBQUEsTUFFQSw0Q0FBNEMsU0FBUyxDQUFDLG9CQUZ0RDtLQWhDSDtBQUFBLElBcUNBLGFBQWEsSUFBQyxRQUFELENBQVMsVUFBVCxFQUFxQjtBQUFBLE1BQUUsUUFBUTtBQUFBLFFBQUUsS0FBSyxDQUFQO09BQVY7S0FBckIsQ0FyQ2I7QUF1Q0EsUUFBRyxVQUFIO0FBR0csU0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7YUFDQSxHQUFHLENBQUMsR0FBSixHQUpIO0tBQUE7QUFPRyxTQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFwQixHQUFpQyxTQUFqQztBQUFBLE1BQ0EsY0FBYyxJQUFDLGFBQUQsQ0FDWDtBQUFBLGtCQUFVLGdCQUFjLFNBQVMsQ0FBQyxtQkFBeEIsR0FBNEMsR0FBNUMsR0FBK0MsU0FBUyxDQUFDLG9CQUF6RCxHQUE4RSxHQUE5RSxHQUFpRixTQUFTLENBQUMsb0JBQXJHO0FBQUEsUUFDQSxVQUFVLEdBQUcsQ0FBQyxNQUFNLENBQUMsUUFEckI7T0FEVyxDQURkO0FBS0E7QUFDRyxXQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QjtBQUFBLFFBQ0EsR0FBRyxDQUFDLEdBQUosRUFEQTtBQUVBLGVBSEg7T0FMQTthQVVBLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLElBQXpCLENBQThCLEtBQUssQ0FBQyxhQUFOLENBQW9CLElBQUMsVUFBckIsQ0FBOUIsQ0FBOEQsQ0FBQyxJQUEvRCxDQUFvRSxXQUFwRSxDQUNHLENBQUMsRUFESixDQUNPLE9BRFAsRUFDZ0IsS0FBSyxDQUFDLFFBQU4sQ0FBZTtlQUFBLFNBQUMsT0FBRDtBQUN6QixjQUFHLE9BQUg7bUJBRUcsV0FBVyxDQUFDLElBQVosQ0FBaUIsS0FBakIsRUFBb0IsR0FBRyxDQUFDLE1BQXhCLEVBQWdDLFNBQUMsR0FBRDtBQUM3QixrQkFBRyxHQUFIO0FBQ0csdUJBQU8sQ0FBQyxLQUFSLENBQWMsa0RBQWQsRUFBa0UsR0FBbEU7QUFBQSxnQkFDQSxHQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QixDQURBLENBREg7ZUFBQTtBQUlHLG1CQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QixFQUpIO2VBQUE7cUJBS0EsR0FBRyxDQUFDLEdBQUosR0FONkI7WUFBQSxDQUFoQyxFQUZIO1dBQUE7QUFXRyxtQkFBTyxDQUFDLEtBQVIsQ0FBYywrQkFBZDtBQUFBLFlBQ0EsR0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekIsQ0FEQTttQkFFQSxHQUFHLENBQUMsR0FBSixHQWJIO1dBRHlCO1FBQUE7TUFBQSxRQUFmLENBRGhCLENBa0JHLENBQUMsRUFsQkosQ0FrQk8sT0FsQlAsRUFrQmdCLEtBQUssQ0FBQyxRQUFOLENBQWU7ZUFBQSxTQUFDLEdBQUQ7QUFDekIsaUJBQU8sQ0FBQyxLQUFSLENBQWMsZUFBZCxFQUErQixHQUEvQjtBQUFBLFVBQ0EsR0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekIsQ0FEQTtpQkFFQSxHQUFHLENBQUMsR0FBSixHQUh5QjtRQUFBO01BQUEsUUFBZixDQWxCaEIsRUFqQkg7S0ExQ3NCO0VBQUEsQ0E3SHpCO0FBQUEsRUErTUEsdUJBQXVCLFNBQUMsTUFBRCxFQUFTLEtBQVQ7QUFDcEI7QUFBQSxRQUFJO0FBQUEsTUFBRSxLQUFLLEtBQUssQ0FBQyxZQUFOLENBQW1CLEtBQUssQ0FBQyxtQkFBekIsQ0FBUDtLQUFKO0FBQ0EsV0FBTyxDQUFQLENBRm9CO0VBQUEsQ0EvTXZCO0FBQUEsRUFzTkEsd0JBQXdCLFNBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxJQUFYO0FBQ3JCO0FBQUEsWUFBUSxHQUFHLENBQUMsS0FBWjtBQUFBLElBQ0EsYUFDRztBQUFBLFdBQUs7UUFDRjtBQUFBLFVBQ0csS0FBSyxLQUFLLENBQUMsWUFBTixDQUFtQixLQUFLLENBQUMsbUJBQXpCLENBRFI7QUFBQSxVQUVHLFFBQVEsU0FBUyxLQUFLLENBQUMsa0JBQWYsQ0FGWDtTQURFLEVBS0Y7QUFBQSxVQUNHLFFBQVEsU0FBUyxLQUFLLENBQUMseUJBQWYsQ0FEWDtBQUFBLFVBRUcsMkNBQTJDLEtBQUssQ0FBQyxtQkFGcEQ7QUFBQSxVQUdHLDRDQUE0QyxTQUFTLEtBQUssQ0FBQyxvQkFBZixDQUgvQztTQUxFO09BQUw7S0FGSDtBQUFBLElBY0EsU0FBUyxJQUFDLFFBQUQsQ0FBUyxVQUFULEVBQXFCO0FBQUEsTUFBRSxRQUFRO0FBQUEsUUFBRSxLQUFLLENBQVA7T0FBVjtLQUFyQixDQWRUO0FBZUEsUUFBRyxNQUFIO0FBRUcsU0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekIsRUFGSDtLQUFBO0FBS0csU0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekIsRUFMSDtLQWZBO1dBc0JBLEdBQUcsQ0FBQyxHQUFKLEdBdkJxQjtFQUFBLENBdE54QjtBQUFBLEVBZ1BBLEtBQUssQ0FBQyxjQUFOLEdBQXVCO0lBQ3BCO0FBQUEsTUFDRyxRQUFRLE1BRFg7QUFBQSxNQUVHLE1BQU0sS0FBSyxDQUFDLGFBRmY7QUFBQSxNQUdHLFFBQVEsb0JBSFg7QUFBQSxNQUlHLFNBQVMscUJBSlo7S0FEb0IsRUFPcEI7QUFBQSxNQUNHLFFBQVEsTUFEWDtBQUFBLE1BRUcsTUFBTSxLQUFLLENBQUMsYUFGZjtBQUFBLE1BR0csUUFBUSxxQkFIWDtBQUFBLE1BSUcsU0FBUyxzQkFKWjtLQVBvQixFQWFwQjtBQUFBLE1BQ0csUUFBUSxLQURYO0FBQUEsTUFFRyxNQUFNLEtBQUssQ0FBQyxhQUZmO0FBQUEsTUFHRyxRQUFRLG9CQUhYO0FBQUEsTUFJRyxTQUFTLHFCQUpaO0tBYm9CO0dBaFB2QixDQUZIO0NBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7O0FBQUEsSUFBRyxNQUFNLENBQUMsUUFBVjtBQUVHLFlBQVUsR0FBRyxDQUFDLE9BQUosQ0FBWSxTQUFaLENBQVY7QUFBQSxFQUNBLGVBQWUsR0FBRyxDQUFDLE9BQUosQ0FBWSxlQUFaLENBRGY7QUFBQSxFQUVBLFVBQVUsR0FBRyxDQUFDLE9BQUosQ0FBWSxTQUFaLENBRlY7QUFBQSxFQUdBLE9BQU8sR0FBRyxDQUFDLE9BQUosQ0FBWSx1QkFBWixDQUhQO0FBQUEsRUFJQSxZQUFZLEdBQUcsQ0FBQyxPQUFKLENBQVksY0FBWixDQUpaO0FBQUEsRUFLQSxRQUFRLEdBQUcsQ0FBQyxPQUFKLENBQVksT0FBWixDQUxSO0FBQUEsRUFPQSxxQkFBcUIsU0FBQyxHQUFEO0FBQ2xCO0FBQUEsa0JBQWMsNkRBQWQ7QUFBQSxJQUNBLFNBQVMsV0FBVyxDQUFDLElBQVosQ0FBaUIsR0FBRyxDQUFDLE9BQVEsZ0JBQTdCLENBRFQ7NkJBRUEsTUFBUSxhQUFSLHNCQUFjLE1BQVEsY0FISjtFQUFBLENBUHJCO0FBQUEsRUFhQSxpQkFBaUIsU0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLElBQVg7QUFFZDtBQUFBLFdBQU8sS0FBSyxDQUFDLFFBQU4sQ0FBZSxJQUFmLENBQVA7QUFFQSxVQUFPLEdBQUcsQ0FBQyxNQUFKLEtBQWMsTUFBZCxJQUF5QixJQUFPLENBQUMsS0FBeEM7QUFDRztBQUNBLGFBRkg7S0FGQTtBQUFBLElBTUEsR0FBRyxDQUFDLEtBQUosR0FBWSxJQU5aO0FBQUEsSUFRQSxlQUFlLEtBUmY7QUFBQSxJQVNBLGdCQUFnQixTQUFDLEdBQUQsRUFBTSxHQUFOLEVBQWdCLE9BQWhCOztRQUFNLE1BQU07T0FDekI7O1FBRDZCLFVBQVU7T0FDdkM7QUFBQSxhQUFPLENBQUMsS0FBUixDQUFpQixHQUFELEdBQUssS0FBckIsRUFBMkIsR0FBM0I7QUFDQTtBQUNHLHVCQUFlLElBQWY7QUFBQSxRQUNBLEdBQUcsQ0FBQyxTQUFKLENBQWMsT0FBZCxFQUF1QixLQUFLLENBQUMsc0JBQTdCLENBREE7ZUFFQSxHQUFHLENBQUMsR0FBSixHQUhIO09BRmE7SUFBQSxDQVRoQjtBQUFBLElBZ0JBLFdBQVcsbUJBQW1CLEdBQW5CLENBaEJYO0FBa0JBO0FBQ0csb0JBQWMsNENBQWQ7QUFDQSxhQUZIO0tBbEJBO0FBQUEsSUFzQkEsU0FBUyxFQXRCVDtBQUFBLElBdUJBLFFBQVEsQ0F2QlI7QUFBQSxJQXdCQSxhQUFhLElBeEJiO0FBQUEsSUF5QkEsV0FBVyxZQXpCWDtBQUFBLElBMEJBLFdBQVcsTUExQlg7QUFBQSxJQTRCQSxJQUFRLFVBQU07QUFBQSxNQUFFLFVBQVUsUUFBWjtLQUFOLENBNUJSO0FBQUEsSUE4QkEsQ0FBQyxDQUFDLEVBQUYsQ0FBSyxNQUFMLEVBQWEsU0FBQyxDQUFEO0FBQ1YsT0FBQyxDQUFDLEVBQUYsQ0FBSyxRQUFMLEVBQWUsU0FBQyxNQUFEO0FBQ1o7QUFBQSxrQkFBVSw2Q0FBVjtBQUFBLFFBQ0EsV0FBVyw0QkFEWDtBQUVBO3dCQUFBO0FBQ0csY0FBRyxNQUFLLGNBQVI7QUFDRyx1QkFBVyxDQUFYLENBREg7V0FBQTtBQUVBLGNBQUcsTUFBSyxxQkFBUjtBQUNHLGdCQUFHLEtBQUssT0FBTyxDQUFDLElBQVIsQ0FBYSxDQUFiLENBQVI7QUFDRywyQkFBYSxDQUFiO0FBQUEsY0FDQSxXQUFXLEVBQUcsR0FEZCxDQURIO2FBQUEsTUFHSyxJQUFHLDhDQUEwQixZQUE3QjtBQUNGLHFCQUFPLEVBQVA7QUFBQSxjQUNBLE9BREE7QUFBQSxjQUVBLENBQUMsQ0FBQyxFQUFGLENBQUssTUFBTCxFQUFhLFNBQUMsQ0FBRDt1QkFDVixRQUFRLENBQUMsQ0FBQyxRQUFGLEdBREU7Y0FBQSxDQUFiLENBRkE7QUFBQSxjQUlBLENBQUMsQ0FBQyxFQUFGLENBQUssS0FBTCxFQUFZO0FBQ1Q7QUFBQSxnQkFDQSxNQUFPLE9BQVAsR0FBZ0IsSUFEaEI7QUFFQSxvQkFBRyxVQUFTLENBQVQsSUFBZSxVQUFsQjtBQUNHLHFCQUFHLENBQUMsU0FBSixHQUNHO0FBQUEsZ0NBQVksVUFBWjtBQUFBLG9CQUNBLFVBQVUsUUFEVjtBQUFBLG9CQUVBLFVBQVUsUUFGVjtBQUFBLG9CQUdBLFFBQVEsTUFIUjttQkFESDtBQUFBLGtCQUtBLGVBQWUsSUFMZjt5QkFNQSxPQVBIO2lCQUhTO2NBQUEsQ0FBWixDQUpBLENBREU7YUFBQTtBQWlCRixxQkFBTyxDQUFDLElBQVIsQ0FBYSxZQUFiLEVBQTJCLENBQTNCLEVBakJFO2FBSlI7V0FISDtBQUFBLFNBRkE7QUE0QkEsWUFBRyxVQUFTLENBQVQsSUFBZSxVQUFsQjtBQUNHLGFBQUcsQ0FBQyxTQUFKLEdBQ0c7QUFBQSx3QkFBWSxVQUFaO0FBQUEsWUFDQSxVQUFVLFFBRFY7QUFBQSxZQUVBLFVBQVUsUUFGVjtBQUFBLFlBR0EsUUFBUSxNQUhSO1dBREg7QUFBQSxVQUtBLGVBQWUsSUFMZjtpQkFNQSxPQVBIO1NBN0JZO01BQUEsQ0FBZjthQXNDQSxDQUFDLENBQUMsRUFBRixDQUFLLE9BQUwsRUFBYyxTQUFDLEdBQUQ7ZUFDWCxjQUFjLHlDQUFkLEVBQXlELEdBQXpELEVBRFc7TUFBQSxDQUFkLEVBdkNVO0lBQUEsQ0FBYixDQTlCQTtBQUFBLElBd0VBLENBQUMsQ0FBQyxFQUFGLENBQUssT0FBTCxFQUFjLFNBQUMsR0FBRDthQUNYLGNBQWMscUNBQWQsRUFBcUQsR0FBckQsRUFEVztJQUFBLENBQWQsQ0F4RUE7QUFBQSxJQTJFQSxDQUFDLENBQUMsRUFBRixDQUFLLFFBQUwsRUFBZTtBQUNaO2VBQ0csY0FBYyx1Q0FBZCxFQURIO09BRFk7SUFBQSxDQUFmLENBM0VBO1dBK0VBLEdBQUcsQ0FBQyxJQUFKLENBQVMsQ0FBVCxFQWpGYztFQUFBLENBYmpCO0FBQUEsRUFzR0EsT0FBTyxTQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsSUFBWDtBQUVKO0FBQUEsUUFBbUQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxRQUFqRTtBQUFBLFNBQUcsQ0FBQyxNQUFNLENBQUMsV0FBWCxHQUF5QixHQUFHLENBQUMsU0FBUyxDQUFDLFFBQXZDO0tBQUE7QUFDQSxRQUFnRCxHQUFHLENBQUMsU0FBUyxDQUFDLFFBQTlEO0FBQUEsU0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFYLEdBQXNCLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBcEM7S0FEQTtBQUFBLElBSUEsU0FBUyxJQUFDLGFBQUQsQ0FBYyxHQUFHLENBQUMsTUFBbEIsQ0FKVDtBQUtBLFFBQUcsTUFBSDthQUNHLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLElBQXpCLENBQThCLEtBQUssQ0FBQyxhQUFOLENBQW9CLElBQUMsVUFBckIsQ0FBOUIsQ0FBOEQsQ0FBQyxJQUEvRCxDQUFvRSxNQUFwRSxDQUNHLENBQUMsRUFESixDQUNPLE9BRFAsRUFDZ0IsU0FBQyxPQUFEO0FBQ1YsWUFBRyxPQUFIO0FBQ0csYUFBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7aUJBQ0EsR0FBRyxDQUFDLEdBQUosR0FGSDtTQURVO01BQUEsQ0FEaEIsQ0FLRyxDQUFDLEVBTEosQ0FLTyxPQUxQLEVBS2dCLFNBQUMsR0FBRDtBQUNWLFdBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2VBQ0EsR0FBRyxDQUFDLEdBQUosR0FGVTtNQUFBLENBTGhCLEVBREg7S0FBQTtBQVVHLFNBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2FBQ0EsR0FBRyxDQUFDLEdBQUosR0FYSDtLQVBJO0VBQUEsQ0F0R1A7QUFBQSxFQThIQSxNQUFNLFNBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxJQUFYO0FBRUg7QUFBQSxjQUFVLEVBQVY7QUFDQTtBQUFBO2lCQUFBO0FBQ0csYUFBUSxHQUFSLEdBQWEsQ0FBYixDQURIO0FBQUEsS0FEQTtBQVFBLFFBQUcsR0FBRyxDQUFDLE9BQVEscUJBQWY7QUFDRyxjQUFRLElBQUksQ0FBQyxLQUFMLENBQVcsR0FBRyxDQUFDLE9BQVEscUJBQXZCLENBQVI7QUFDQSxVQUFHLFNBQVUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFyQixJQUFvQyxDQUFDLEdBQUcsQ0FBQyxPQUFRLHFCQUFaLEtBQW9DLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQXRCLEVBQXBDLElBQTJFLFNBQVMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBdEIsRUFBckYsQ0FBdkM7QUFDRyxXQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsT0FBbkI7QUFBQSxRQUNBLEdBQUcsQ0FBQyxHQUFKLEVBREE7QUFFQSxlQUhIO09BRkg7S0FSQTtBQWdCQSxRQUFHLEdBQUcsQ0FBQyxPQUFRLFNBQWY7QUFFRSxtQkFBYSxHQUFiO0FBQUEsTUFHQSxRQUFRLEdBQUcsQ0FBQyxPQUFRLFNBQVEsQ0FBQyxPQUFyQixDQUE2QixRQUE3QixFQUF1QyxFQUF2QyxDQUEwQyxDQUFDLEtBQTNDLENBQWlELEdBQWpELENBSFI7QUFBQSxNQUlBLFFBQVEsU0FBUyxLQUFNLEdBQWYsRUFBbUIsRUFBbkIsQ0FKUjtBQUFBLE1BS0EsTUFBTSxDQUFJLEtBQU0sR0FBVCxHQUFpQixTQUFTLEtBQU0sR0FBZixFQUFtQixFQUFuQixDQUFqQixHQUE2QyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQVgsR0FBb0IsQ0FBbEUsQ0FMTjtBQVFBLFVBQUcsQ0FBQyxRQUFRLENBQVQsS0FBZSxDQUFDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFuQixDQUFmLElBQTZDLENBQUMsUUFBUSxHQUFULENBQTdDLElBQThELE1BQU0sS0FBTixDQUE5RCxJQUE4RSxNQUFNLEdBQU4sQ0FBakY7QUFDRSxlQUFRLGlCQUFSLEdBQTJCLFdBQVcsSUFBWCxHQUFrQixHQUFHLENBQUMsTUFBTSxDQUFDLE1BQXhEO0FBQUEsUUFDQSxHQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsT0FBbkIsQ0FEQTtBQUFBLFFBRUEsR0FBRyxDQUFDLEdBQUosRUFGQTtBQUdBLGVBSkY7T0FSQTtBQUFBLE1BZUEsWUFBWSxDQUFDLE1BQU0sS0FBUCxJQUFnQixDQWY1QjtBQUFBLE1Ba0JBLE9BQVEsaUJBQVIsR0FBMkIsV0FBVyxLQUFYLEdBQW1CLEdBQW5CLEdBQXlCLEdBQXpCLEdBQStCLEdBQS9CLEdBQXFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFsQjNFO0FBQUEsTUFtQkEsT0FBUSxpQkFBUixHQUEyQixPQW5CM0I7QUFBQSxNQW9CQSxPQUFRLGdCQUFSLEdBQTBCLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FwQnJDO0FBQUEsTUFxQkEsT0FBUSxrQkFBUixHQUE0QixTQXJCNUI7QUFBQSxNQXNCQSxPQUFRLGlCQUFSLEdBQTJCLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQXRCLEVBdEIzQjtBQXlCQSxVQUFPLEdBQUcsQ0FBQyxNQUFKLEtBQWMsTUFBckI7QUFDRyxpQkFBUyxJQUFDLGNBQUQsQ0FDUDtBQUFBLGVBQUssR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFoQjtTQURPLEVBR1A7QUFBQSxpQkFDRTtBQUFBLG1CQUFPLEtBQVA7QUFBQSxZQUNBLEtBQUssR0FETDtXQURGO1NBSE8sQ0FBVCxDQURIO09BM0JGO0tBQUE7QUF1Q0UsbUJBQWEsR0FBYjtBQUFBLE1BR0EsT0FBUSxnQkFBUixHQUEwQixHQUFHLENBQUMsTUFBTSxDQUFDLFdBSHJDO0FBQUEsTUFJQSxPQUFRLGVBQVIsR0FBeUIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUpwQztBQUFBLE1BS0EsT0FBUSxrQkFBUixHQUE0QixHQUFHLENBQUMsTUFBTSxDQUFDLE1BTHZDO0FBQUEsTUFNQSxPQUFRLGlCQUFSLEdBQTJCLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQXRCLEVBTjNCO0FBU0EsVUFBTyxHQUFHLENBQUMsTUFBSixLQUFjLE1BQXJCO0FBQ0csaUJBQVMsSUFBQyxjQUFELENBQWU7QUFBQSxVQUFFLEtBQUssR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFsQjtTQUFmLENBQVQsQ0FESDtPQWhERjtLQWhCQTtBQW9FQSxRQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFWLElBQXVCLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQW5CLE9BQW9DLE1BQTVELEtBQXVFLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBcEY7QUFDRSxpQkFBVyxnRUFBd0MsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFuRCxDQUFYO0FBQUEsTUFDQSxPQUFRLHVCQUFSLEdBQWlDLDRCQUEwQixRQUExQixHQUFtQyx1QkFBbkMsR0FBMEQsUUFEM0YsQ0FERjtLQXBFQTtBQXlFQSxRQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBVixJQUFvQixNQUFJLENBQU0sU0FBUyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQW5CLENBQU4sQ0FBM0I7QUFDRSxhQUFRLGlCQUFSLEdBQTJCLGFBQWEsU0FBUyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQW5CLENBQWIsR0FBdUMsV0FBbEUsQ0FERjtLQXpFQTtBQTZFQSxRQUFHLEdBQUcsQ0FBQyxNQUFKLEtBQWMsTUFBakI7QUFDRSxTQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsT0FBbkI7QUFBQSxNQUNBLEdBQUcsQ0FBQyxHQUFKLEVBREE7QUFFQSxhQUhGO0tBN0VBO0FBbUZBLFFBQUcsTUFBSDtBQUNHLFNBQUcsQ0FBQyxTQUFKLENBQWMsVUFBZCxFQUEwQixPQUExQjthQUNBLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixDQUNHLENBQUMsRUFESixDQUNPLE9BRFAsRUFDZ0I7ZUFDVixHQUFHLENBQUMsR0FBSixHQURVO01BQUEsQ0FEaEIsQ0FHRyxDQUFDLEVBSEosQ0FHTyxPQUhQLEVBR2dCLFNBQUMsR0FBRDtBQUNWLFdBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2VBQ0EsR0FBRyxDQUFDLEdBQUosQ0FBUSxHQUFSLEVBRlU7TUFBQSxDQUhoQixFQUZIO0tBQUE7QUFTRyxTQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QjthQUNBLEdBQUcsQ0FBQyxHQUFKLEdBVkg7S0FyRkc7RUFBQSxDQTlITjtBQUFBLEVBcU9BLE1BQU0sU0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLElBQVg7QUFHSDtBQUFBLFFBQUcsR0FBRyxDQUFDLE9BQVEsZ0JBQWY7QUFDRyxTQUFHLENBQUMsTUFBTSxDQUFDLFdBQVgsR0FBeUIsR0FBRyxDQUFDLE9BQVEsZ0JBQXJDLENBREg7S0FBQTtBQUFBLElBSUEsU0FBUyxJQUFDLGFBQUQsQ0FBYyxHQUFHLENBQUMsTUFBbEIsQ0FKVDtBQUtBLFFBQUcsTUFBSDthQUNHLEdBQUcsQ0FBQyxJQUFKLENBQVMsS0FBSyxDQUFDLGFBQU4sQ0FBb0IsSUFBQyxVQUFyQixDQUFULENBQXlDLENBQUMsSUFBMUMsQ0FBK0MsTUFBL0MsQ0FDRyxDQUFDLEVBREosQ0FDTyxPQURQLEVBQ2dCLFNBQUMsT0FBRDtBQUNWLFlBQUcsT0FBSDtBQUNHLGFBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2lCQUNBLEdBQUcsQ0FBQyxHQUFKLEdBRkg7U0FBQTtBQUFBO1NBRFU7TUFBQSxDQURoQixDQU1HLENBQUMsRUFOSixDQU1PLE9BTlAsRUFNZ0IsU0FBQyxHQUFEO0FBQ1YsV0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7ZUFDQSxHQUFHLENBQUMsR0FBSixDQUFRLEdBQVIsRUFGVTtNQUFBLENBTmhCLEVBREg7S0FBQTtBQVdHLFNBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2FBQ0EsR0FBRyxDQUFDLEdBQUosQ0FBVyxHQUFHLENBQUMsR0FBTCxHQUFTLGFBQW5CLEVBWkg7S0FSRztFQUFBLENBck9OO0FBQUEsRUFpUUEsTUFBTSxTQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsSUFBWDtBQUVILFFBQUMsT0FBRCxDQUFRLEdBQUcsQ0FBQyxNQUFaO0FBQUEsSUFDQSxHQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QixDQURBO1dBRUEsR0FBRyxDQUFDLEdBQUosR0FKRztFQUFBLENBalFOO0FBQUEsRUEwUUEscUJBQXFCLFNBQUMsSUFBRDtBQUdsQjtBQUFBO2tCQUFBO0FBRUcsVUFBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVQsT0FBMEIsTUFBN0I7QUFDRyxZQUFDLE9BQU0sQ0FBQyxJQUFSLENBQWEsQ0FBQyxDQUFDLElBQWYsRUFBcUIsY0FBckIsRUFESDtPQUFBO0FBQUEsTUFJQSxJQUFDLE9BQU8sRUFBQyxDQUFDLE1BQUYsQ0FBUixDQUFrQixDQUFDLENBQUMsSUFBcEIsRUFBNkI7ZUFBQSxTQUFDLENBQUQ7aUJBRTFCLFNBQUMsR0FBRCxFQUFNLEdBQU4sRUFBVyxJQUFYO0FBR0c7QUFBQSxnQkFBdUQsdURBQXZEO0FBQUEsaUJBQUcsQ0FBQyxNQUFNLENBQUMsR0FBWCxHQUFpQixLQUFLLENBQUMsWUFBTixDQUFtQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQTlCLENBQWpCO2FBQUE7QUFDQSxnQkFBcUQsd0RBQXJEO0FBQUEsaUJBQUcsQ0FBQyxLQUFLLENBQUMsR0FBVixHQUFnQixLQUFLLENBQUMsWUFBTixDQUFtQixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQTdCLENBQWhCO2FBREE7QUFBQSxZQUlBLHlDQUFpQixDQUFFLElBQVYsQ0FBZSxLQUFmLEVBQWtCLEdBQUcsQ0FBQyxNQUFKLElBQWMsRUFBaEMsRUFBb0MsR0FBRyxDQUFDLEtBQUosSUFBYSxFQUFqRCxFQUFxRCxHQUFHLENBQUMsU0FBekQsVUFKVDtBQUtBLGdCQUFPLGNBQVA7QUFFRyxpQkFBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7QUFBQSxjQUNBLEdBQUcsQ0FBQyxHQUFKLEVBREEsQ0FGSDthQUFBO0FBT0csaUJBQUcsQ0FBQyxNQUFKLEdBQWEsS0FBQyxRQUFELENBQVMsTUFBVCxDQUFiO0FBQ0Esc0JBQVUsQ0FBQyxNQUFYO0FBQ0csbUJBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO0FBQUEsZ0JBQ0EsR0FBRyxDQUFDLEdBQUosRUFEQTtBQUVBLHVCQUhIO2VBREE7QUFPQSxzQkFBTyxHQUFHLENBQUMsTUFBWDtBQUFBLHFCQUNRLE1BRFI7QUFBQSxxQkFDZ0IsS0FEaEI7QUFFTSw0QkFBWSxDQUFDLGdCQUFnQixDQUFDLElBQXZCLENBQTRCLEtBQTVCLEVBQStCLE1BQS9CLEVBQXVDLEdBQUcsQ0FBQyxZQUEzQyxFQUF5RCxHQUFHLENBQUMsTUFBN0QsQ0FBUDtBQUNHLHVCQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QjtBQUFBLG9CQUNBLEdBQUcsQ0FBQyxHQUFKLEVBREE7QUFFQSwyQkFISDttQkFGTjtBQUNnQjtBQURoQixxQkFNUSxNQU5SO0FBQUEscUJBTWdCLEtBTmhCO0FBT00scUJBQUcsQ0FBQyxhQUFKLEdBQW9CLEtBQUMsY0FBckI7QUFDQSx3QkFBTyxPQUFPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUF2QixDQUE0QixLQUE1QixFQUErQixPQUEvQixFQUF3QyxHQUFHLENBQUMsWUFBNUMsRUFBMEQsR0FBRyxDQUFDLE1BQTlELENBQVAsQ0FBUDtBQUNHLHVCQUFHLENBQUMsU0FBSixDQUFjLEdBQWQsRUFBbUIsS0FBSyxDQUFDLHNCQUF6QjtBQUFBLG9CQUNBLEdBQUcsQ0FBQyxHQUFKLEVBREE7QUFFQSwyQkFISDttQkFEQTtBQUtBLHNCQUFHLGdDQUF3QixXQUFXLENBQUMsYUFBWixLQUE2QixRQUF4RDtBQUNHLHVCQUFHLENBQUMsYUFBSixHQUFvQixJQUFJLENBQUMsYUFBekIsQ0FESDttQkFMQTtBQU9BLHNCQUFHLEdBQUcsQ0FBQyxhQUFKLEdBQW9CLENBQXZCO0FBQ0csd0JBQU8scUNBQVA7QUFDRyx5QkFBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7QUFBQSxzQkFDQSxHQUFHLENBQUMsR0FBSixFQURBO0FBRUEsNkJBSEg7cUJBQUE7QUFJQSwwQkFBTyxTQUFTLEdBQUcsQ0FBQyxPQUFRLGtCQUFyQixLQUEyQyxHQUFHLENBQUMsYUFBdEQ7QUFDRyx5QkFBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7QUFBQSxzQkFDQSxHQUFHLENBQUMsR0FBSixFQURBO0FBRUEsNkJBSEg7cUJBTEg7bUJBZE47QUFNZ0I7QUFOaEIscUJBdUJRLFFBdkJSO0FBd0JNLDRCQUFZLENBQUMsZ0JBQWdCLENBQUMsSUFBdkIsQ0FBNEIsS0FBNUIsRUFBK0IsUUFBL0IsRUFBeUMsR0FBRyxDQUFDLFlBQTdDLEVBQTJELEdBQUcsQ0FBQyxNQUEvRCxDQUFQO0FBQ0csdUJBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO0FBQUEsb0JBQ0EsR0FBRyxDQUFDLEdBQUosRUFEQTtBQUVBLDJCQUhIO21CQXhCTjtBQXVCUTtBQXZCUixxQkE0QlEsU0E1QlI7QUE2Qk0sd0JBQVEsS0FBSyxDQUFDLGdCQUFnQixDQUFDLElBQXZCLENBQTRCLEtBQTVCLEVBQStCLE1BQS9CLEVBQXVDLEdBQUcsQ0FBQyxZQUEzQyxFQUF5RCxHQUFHLENBQUMsTUFBN0QsS0FDQSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsSUFBdkIsQ0FBNEIsS0FBNUIsRUFBK0IsT0FBL0IsRUFBd0MsR0FBRyxDQUFDLFlBQTVDLEVBQTBELEdBQUcsQ0FBQyxNQUE5RCxDQURBLElBRUEsS0FBSyxDQUFDLGdCQUFnQixDQUFDLElBQXZCLENBQTRCLEtBQTVCLEVBQStCLFFBQS9CLEVBQXlDLEdBQUcsQ0FBQyxZQUE3QyxFQUEyRCxHQUFHLENBQUMsTUFBL0QsQ0FGRCxDQUFQO0FBR0csdUJBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO0FBQUEsb0JBQ0EsR0FBRyxDQUFDLEdBQUosRUFEQTtBQUVBLDJCQUxIO21CQTdCTjtBQTRCUTtBQTVCUjtBQW9DTSxxQkFBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEtBQUssQ0FBQyxzQkFBekI7QUFBQSxrQkFDQSxHQUFHLENBQUMsR0FBSixFQURBO0FBRUEseUJBdENOO0FBQUEsZUFQQTtxQkErQ0EsT0F0REg7YUFSSDtVQUFBLEVBRjBCO1FBQUE7TUFBQSxRQUFILENBQUksQ0FBSixDQUExQixDQUpBO0FBdUVBLFVBQUcsUUFBUSxDQUFDLE9BQVQsS0FBb0IsVUFBdkI7QUFDRyxZQUFDLE9BQU8sRUFBQyxDQUFDLE1BQUYsQ0FBUixDQUFrQixDQUFDLENBQUMsSUFBcEIsRUFBMEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFWLENBQWUsSUFBZixDQUExQixFQURIO09BekVIO0FBQUE7V0E2RUEsSUFBQyxPQUFNLENBQUMsS0FBUixDQUFjLElBQWQsQ0FDRyxDQUFDLElBREosQ0FDUyxHQUFHLENBQUMsSUFBSixDQUFTLElBQVQsQ0FEVCxDQUVHLENBQUMsR0FGSixDQUVRLEdBQUcsQ0FBQyxJQUFKLENBQVMsSUFBVCxDQUZSLENBR0csQ0FBQyxHQUhKLENBR1EsR0FBRyxDQUFDLElBQUosQ0FBUyxJQUFULENBSFIsQ0FJRyxDQUFDLElBSkosQ0FJUyxJQUFJLENBQUMsSUFBTCxDQUFVLElBQVYsQ0FKVCxDQUtHLENBQUMsUUFBRCxDQUxILENBS1csR0FBRyxDQUFDLElBQUosQ0FBUyxJQUFULENBTFgsQ0FNRyxDQUFDLEdBTkosQ0FNUSxTQUFDLEdBQUQsRUFBTSxHQUFOLEVBQVcsSUFBWDtBQUNGLFNBQUcsQ0FBQyxTQUFKLENBQWMsR0FBZCxFQUFtQixLQUFLLENBQUMsc0JBQXpCO2FBQ0EsR0FBRyxDQUFDLEdBQUosR0FGRTtJQUFBLENBTlIsRUFoRmtCO0VBQUEsQ0ExUXJCO0FBQUEsRUFzV0EseUJBQXlCLFNBQUMsU0FBRDtBQUN0QjtBQUFBLGdEQUFzQixDQUFFLE9BQWQsQ0FDUDtBQUFBLHFDQUNHO0FBQUEsb0JBQ0c7QUFBQSw4RUFBYSxRQUFRLENBQUUsZUFBVixDQUEwQixTQUExQixVQUFiO1NBREg7T0FESDtLQURPLFVBQVY7QUFJQSw4QkFBTyxPQUFPLENBQUUsYUFBVCxJQUFnQixJQUF2QixDQUxzQjtFQUFBLENBdFd6QjtBQUFBLEVBZ1hBLGNBQWMsU0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLElBQVg7QUFDWDtBQUFBLFFBQU8sd0JBQVA7QUFFRyxVQUFHLG9FQUFIO0FBQ0csV0FBRyxDQUFDLFlBQUosR0FBbUIsdUJBQXVCLEdBQUcsQ0FBQyxPQUFRLGdCQUFuQyxDQUFuQixDQURIO09BQUEsTUFHSyxJQUFHLHNFQUFIO0FBQ0YsV0FBRyxDQUFDLFlBQUosR0FBbUIsdUJBQXVCLEdBQUcsQ0FBQyxPQUFRLGdCQUFuQyxDQUFuQixDQURFO09BQUE7QUFHRixXQUFHLENBQUMsWUFBSixHQUFtQixJQUFuQixDQUhFO09BTFI7S0FBQTtXQVNBLE9BVlc7RUFBQSxDQWhYZDtBQUFBLEVBNlhBLEtBQUssQ0FBQyxlQUFOLEdBQXdCLFNBQUMsT0FBRDtBQUdyQjtBQUFBLFFBQUcsT0FBTyxDQUFDLFNBQVg7QUFDRyxVQUF5QixvQkFBekI7QUFBQSxlQUFPLENBQUMsSUFBUixHQUFlLEVBQWY7T0FBQTtBQUFBLE1BQ0Esb0JBQW9CLEVBRHBCO0FBQUEsTUFFQSxnQkFBZ0IsRUFGaEI7QUFHQTtBQUFBO21CQUFBO0FBQ0csWUFBRyxDQUFDLENBQUMsSUFBRixLQUFVLEtBQUssQ0FBQyxhQUFuQjtBQUNHLDJCQUFpQixDQUFDLElBQWxCLENBQXVCLENBQXZCLEVBREg7U0FBQTtBQUdHLHVCQUFhLENBQUMsSUFBZCxDQUFtQixDQUFuQixFQUhIO1NBREg7QUFBQSxPQUhBO0FBQUEsTUFRQSxvQkFBb0IsaUJBQWlCLENBQUMsTUFBbEIsQ0FBeUIsS0FBSyxDQUFDLGNBQS9CLENBUnBCO0FBQUEsTUFTQSxPQUFPLENBQUMsSUFBUixHQUFlLGlCQUFpQixDQUFDLE1BQWxCLENBQXlCLGFBQXpCLENBVGYsQ0FESDtLQUFBO0FBYUEsNkNBQWUsQ0FBRSxnQkFBZCxHQUF1QixDQUExQjtBQUNHLFVBQUksT0FBTyxDQUFDLE1BQVIsRUFBSjtBQUFBLE1BQ0EsQ0FBQyxDQUFDLEdBQUYsQ0FBTSxPQUFPLENBQUMsS0FBUixFQUFOLENBREE7QUFBQSxNQUVBLENBQUMsQ0FBQyxHQUFGLENBQU0sY0FBTixDQUZBO0FBQUEsTUFHQSxDQUFDLENBQUMsR0FBRixDQUFNLFdBQU4sQ0FIQTtBQUFBLE1BSUEsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEdBQTFCLENBQThCLElBQUMsUUFBL0IsRUFBd0MsS0FBSyxDQUFDLFFBQU4sQ0FBZSxDQUFmLENBQXhDLENBSkE7QUFBQSxNQU9BLElBQUMsT0FBRCxHQUFVLE9BQU8sQ0FBQyxNQUFSLEVBUFY7QUFBQSxNQVFBLGtCQUFrQixDQUFDLElBQW5CLENBQXdCLElBQXhCLEVBQTJCLE9BQU8sQ0FBQyxJQUFuQyxFQUF5QyxJQUFDLE9BQTFDLENBUkE7YUFTQSxNQUFNLENBQUMsa0JBQWtCLENBQUMsR0FBMUIsQ0FBOEIsSUFBQyxRQUEvQixFQUF3QyxLQUFLLENBQUMsUUFBTixDQUFlLElBQUMsT0FBaEIsQ0FBeEMsRUFWSDtLQWhCcUI7RUFBQSxDQTdYeEIsQ0FGSDtDQUFBIiwiZmlsZSI6Ii9wYWNrYWdlcy92c2l2c2lfZmlsZS1jb2xsZWN0aW9uLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuIyAgICAgQ29weXJpZ2h0IChDKSAyMDE0LTIwMTYgYnkgVmF1Z2huIEl2ZXJzb25cbiMgICAgIGZpbGVDb2xsZWN0aW9uIGlzIGZyZWUgc29mdHdhcmUgcmVsZWFzZWQgdW5kZXIgdGhlIE1JVC9YMTEgbGljZW5zZS5cbiMgICAgIFNlZSBpbmNsdWRlZCBMSUNFTlNFIGZpbGUgZm9yIGRldGFpbHMuXG4jIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG5cbnNoYXJlLmRlZmF1bHRDaHVua1NpemUgPSAyKjEwMjQqMTAyNCAtIDEwMjRcbnNoYXJlLmRlZmF1bHRSb290ID0gJ2ZzJ1xuXG5zaGFyZS5yZXN1bWFibGVCYXNlID0gJy9fcmVzdW1hYmxlJ1xuXG5zaGFyZS5pbnNlcnRfZnVuYyA9IChmaWxlID0ge30sIGNodW5rU2l6ZSkgLT5cbiAgIHRyeVxuICAgICAgaWQgPSBuZXcgTW9uZ28uT2JqZWN0SUQoXCIje2ZpbGUuX2lkfVwiKVxuICAgY2F0Y2hcbiAgICAgIGlkID0gbmV3IE1vbmdvLk9iamVjdElEKClcbiAgIHN1YkZpbGUgPSB7fVxuICAgc3ViRmlsZS5faWQgPSBpZFxuICAgc3ViRmlsZS5sZW5ndGggPSAwXG4gICBzdWJGaWxlLm1kNSA9ICdkNDFkOGNkOThmMDBiMjA0ZTk4MDA5OThlY2Y4NDI3ZSdcbiAgIHN1YkZpbGUudXBsb2FkRGF0ZSA9IG5ldyBEYXRlKClcbiAgIHN1YkZpbGUuY2h1bmtTaXplID0gY2h1bmtTaXplXG4gICBzdWJGaWxlLmZpbGVuYW1lID0gZmlsZS5maWxlbmFtZSA/ICcnXG4gICBzdWJGaWxlLm1ldGFkYXRhID0gZmlsZS5tZXRhZGF0YSA/IHt9XG4gICBzdWJGaWxlLmFsaWFzZXMgPSBmaWxlLmFsaWFzZXMgPyBbXVxuICAgc3ViRmlsZS5jb250ZW50VHlwZSA9IGZpbGUuY29udGVudFR5cGUgPyAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJ1xuICAgcmV0dXJuIHN1YkZpbGVcblxuc2hhcmUucmVqZWN0X2ZpbGVfbW9kaWZpZXIgPSAobW9kaWZpZXIpIC0+XG5cbiAgIGZvcmJpZGRlbiA9IE1hdGNoLk9uZU9mKFxuICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgX2lkOiAgICAgICAgTWF0Y2guQW55IH0pXG4gICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyBsZW5ndGg6ICAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGNodW5rU2l6ZTogIE1hdGNoLkFueSB9KVxuICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgbWQ1OiAgICAgICAgTWF0Y2guQW55IH0pXG4gICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyB1cGxvYWREYXRlOiBNYXRjaC5BbnkgfSlcbiAgIClcblxuICAgcmVxdWlyZWQgPSBNYXRjaC5PbmVPZihcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IF9pZDogICAgICAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGxlbmd0aDogICAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGNodW5rU2l6ZTogICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IG1kNTogICAgICAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IHVwbG9hZERhdGU6ICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IG1ldGFkYXRhOiAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGFsaWFzZXM6ICAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGZpbGVuYW1lOiAgICBNYXRjaC5BbnkgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7IGNvbnRlbnRUeXBlOiBNYXRjaC5BbnkgfSlcbiAgIClcblxuICAgcmV0dXJuIE1hdGNoLnRlc3QgbW9kaWZpZXIsIE1hdGNoLk9uZU9mKFxuICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJHNldDogZm9yYmlkZGVuIH0pXG4gICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkdW5zZXQ6IHJlcXVpcmVkIH0pXG4gICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkaW5jOiBmb3JiaWRkZW4gfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRtdWw6IGZvcmJpZGRlbiB9KVxuICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJGJpdDogZm9yYmlkZGVuIH0pXG4gICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkbWluOiBmb3JiaWRkZW4gfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRtYXg6IGZvcmJpZGRlbiB9KVxuICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJHJlbmFtZTogcmVxdWlyZWQgfSlcbiAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRjdXJyZW50RGF0ZTogZm9yYmlkZGVuIH0pXG4gICAgICBNYXRjaC5XaGVyZSAocGF0KSAtPiAjIFRoaXMgcmVxdWlyZXMgdGhhdCB0aGUgdXBkYXRlIGlzbid0IGEgcmVwbGFjZW1lbnRcbiAgICAgICAgcmV0dXJuIG5vdCBNYXRjaC50ZXN0IHBhdCwgTWF0Y2guT25lT2YoXG4gICAgICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJGluYzogTWF0Y2guQW55IH0pXG4gICAgICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJHNldDogTWF0Y2guQW55IH0pXG4gICAgICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJHVuc2V0OiBNYXRjaC5BbnkgfSlcbiAgICAgICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkYWRkVG9TZXQ6IE1hdGNoLkFueSB9KVxuICAgICAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRwb3A6IE1hdGNoLkFueSB9KVxuICAgICAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRwdWxsQWxsOiBNYXRjaC5BbnkgfSlcbiAgICAgICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkcHVsbDogTWF0Y2guQW55IH0pXG4gICAgICAgICAgTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgJHB1c2hBbGw6IE1hdGNoLkFueSB9KVxuICAgICAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7ICRwdXNoOiBNYXRjaC5BbnkgfSlcbiAgICAgICAgICBNYXRjaC5PYmplY3RJbmNsdWRpbmcoeyAkYml0OiBNYXRjaC5BbnkgfSlcbiAgICAgICAgKVxuICAgKVxuIiwiIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuIyAgICAgQ29weXJpZ2h0IChDKSAyMDE0LTIwMTYgYnkgVmF1Z2huIEl2ZXJzb25cbiMgICAgIGZpbGVDb2xsZWN0aW9uIGlzIGZyZWUgc29mdHdhcmUgcmVsZWFzZWQgdW5kZXIgdGhlIE1JVC9YMTEgbGljZW5zZS5cbiMgICAgIFNlZSBpbmNsdWRlZCBMSUNFTlNFIGZpbGUgZm9yIGRldGFpbHMuXG4jIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG5cbmlmIE1ldGVvci5pc1NlcnZlclxuXG4gICB0aHJvdWdoMiA9IE5wbS5yZXF1aXJlICd0aHJvdWdoMidcblxuICAgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycyA9XG4gICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvcGxhaW4nXG5cbiAgIHNoYXJlLmNoZWNrX2FsbG93X2RlbnkgPSAodHlwZSwgdXNlcklkLCBmaWxlLCBmaWVsZHMpIC0+XG5cbiAgICAgIGNoZWNrUnVsZXMgPSAocnVsZXMpIC0+XG4gICAgICAgICByZXMgPSBmYWxzZVxuICAgICAgICAgZm9yIGZ1bmMgaW4gcnVsZXNbdHlwZV0gd2hlbiBub3QgcmVzXG4gICAgICAgICAgICByZXMgPSBmdW5jKHVzZXJJZCwgZmlsZSwgZmllbGRzKVxuICAgICAgICAgcmV0dXJuIHJlc1xuXG4gICAgICByZXN1bHQgPSBub3QgY2hlY2tSdWxlcyhAZGVueXMpIGFuZCBjaGVja1J1bGVzKEBhbGxvd3MpXG4gICAgICByZXR1cm4gcmVzdWx0XG5cbiAgIHNoYXJlLmJpbmRfZW52ID0gKGZ1bmMpIC0+XG4gICAgICBpZiBmdW5jP1xuICAgICAgICAgcmV0dXJuIE1ldGVvci5iaW5kRW52aXJvbm1lbnQgZnVuYywgKGVycikgLT4gdGhyb3cgZXJyXG4gICAgICBlbHNlXG4gICAgICAgICByZXR1cm4gZnVuY1xuXG4gICBzaGFyZS5zYWZlT2JqZWN0SUQgPSAocykgLT5cbiAgICAgIGlmIHM/Lm1hdGNoIC9eWzAtOWEtZl17MjR9JC9pICAjIFZhbGlkYXRlIHRoYXQgX2lkIGlzIGEgMTIgYnl0ZSBoZXggc3RyaW5nXG4gICAgICAgICBuZXcgTW9uZ28uT2JqZWN0SUQgc1xuICAgICAgZWxzZVxuICAgICAgICAgbnVsbFxuXG4gICBzaGFyZS5zdHJlYW1DaHVua2VyID0gKHNpemUgPSBzaGFyZS5kZWZhdWx0Q2h1bmtTaXplKSAtPlxuICAgICAgbWFrZUZ1bmNzID0gKHNpemUpIC0+XG4gICAgICAgICBidWZmZXJMaXN0ID0gWyBuZXcgQnVmZmVyKDApIF1cbiAgICAgICAgIHRvdGFsID0gMFxuICAgICAgICAgZmx1c2ggPSAoY2IpIC0+XG4gICAgICAgICAgICBvdXRTaXplID0gaWYgdG90YWwgPiBzaXplIHRoZW4gc2l6ZSBlbHNlIHRvdGFsXG4gICAgICAgICAgICBpZiBvdXRTaXplID4gMFxuICAgICAgICAgICAgICAgb3V0cHV0QnVmZmVyID0gQnVmZmVyLmNvbmNhdCBidWZmZXJMaXN0LCBvdXRTaXplXG4gICAgICAgICAgICAgICB0aGlzLnB1c2ggb3V0cHV0QnVmZmVyXG4gICAgICAgICAgICAgICB0b3RhbCAtPSBvdXRTaXplXG4gICAgICAgICAgICBsYXN0QnVmZmVyID0gYnVmZmVyTGlzdC5wb3AoKVxuICAgICAgICAgICAgbmV3QnVmZmVyID0gbGFzdEJ1ZmZlci5zbGljZShsYXN0QnVmZmVyLmxlbmd0aCAtIHRvdGFsKVxuICAgICAgICAgICAgYnVmZmVyTGlzdCA9IFsgbmV3QnVmZmVyIF1cbiAgICAgICAgICAgIGlmIHRvdGFsIDwgc2l6ZVxuICAgICAgICAgICAgICAgY2IoKVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgZmx1c2guYmluZCh0aGlzKSBjYlxuICAgICAgICAgdHJhbnNmb3JtID0gKGNodW5rLCBlbmMsIGNiKSAtPlxuICAgICAgICAgICAgYnVmZmVyTGlzdC5wdXNoIGNodW5rXG4gICAgICAgICAgICB0b3RhbCArPSBjaHVuay5sZW5ndGhcbiAgICAgICAgICAgIGlmIHRvdGFsIDwgc2l6ZVxuICAgICAgICAgICAgICAgY2IoKVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgZmx1c2guYmluZCh0aGlzKSBjYlxuICAgICAgICAgcmV0dXJuIFt0cmFuc2Zvcm0sIGZsdXNoXVxuICAgICAgcmV0dXJuIHRocm91Z2gyLmFwcGx5IHRoaXMsIG1ha2VGdW5jcyhzaXplKVxuIiwiIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuIyAgICAgQ29weXJpZ2h0IChDKSAyMDE0LTIwMTYgYnkgVmF1Z2huIEl2ZXJzb25cbiMgICAgIGZpbGVDb2xsZWN0aW9uIGlzIGZyZWUgc29mdHdhcmUgcmVsZWFzZWQgdW5kZXIgdGhlIE1JVC9YMTEgbGljZW5zZS5cbiMgICAgIFNlZSBpbmNsdWRlZCBMSUNFTlNFIGZpbGUgZm9yIGRldGFpbHMuXG4jIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG5cbmlmIE1ldGVvci5pc1NlcnZlclxuXG4gICBtb25nb2RiID0gTnBtLnJlcXVpcmUgJ21vbmdvZGInXG4gICBncmlkID0gTnBtLnJlcXVpcmUgJ2dyaWRmcy1sb2NraW5nLXN0cmVhbSdcbiAgIGdyaWRMb2NrcyA9IE5wbS5yZXF1aXJlICdncmlkZnMtbG9ja3MnXG4gICBmcyA9IE5wbS5yZXF1aXJlICdmcydcbiAgIHBhdGggPSBOcG0ucmVxdWlyZSAncGF0aCdcbiAgIGRpY2VyID0gTnBtLnJlcXVpcmUgJ2RpY2VyJ1xuICAgZXhwcmVzcyA9IE5wbS5yZXF1aXJlICdleHByZXNzJ1xuXG4gICBjbGFzcyBGaWxlQ29sbGVjdGlvbiBleHRlbmRzIE1vbmdvLkNvbGxlY3Rpb25cblxuICAgICAgY29uc3RydWN0b3I6IChAcm9vdCA9IHNoYXJlLmRlZmF1bHRSb290LCBvcHRpb25zID0ge30pIC0+XG4gICAgICAgICB1bmxlc3MgQCBpbnN0YW5jZW9mIEZpbGVDb2xsZWN0aW9uXG4gICAgICAgICAgICByZXR1cm4gbmV3IEZpbGVDb2xsZWN0aW9uKEByb290LCBvcHRpb25zKVxuXG4gICAgICAgICB1bmxlc3MgQCBpbnN0YW5jZW9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IgJ1RoZSBnbG9iYWwgZGVmaW5pdGlvbiBvZiBNb25nby5Db2xsZWN0aW9uIGhhcyBjaGFuZ2VkIHNpbmNlIHRoZSBmaWxlLWNvbGxlY3Rpb24gcGFja2FnZSB3YXMgbG9hZGVkLiBQbGVhc2UgZW5zdXJlIHRoYXQgYW55IHBhY2thZ2VzIHRoYXQgcmVkZWZpbmUgTW9uZ28uQ29sbGVjdGlvbiBhcmUgbG9hZGVkIGJlZm9yZSBmaWxlLWNvbGxlY3Rpb24uJ1xuXG4gICAgICAgICB1bmxlc3MgTW9uZ28uQ29sbGVjdGlvbiBpcyBNb25nby5Db2xsZWN0aW9uLnByb3RvdHlwZS5jb25zdHJ1Y3RvclxuICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yICdUaGUgZ2xvYmFsIGRlZmluaXRpb24gb2YgTW9uZ28uQ29sbGVjdGlvbiBoYXMgYmVlbiBwYXRjaGVkIGJ5IGFub3RoZXIgcGFja2FnZSwgYW5kIHRoZSBwcm90b3R5cGUgY29uc3RydWN0b3IgaGFzIGJlZW4gbGVmdCBpbiBhbiBpbmNvbnNpc3RlbnQgc3RhdGUuIFBsZWFzZSBzZWUgdGhpcyBsaW5rIGZvciBhIHdvcmthcm91bmQ6IGh0dHBzOi8vZ2l0aHViLmNvbS92c2l2c2kvbWV0ZW9yLWZpbGUtc2FtcGxlLWFwcC9pc3N1ZXMvMiNpc3N1ZWNvbW1lbnQtMTIwNzgwNTkyJ1xuXG4gICAgICAgICBpZiB0eXBlb2YgQHJvb3QgaXMgJ29iamVjdCdcbiAgICAgICAgICAgIG9wdGlvbnMgPSBAcm9vdFxuICAgICAgICAgICAgQHJvb3QgPSBzaGFyZS5kZWZhdWx0Um9vdFxuXG4gICAgICAgICBAY2h1bmtTaXplID0gb3B0aW9ucy5jaHVua1NpemUgPyBzaGFyZS5kZWZhdWx0Q2h1bmtTaXplXG5cbiAgICAgICAgIEBkYiA9IE1ldGVvci53cmFwQXN5bmMobW9uZ29kYi5Nb25nb0NsaWVudC5jb25uZWN0KShwcm9jZXNzLmVudi5NT05HT19VUkwse30pXG5cbiAgICAgICAgIEBsb2NrT3B0aW9ucyA9XG4gICAgICAgICAgICB0aW1lT3V0OiBvcHRpb25zLmxvY2tzPy50aW1lT3V0ID8gMzYwXG4gICAgICAgICAgICBsb2NrRXhwaXJhdGlvbjogb3B0aW9ucy5sb2Nrcz8ubG9ja0V4cGlyYXRpb24gPyA5MFxuICAgICAgICAgICAgcG9sbGluZ0ludGVydmFsOiBvcHRpb25zLmxvY2tzPy5wb2xsaW5nSW50ZXJ2YWwgPyA1XG5cbiAgICAgICAgIEBsb2NrcyA9IGdyaWRMb2Nrcy5Mb2NrQ29sbGVjdGlvbiBAZGIsXG4gICAgICAgICAgICByb290OiBAcm9vdFxuICAgICAgICAgICAgdGltZU91dDogQGxvY2tPcHRpb25zLnRpbWVPdXRcbiAgICAgICAgICAgIGxvY2tFeHBpcmF0aW9uOiBAbG9ja09wdGlvbnMubG9ja0V4cGlyYXRpb25cbiAgICAgICAgICAgIHBvbGxpbmdJbnRlcnZhbDogQGxvY2tPcHRpb25zLnBvbGxpbmdJbnRlcnZhbFxuXG4gICAgICAgICBAZ2ZzID0gbmV3IGdyaWQoQGRiLCBtb25nb2RiLCBAcm9vdClcblxuICAgICAgICAgQGJhc2VVUkwgPSBvcHRpb25zLmJhc2VVUkwgPyBcIi9ncmlkZnMvI3tAcm9vdH1cIlxuXG4gICAgICAgICAjIGlmIHRoZXJlIGFyZSBIVFRQIG9wdGlvbnMsIHNldHVwIHRoZSBleHByZXNzIEhUVFAgYWNjZXNzIHBvaW50KHMpXG4gICAgICAgICBpZiBvcHRpb25zLnJlc3VtYWJsZSBvciBvcHRpb25zLmh0dHBcbiAgICAgICAgICAgIHNoYXJlLnNldHVwSHR0cEFjY2Vzcy5iaW5kKEApKG9wdGlvbnMpXG5cbiAgICAgICAgICMgRGVmYXVsdCBjbGllbnQgYWxsb3cvZGVueSBwZXJtaXNzaW9uc1xuICAgICAgICAgQGFsbG93cyA9IHsgcmVhZDogW10sIGluc2VydDogW10sIHdyaXRlOiBbXSwgcmVtb3ZlOiBbXSB9XG4gICAgICAgICBAZGVueXMgPSB7IHJlYWQ6IFtdLCBpbnNlcnQ6IFtdLCB3cml0ZTogW10sIHJlbW92ZTogW10gfVxuXG4gICAgICAgICAjIENhbGwgc3VwZXIncyBjb25zdHJ1Y3RvclxuICAgICAgICAgc3VwZXIgQHJvb3QgKyAnLmZpbGVzJywgeyBpZEdlbmVyYXRpb246ICdNT05HTycgfVxuXG4gICAgICAgICAjIERlZmF1bHQgaW5kZXhlc1xuICAgICAgICAgaWYgb3B0aW9ucy5yZXN1bWFibGVcbiAgICAgICAgICAgIGluZGV4T3B0aW9ucyA9IHt9XG4gICAgICAgICAgICBpZiB0eXBlb2Ygb3B0aW9ucy5yZXN1bWFibGVJbmRleE5hbWUgaXMgJ3N0cmluZydcbiAgICAgICAgICAgICAgIGluZGV4T3B0aW9ucy5uYW1lID0gb3B0aW9ucy5yZXN1bWFibGVJbmRleE5hbWVcblxuICAgICAgICAgICAgQGRiLmNvbGxlY3Rpb24oXCIje0Byb290fS5maWxlc1wiKS5lbnN1cmVJbmRleCh7XG4gICAgICAgICAgICAgICAgICAnbWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVJZGVudGlmaWVyJzogMVxuICAgICAgICAgICAgICAgICAgJ21ldGFkYXRhLl9SZXN1bWFibGUucmVzdW1hYmxlQ2h1bmtOdW1iZXInOiAxXG4gICAgICAgICAgICAgICAgICBsZW5ndGg6IDFcbiAgICAgICAgICAgICAgIH0sIGluZGV4T3B0aW9ucylcblxuICAgICAgICAgQG1heFVwbG9hZFNpemUgPSBvcHRpb25zLm1heFVwbG9hZFNpemUgPyAtMSAgIyBOZWdhdGl2ZSBpcyBubyBsaW1pdC4uLlxuXG4gICAgICAgICAjIyBEZWxheSB0aGlzIGZlYXR1cmUgdW50aWwgZGVtYW5kIGlzIGNsZWFyLiBVbml0IHRlc3RzIC8gZG9jdW1lbnRhdGlvbiBuZWVkZWQuXG5cbiAgICAgICAgICMgdW5sZXNzIG9wdGlvbnMuYWRkaXRpb25hbEhUVFBIZWFkZXJzPyBhbmQgKHR5cGVvZiBvcHRpb25zLmFkZGl0aW9uYWxIVFRQSGVhZGVycyBpcyAnb2JqZWN0JylcbiAgICAgICAgICMgICAgb3B0aW9ucy5hZGRpdGlvbmFsSFRUUEhlYWRlcnMgPSB7fVxuICAgICAgICAgI1xuICAgICAgICAgIyBmb3IgaCwgdiBvZiBvcHRpb25zLmFkZGl0aW9uYWxIVFRQSGVhZGVyc1xuICAgICAgICAgIyAgICBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzW2hdID0gdlxuXG4gICAgICAgICAjIFNldHVwIHNwZWNpZmljIGFsbG93L2RlbnkgcnVsZXMgZm9yIGdyaWRGUywgYW5kIHRpZS1pbiB0aGUgYXBwbGljYXRpb24gc2V0dGluZ3NcblxuICAgICAgICAgRmlsZUNvbGxlY3Rpb24uX19zdXBlcl9fLmFsbG93LmJpbmQoQClcbiAgICAgICAgICAgICMgQmVjYXVzZSBhbGxvdyBydWxlcyBhcmUgbm90IGd1YXJhbnRlZWQgdG8gcnVuLFxuICAgICAgICAgICAgIyBhbGwgY2hlY2tpbmcgaXMgZG9uZSBpbiB0aGUgZGVueSBydWxlcyBiZWxvd1xuICAgICAgICAgICAgaW5zZXJ0OiAodXNlcklkLCBmaWxlKSA9PiB0cnVlXG4gICAgICAgICAgICByZW1vdmU6ICh1c2VySWQsIGZpbGUpID0+IHRydWVcblxuICAgICAgICAgRmlsZUNvbGxlY3Rpb24uX19zdXBlcl9fLmRlbnkuYmluZChAKVxuXG4gICAgICAgICAgICBpbnNlcnQ6ICh1c2VySWQsIGZpbGUpID0+XG5cbiAgICAgICAgICAgICAgICMgTWFrZSBkYXJuIHN1cmUgd2UncmUgY3JlYXRpbmcgYSB2YWxpZCBncmlkRlMgLmZpbGVzIGRvY3VtZW50XG4gICAgICAgICAgICAgICBjaGVjayBmaWxlLFxuICAgICAgICAgICAgICAgICAgX2lkOiBNb25nby5PYmplY3RJRFxuICAgICAgICAgICAgICAgICAgbGVuZ3RoOiBNYXRjaC5XaGVyZSAoeCkgPT5cbiAgICAgICAgICAgICAgICAgICAgIGNoZWNrIHgsIE1hdGNoLkludGVnZXJcbiAgICAgICAgICAgICAgICAgICAgIHggaXMgMFxuICAgICAgICAgICAgICAgICAgbWQ1OiBNYXRjaC5XaGVyZSAoeCkgPT5cbiAgICAgICAgICAgICAgICAgICAgIGNoZWNrIHgsIFN0cmluZ1xuICAgICAgICAgICAgICAgICAgICAgeCBpcyAnZDQxZDhjZDk4ZjAwYjIwNGU5ODAwOTk4ZWNmODQyN2UnICMgVGhlIG1kNSBvZiBhbiBlbXB0eSBmaWxlXG4gICAgICAgICAgICAgICAgICB1cGxvYWREYXRlOiBEYXRlXG4gICAgICAgICAgICAgICAgICBjaHVua1NpemU6IE1hdGNoLldoZXJlICh4KSA9PlxuICAgICAgICAgICAgICAgICAgICAgY2hlY2sgeCwgTWF0Y2guSW50ZWdlclxuICAgICAgICAgICAgICAgICAgICAgeCBpcyBAY2h1bmtTaXplXG4gICAgICAgICAgICAgICAgICBmaWxlbmFtZTogU3RyaW5nXG4gICAgICAgICAgICAgICAgICBjb250ZW50VHlwZTogU3RyaW5nXG4gICAgICAgICAgICAgICAgICBhbGlhc2VzOiBbIFN0cmluZyBdXG4gICAgICAgICAgICAgICAgICBtZXRhZGF0YTogT2JqZWN0XG5cbiAgICAgICAgICAgICAgICMgRW5mb3JjZSBhIHVuaWZvcm0gY2h1bmtTaXplXG4gICAgICAgICAgICAgICB1bmxlc3MgZmlsZS5jaHVua1NpemUgaXMgQGNodW5rU2l6ZVxuICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuIFwiSW52YWxpZCBjaHVua3NpemVcIlxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWVcblxuICAgICAgICAgICAgICAgIyBjYWxsIGFwcGxpY2F0aW9uIHJ1bGVzXG4gICAgICAgICAgICAgICBpZiBzaGFyZS5jaGVja19hbGxvd19kZW55LmJpbmQoQCkgJ2luc2VydCcsIHVzZXJJZCwgZmlsZVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG5cbiAgICAgICAgICAgICAgIHJldHVybiB0cnVlXG5cbiAgICAgICAgICAgIHVwZGF0ZTogKHVzZXJJZCwgZmlsZSwgZmllbGRzKSA9PlxuICAgICAgICAgICAgICAgIyMgQ293Ym95IHVwZGF0ZXMgYXJlIG5vdCBjdXJyZW50bHkgYWxsb3dlZCBmcm9tIHRoZSBjbGllbnQuIFRvbyBtdWNoIHRvIHNjcmV3IHVwLlxuICAgICAgICAgICAgICAgIyMgRm9yIGV4YW1wbGUsIGlmIHlvdSBzdG9yZSBmaWxlIG93bmVyc2hpcCBpbmZvIGluIGEgc3ViIGRvY3VtZW50IHVuZGVyICdtZXRhZGF0YSdcbiAgICAgICAgICAgICAgICMjIGl0IHdpbGwgYmUgY29tcGxpY2F0ZWQgdG8gZ3VhcmQgYWdhaW5zdCB0aGF0IGJlaW5nIGNoYW5nZWQgaWYgeW91IGFsbG93IG90aGVyIHBhcnRzXG4gICAgICAgICAgICAgICAjIyBvZiB0aGUgbWV0YWRhdGEgc3ViIGRvYyB0byBiZSB1cGRhdGVkLiBXcml0ZSBzcGVjaWZpYyBNZXRlb3IgbWV0aG9kcyBpbnN0ZWFkIHRvXG4gICAgICAgICAgICAgICAjIyBhbGxvdyByZWFzb25hYmxlIGNoYW5nZXMgdG8gdGhlIFwibWV0YWRhdGFcIiBwYXJ0cyBvZiB0aGUgZ3JpZEZTIGZpbGUgcmVjb3JkLlxuICAgICAgICAgICAgICAgcmV0dXJuIHRydWVcblxuICAgICAgICAgICAgcmVtb3ZlOiAodXNlcklkLCBmaWxlKSA9PlxuICAgICAgICAgICAgICAgIyMgUmVtb3ZlIGlzIG5vdyBoYW5kbGVkIHZpYSB0aGUgZGVmYXVsdCBtZXRob2Qgb3ZlcnJpZGUgYmVsb3csIHNvIHRoaXMgc2hvdWxkXG4gICAgICAgICAgICAgICAjIyBOZXZlciBiZSBjYWxsZWQuXG4gICAgICAgICAgICAgICByZXR1cm4gdHJ1ZVxuXG4gICAgICAgICBzZWxmID0gQCAjIE5lY2Vzc2FyeSBpbiB0aGUgbWV0aG9kIGRlZmluaXRpb24gYmVsb3dcblxuICAgICAgICAgTWV0ZW9yLnNlcnZlci5tZXRob2RfaGFuZGxlcnNbXCIje0BfcHJlZml4fXJlbW92ZVwiXSA9IChzZWxlY3RvcikgLT5cblxuICAgICAgICAgICAgY2hlY2sgc2VsZWN0b3IsIE9iamVjdFxuXG4gICAgICAgICAgICB1bmxlc3MgTG9jYWxDb2xsZWN0aW9uLl9zZWxlY3RvcklzSWRQZXJoYXBzQXNPYmplY3Qoc2VsZWN0b3IpXG4gICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIDQwMywgXCJOb3QgcGVybWl0dGVkLiBVbnRydXN0ZWQgY29kZSBtYXkgb25seSByZW1vdmUgZG9jdW1lbnRzIGJ5IElELlwiXG5cbiAgICAgICAgICAgIGZpbGUgPSBzZWxmLmZpbmRPbmUgc2VsZWN0b3JcbiAgICAgICAgICAgIGlmIGZpbGVcbiAgICAgICAgICAgICAgIGlmIHNoYXJlLmNoZWNrX2FsbG93X2RlbnkuYmluZChzZWxmKSAncmVtb3ZlJywgdGhpcy51c2VySWQsIGZpbGVcbiAgICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLnJlbW92ZSBmaWxlXG4gICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIDQwMywgXCJBY2Nlc3MgZGVuaWVkXCJcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgIHJldHVybiAwXG5cbiAgICAgICMgUmVnaXN0ZXIgYXBwbGljYXRpb24gYWxsb3cgcnVsZXNcbiAgICAgIGFsbG93OiAoYWxsb3dPcHRpb25zKSAtPlxuICAgICAgICAgZm9yIHR5cGUsIGZ1bmMgb2YgYWxsb3dPcHRpb25zXG4gICAgICAgICAgICB1bmxlc3MgdHlwZSBvZiBAYWxsb3dzXG4gICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIFwiVW5yZWNvZ25pemVkIGFsbG93IHJ1bGUgdHlwZSAnI3t0eXBlfScuXCJcbiAgICAgICAgICAgIHVubGVzcyB0eXBlb2YgZnVuYyBpcyAnZnVuY3Rpb24nXG4gICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIFwiQWxsb3cgcnVsZSAje3R5cGV9IG11c3QgYmUgYSB2YWxpZCBmdW5jdGlvbi5cIlxuICAgICAgICAgICAgQGFsbG93c1t0eXBlXS5wdXNoKGZ1bmMpXG5cbiAgICAgICMgUmVnaXN0ZXIgYXBwbGljYXRpb24gZGVueSBydWxlc1xuICAgICAgZGVueTogKGRlbnlPcHRpb25zKSAtPlxuICAgICAgICAgZm9yIHR5cGUsIGZ1bmMgb2YgZGVueU9wdGlvbnNcbiAgICAgICAgICAgIHVubGVzcyB0eXBlIG9mIEBkZW55c1xuICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciBcIlVucmVjb2duaXplZCBkZW55IHJ1bGUgdHlwZSAnI3t0eXBlfScuXCJcbiAgICAgICAgICAgIHVubGVzcyB0eXBlb2YgZnVuYyBpcyAnZnVuY3Rpb24nXG4gICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yIFwiRGVueSBydWxlICN7dHlwZX0gbXVzdCBiZSBhIHZhbGlkIGZ1bmN0aW9uLlwiXG4gICAgICAgICAgICBAZGVueXNbdHlwZV0ucHVzaChmdW5jKVxuXG4gICAgICBpbnNlcnQ6IChmaWxlID0ge30sIGNhbGxiYWNrID0gdW5kZWZpbmVkKSAtPlxuICAgICAgICAgZmlsZSA9IHNoYXJlLmluc2VydF9mdW5jIGZpbGUsIEBjaHVua1NpemVcbiAgICAgICAgIHN1cGVyIGZpbGUsIGNhbGxiYWNrXG5cbiAgICAgICMgVXBkYXRlIGlzIGRhbmdlcm91cyEgVGhlIGNoZWNrcyBpbnNpZGUgYXR0ZW1wdCB0byBrZWVwIHlvdSBvdXQgb2ZcbiAgICAgICMgdHJvdWJsZSB3aXRoIGdyaWRGUy4gQ2xpZW50cyBjYW4ndCB1cGRhdGUgYXQgYWxsLiBCZSBjYXJlZnVsIVxuICAgICAgIyBPbmx5IG1ldGFkYXRhLCBmaWxlbmFtZSwgYWxpYXNlcyBhbmQgY29udGVudFR5cGUgc2hvdWxkIGV2ZXIgYmUgY2hhbmdlZFxuICAgICAgIyBkaXJlY3RseSBieSBhIHNlcnZlci5cblxuICAgICAgdXBkYXRlOiAoc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zID0ge30sIGNhbGxiYWNrID0gdW5kZWZpbmVkKSAtPlxuICAgICAgICAgaWYgbm90IGNhbGxiYWNrPyBhbmQgdHlwZW9mIG9wdGlvbnMgaXMgJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgY2FsbGJhY2sgPSBvcHRpb25zXG4gICAgICAgICAgICBvcHRpb25zID0ge31cblxuICAgICAgICAgaWYgb3B0aW9ucy51cHNlcnQ/XG4gICAgICAgICAgICBlcnIgPSBuZXcgTWV0ZW9yLkVycm9yIFwiVXBkYXRlIGRvZXMgbm90IHN1cHBvcnQgdGhlIHVwc2VydCBvcHRpb25cIlxuICAgICAgICAgICAgaWYgY2FsbGJhY2s/XG4gICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sgZXJyXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICB0aHJvdyBlcnJcblxuICAgICAgICAgaWYgc2hhcmUucmVqZWN0X2ZpbGVfbW9kaWZpZXIobW9kaWZpZXIpIGFuZCBub3Qgb3B0aW9ucy5mb3JjZVxuICAgICAgICAgICAgZXJyID0gbmV3IE1ldGVvci5FcnJvciBcIk1vZGlmeWluZyBncmlkRlMgcmVhZC1vbmx5IGRvY3VtZW50IGVsZW1lbnRzIGlzIGEgdmVyeSBiYWQgaWRlYSFcIlxuICAgICAgICAgICAgaWYgY2FsbGJhY2s/XG4gICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sgZXJyXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN1cGVyIHNlbGVjdG9yLCBtb2RpZmllciwgb3B0aW9ucywgY2FsbGJhY2tcblxuICAgICAgdXBzZXJ0OiAoc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zID0ge30sIGNhbGxiYWNrID0gdW5kZWZpbmVkKSAtPlxuICAgICAgICAgaWYgbm90IGNhbGxiYWNrPyBhbmQgdHlwZW9mIG9wdGlvbnMgaXMgJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgY2FsbGJhY2sgPSBvcHRpb25zXG4gICAgICAgICBlcnIgPSBuZXcgTWV0ZW9yLkVycm9yIFwiRmlsZSBDb2xsZWN0aW9ucyBkbyBub3Qgc3VwcG9ydCAndXBzZXJ0J1wiXG4gICAgICAgICBpZiBjYWxsYmFjaz9cbiAgICAgICAgICAgIGNhbGxiYWNrIGVyclxuICAgICAgICAgZWxzZVxuICAgICAgICAgICAgdGhyb3cgZXJyXG5cbiAgICAgIHVwc2VydFN0cmVhbTogKGZpbGUsIG9wdGlvbnMgPSB7fSwgY2FsbGJhY2sgPSB1bmRlZmluZWQpIC0+XG4gICAgICAgICBpZiBub3QgY2FsbGJhY2s/IGFuZCB0eXBlb2Ygb3B0aW9ucyBpcyAnZnVuY3Rpb24nXG4gICAgICAgICAgICBjYWxsYmFjayA9IG9wdGlvbnNcbiAgICAgICAgICAgIG9wdGlvbnMgPSB7fVxuICAgICAgICAgY2FsbGJhY2sgPSBzaGFyZS5iaW5kX2VudiBjYWxsYmFja1xuICAgICAgICAgY2JDYWxsZWQgPSBmYWxzZVxuICAgICAgICAgbW9kcyA9IHt9XG4gICAgICAgICBtb2RzLmZpbGVuYW1lID0gZmlsZS5maWxlbmFtZSBpZiBmaWxlLmZpbGVuYW1lP1xuICAgICAgICAgbW9kcy5hbGlhc2VzID0gZmlsZS5hbGlhc2VzIGlmIGZpbGUuYWxpYXNlcz9cbiAgICAgICAgIG1vZHMuY29udGVudFR5cGUgPSBmaWxlLmNvbnRlbnRUeXBlIGlmIGZpbGUuY29udGVudFR5cGU/XG4gICAgICAgICBtb2RzLm1ldGFkYXRhID0gZmlsZS5tZXRhZGF0YSBpZiBmaWxlLm1ldGFkYXRhP1xuXG4gICAgICAgICBvcHRpb25zLmF1dG9SZW5ld0xvY2sgPz0gdHJ1ZVxuXG4gICAgICAgICBpZiBvcHRpb25zLm1vZGUgaXMgJ3crJ1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciBcIlRoZSBhYmlsaXR5IHRvIGFwcGVuZCBmaWxlIGRhdGEgaW4gdXBzZXJ0U3RyZWFtKCkgd2FzIHJlbW92ZWQgaW4gdmVyc2lvbiAxLjAuMFwiXG5cbiAgICAgICAgICMgTWFrZSBzdXJlIHRoYXQgd2UgaGF2ZSBhbiBJRCBhbmQgaXQncyB2YWxpZFxuICAgICAgICAgaWYgZmlsZS5faWRcbiAgICAgICAgICAgIGZvdW5kID0gQGZpbmRPbmUge19pZDogZmlsZS5faWR9XG5cbiAgICAgICAgIHVubGVzcyBmaWxlLl9pZCBhbmQgZm91bmRcbiAgICAgICAgICAgIGZpbGUuX2lkID0gQGluc2VydCBtb2RzXG4gICAgICAgICBlbHNlIGlmIE9iamVjdC5rZXlzKG1vZHMpLmxlbmd0aCA+IDBcbiAgICAgICAgICAgIEB1cGRhdGUgeyBfaWQ6IGZpbGUuX2lkIH0sIHsgJHNldDogbW9kcyB9XG5cbiAgICAgICAgIHdyaXRlU3RyZWFtID0gTWV0ZW9yLndyYXBBc3luYyhAZ2ZzLmNyZWF0ZVdyaXRlU3RyZWFtLmJpbmQoQGdmcykpXG4gICAgICAgICAgICByb290OiBAcm9vdFxuICAgICAgICAgICAgX2lkOiBtb25nb2RiLk9iamVjdElEKFwiI3tmaWxlLl9pZH1cIilcbiAgICAgICAgICAgIG1vZGU6ICd3J1xuICAgICAgICAgICAgdGltZU91dDogQGxvY2tPcHRpb25zLnRpbWVPdXRcbiAgICAgICAgICAgIGxvY2tFeHBpcmF0aW9uOiBAbG9ja09wdGlvbnMubG9ja0V4cGlyYXRpb25cbiAgICAgICAgICAgIHBvbGxpbmdJbnRlcnZhbDogQGxvY2tPcHRpb25zLnBvbGxpbmdJbnRlcnZhbFxuXG4gICAgICAgICBpZiB3cml0ZVN0cmVhbVxuXG4gICAgICAgICAgICBpZiBvcHRpb25zLmF1dG9SZW5ld0xvY2tcbiAgICAgICAgICAgICAgIHdyaXRlU3RyZWFtLm9uICdleHBpcmVzLXNvb24nLCAoKSA9PlxuICAgICAgICAgICAgICAgICAgd3JpdGVTdHJlYW0ucmVuZXdMb2NrIChlLCBkKSAtPlxuICAgICAgICAgICAgICAgICAgICAgaWYgZSBvciBub3QgZFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuIFwiQXV0b21hdGljIFdyaXRlIExvY2sgUmVuZXdhbCBGYWlsZWQ6ICN7ZmlsZS5faWR9XCIsIGVcblxuICAgICAgICAgICAgaWYgY2FsbGJhY2s/XG4gICAgICAgICAgICAgICB3cml0ZVN0cmVhbS5vbiAnY2xvc2UnLCAocmV0RmlsZSkgLT5cbiAgICAgICAgICAgICAgICAgIGlmIHJldEZpbGVcbiAgICAgICAgICAgICAgICAgICAgIHJldEZpbGUuX2lkID0gbmV3IE1vbmdvLk9iamVjdElEIHJldEZpbGUuX2lkLnRvSGV4U3RyaW5nKClcbiAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJldEZpbGUpXG4gICAgICAgICAgICAgICB3cml0ZVN0cmVhbS5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgICAgICAgICAgY2FsbGJhY2soZXJyKVxuXG4gICAgICAgICAgICByZXR1cm4gd3JpdGVTdHJlYW1cblxuICAgICAgICAgcmV0dXJuIG51bGxcblxuICAgICAgZmluZE9uZVN0cmVhbTogKHNlbGVjdG9yLCBvcHRpb25zID0ge30sIGNhbGxiYWNrID0gdW5kZWZpbmVkKSAtPlxuICAgICAgICAgaWYgbm90IGNhbGxiYWNrPyBhbmQgdHlwZW9mIG9wdGlvbnMgaXMgJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgY2FsbGJhY2sgPSBvcHRpb25zXG4gICAgICAgICAgICBvcHRpb25zID0ge31cblxuICAgICAgICAgY2FsbGJhY2sgPSBzaGFyZS5iaW5kX2VudiBjYWxsYmFja1xuICAgICAgICAgb3B0cyA9IHt9XG4gICAgICAgICBvcHRzLnNvcnQgPSBvcHRpb25zLnNvcnQgaWYgb3B0aW9ucy5zb3J0P1xuICAgICAgICAgb3B0cy5za2lwID0gb3B0aW9ucy5za2lwIGlmIG9wdGlvbnMuc2tpcD9cbiAgICAgICAgIGZpbGUgPSBAZmluZE9uZSBzZWxlY3Rvciwgb3B0c1xuXG4gICAgICAgICBpZiBmaWxlXG4gICAgICAgICAgICBvcHRpb25zLmF1dG9SZW5ld0xvY2sgPz0gdHJ1ZVxuXG4gICAgICAgICAgICAjIEluaXQgdGhlIHN0YXJ0IGFuZCBlbmQgcmFuZ2UsIGRlZmF1bHQgdG8gZnVsbCBmaWxlIG9yIHN0YXJ0L2VuZCBhcyBzcGVjaWZpZWRcbiAgICAgICAgICAgIHJhbmdlID1cbiAgICAgICAgICAgICAgIHN0YXJ0OiBvcHRpb25zLnJhbmdlPy5zdGFydCA/IDBcbiAgICAgICAgICAgICAgIGVuZDogb3B0aW9ucy5yYW5nZT8uZW5kID8gZmlsZS5sZW5ndGggLSAxXG5cbiAgICAgICAgICAgIHJlYWRTdHJlYW0gPSBNZXRlb3Iud3JhcEFzeW5jKEBnZnMuY3JlYXRlUmVhZFN0cmVhbS5iaW5kKEBnZnMpKVxuICAgICAgICAgICAgICAgcm9vdDogQHJvb3RcbiAgICAgICAgICAgICAgIF9pZDogbW9uZ29kYi5PYmplY3RJRChcIiN7ZmlsZS5faWR9XCIpXG4gICAgICAgICAgICAgICB0aW1lT3V0OiBAbG9ja09wdGlvbnMudGltZU91dFxuICAgICAgICAgICAgICAgbG9ja0V4cGlyYXRpb246IEBsb2NrT3B0aW9ucy5sb2NrRXhwaXJhdGlvblxuICAgICAgICAgICAgICAgcG9sbGluZ0ludGVydmFsOiBAbG9ja09wdGlvbnMucG9sbGluZ0ludGVydmFsXG4gICAgICAgICAgICAgICByYW5nZTpcbiAgICAgICAgICAgICAgICAgc3RhcnRQb3M6IHJhbmdlLnN0YXJ0XG4gICAgICAgICAgICAgICAgIGVuZFBvczogcmFuZ2UuZW5kXG5cbiAgICAgICAgICAgIGlmIHJlYWRTdHJlYW1cbiAgICAgICAgICAgICAgIGlmIG9wdGlvbnMuYXV0b1JlbmV3TG9ja1xuICAgICAgICAgICAgICAgICAgcmVhZFN0cmVhbS5vbiAnZXhwaXJlcy1zb29uJywgKCkgPT5cbiAgICAgICAgICAgICAgICAgICAgIHJlYWRTdHJlYW0ucmVuZXdMb2NrIChlLCBkKSAtPlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgZSBvciBub3QgZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuIFwiQXV0b21hdGljIFJlYWQgTG9jayBSZW5ld2FsIEZhaWxlZDogI3tmaWxlLl9pZH1cIiwgZVxuXG4gICAgICAgICAgICAgICBpZiBjYWxsYmFjaz9cbiAgICAgICAgICAgICAgICAgIHJlYWRTdHJlYW0ub24gJ2Nsb3NlJywgKCkgLT5cbiAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIGZpbGUpXG4gICAgICAgICAgICAgICAgICByZWFkU3RyZWFtLm9uICdlcnJvcicsIChlcnIpIC0+XG4gICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayhlcnIpXG4gICAgICAgICAgICAgICByZXR1cm4gcmVhZFN0cmVhbVxuXG4gICAgICAgICByZXR1cm4gbnVsbFxuXG4gICAgICByZW1vdmU6IChzZWxlY3RvciwgY2FsbGJhY2sgPSB1bmRlZmluZWQpIC0+XG4gICAgICAgICBjYWxsYmFjayA9IHNoYXJlLmJpbmRfZW52IGNhbGxiYWNrXG4gICAgICAgICBpZiBzZWxlY3Rvcj9cbiAgICAgICAgICAgIHJldCA9IDBcbiAgICAgICAgICAgIEBmaW5kKHNlbGVjdG9yKS5mb3JFYWNoIChmaWxlKSA9PlxuICAgICAgICAgICAgICAgcmVzID0gTWV0ZW9yLndyYXBBc3luYyhAZ2ZzLnJlbW92ZS5iaW5kKEBnZnMpKVxuICAgICAgICAgICAgICAgICAgX2lkOiBtb25nb2RiLk9iamVjdElEKFwiI3tmaWxlLl9pZH1cIilcbiAgICAgICAgICAgICAgICAgIHJvb3Q6IEByb290XG4gICAgICAgICAgICAgICAgICB0aW1lT3V0OiBAbG9ja09wdGlvbnMudGltZU91dFxuICAgICAgICAgICAgICAgICAgbG9ja0V4cGlyYXRpb246IEBsb2NrT3B0aW9ucy5sb2NrRXhwaXJhdGlvblxuICAgICAgICAgICAgICAgICAgcG9sbGluZ0ludGVydmFsOiBAbG9ja09wdGlvbnMucG9sbGluZ0ludGVydmFsXG4gICAgICAgICAgICAgICByZXQgKz0gaWYgcmVzIHRoZW4gMSBlbHNlIDBcbiAgICAgICAgICAgIGNhbGxiYWNrPyBhbmQgY2FsbGJhY2sgbnVsbCwgcmV0XG4gICAgICAgICAgICByZXR1cm4gcmV0XG4gICAgICAgICBlbHNlXG4gICAgICAgICAgICBlcnIgPSBuZXcgTWV0ZW9yLkVycm9yIFwiUmVtb3ZlIHdpdGggYW4gZW1wdHkgc2VsZWN0b3IgaXMgbm90IHN1cHBvcnRlZFwiXG4gICAgICAgICAgICBpZiBjYWxsYmFjaz9cbiAgICAgICAgICAgICAgIGNhbGxiYWNrIGVyclxuICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICB0aHJvdyBlcnJcblxuICAgICAgaW1wb3J0RmlsZTogKGZpbGVQYXRoLCBmaWxlLCBjYWxsYmFjaykgLT5cbiAgICAgICAgIGNhbGxiYWNrID0gc2hhcmUuYmluZF9lbnYgY2FsbGJhY2tcbiAgICAgICAgIGZpbGVQYXRoID0gcGF0aC5ub3JtYWxpemUgZmlsZVBhdGhcbiAgICAgICAgIGZpbGUgPz0ge31cbiAgICAgICAgIGZpbGUuZmlsZW5hbWUgPz0gcGF0aC5iYXNlbmFtZSBmaWxlUGF0aFxuICAgICAgICAgcmVhZFN0cmVhbSA9IGZzLmNyZWF0ZVJlYWRTdHJlYW0gZmlsZVBhdGhcbiAgICAgICAgIHJlYWRTdHJlYW0ub24oJ2Vycm9yJywgc2hhcmUuYmluZF9lbnYoY2FsbGJhY2spKVxuICAgICAgICAgd3JpdGVTdHJlYW0gPSBAdXBzZXJ0U3RyZWFtIGZpbGVcbiAgICAgICAgIHJlYWRTdHJlYW0ucGlwZShzaGFyZS5zdHJlYW1DaHVua2VyKEBjaHVua1NpemUpKS5waXBlKHdyaXRlU3RyZWFtKVxuICAgICAgICAgICAgLm9uKCdjbG9zZScsIHNoYXJlLmJpbmRfZW52KChkKSAtPiBjYWxsYmFjayhudWxsLCBkKSkpXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgc2hhcmUuYmluZF9lbnYoY2FsbGJhY2spKVxuXG4gICAgICBleHBvcnRGaWxlOiAoc2VsZWN0b3IsIGZpbGVQYXRoLCBjYWxsYmFjaykgLT5cbiAgICAgICAgIGNhbGxiYWNrID0gc2hhcmUuYmluZF9lbnYgY2FsbGJhY2tcbiAgICAgICAgIGZpbGVQYXRoID0gcGF0aC5ub3JtYWxpemUgZmlsZVBhdGhcbiAgICAgICAgIHJlYWRTdHJlYW0gPSBAZmluZE9uZVN0cmVhbSBzZWxlY3RvclxuICAgICAgICAgd3JpdGVTdHJlYW0gPSBmcy5jcmVhdGVXcml0ZVN0cmVhbSBmaWxlUGF0aFxuICAgICAgICAgcmVhZFN0cmVhbS5waXBlKHdyaXRlU3RyZWFtKVxuICAgICAgICAgICAgLm9uKCdmaW5pc2gnLCBzaGFyZS5iaW5kX2VudihjYWxsYmFjaykpXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgc2hhcmUuYmluZF9lbnYoY2FsbGJhY2spKVxuIiwiIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjI1xuIyAgICAgQ29weXJpZ2h0IChDKSAyMDE0LTIwMTYgYnkgVmF1Z2huIEl2ZXJzb25cbiMgICAgIGZpbGVDb2xsZWN0aW9uIGlzIGZyZWUgc29mdHdhcmUgcmVsZWFzZWQgdW5kZXIgdGhlIE1JVC9YMTEgbGljZW5zZS5cbiMgICAgIFNlZSBpbmNsdWRlZCBMSUNFTlNFIGZpbGUgZm9yIGRldGFpbHMuXG4jIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG5cbmlmIE1ldGVvci5pc1NlcnZlclxuXG4gICBleHByZXNzID0gTnBtLnJlcXVpcmUgJ2V4cHJlc3MnXG4gICBtb25nb2RiID0gTnBtLnJlcXVpcmUgJ21vbmdvZGInXG4gICBncmlkID0gTnBtLnJlcXVpcmUgJ2dyaWRmcy1sb2NraW5nLXN0cmVhbSdcbiAgIGdyaWRMb2NrcyA9IE5wbS5yZXF1aXJlICdncmlkZnMtbG9ja3MnXG4gICBkaWNlciA9IE5wbS5yZXF1aXJlICdkaWNlcidcbiAgIGFzeW5jID0gTnBtLnJlcXVpcmUgJ2FzeW5jJ1xuXG4gICAjIFRoaXMgZnVuY3Rpb24gY2hlY2tzIHRvIHNlZSBpZiBhbGwgb2YgdGhlIHBhcnRzIG9mIGEgUmVzdW1hYmxlLmpzIHVwbG9hZGVkIGZpbGUgYXJlIG5vdyBpbiB0aGUgZ3JpZEZTXG4gICAjIENvbGxlY3Rpb24uIElmIHNvLCBpdCBjb21wbGV0ZXMgdGhlIGZpbGUgYnkgbW92aW5nIGFsbCBvZiB0aGUgY2h1bmtzIHRvIHRoZSBjb3JyZWN0IGZpbGUgYW5kIGNsZWFucyB1cFxuXG4gICBjaGVja19vcmRlciA9IChmaWxlLCBjYWxsYmFjaykgLT5cbiAgICAgIGZpbGVJZCA9IG1vbmdvZGIuT2JqZWN0SUQoXCIje2ZpbGUubWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVJZGVudGlmaWVyfVwiKVxuICAgICAgbG9jayA9IGdyaWRMb2Nrcy5Mb2NrKGZpbGVJZCwgQGxvY2tzLCB7fSkub2J0YWluV3JpdGVMb2NrKClcbiAgICAgIGxvY2sub24gJ2xvY2tlZCcsICgpID0+XG5cbiAgICAgICAgIGZpbGVzID0gQGRiLmNvbGxlY3Rpb24gXCIje0Byb290fS5maWxlc1wiXG5cbiAgICAgICAgIGN1cnNvciA9IGZpbGVzLmZpbmQoXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAnbWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVJZGVudGlmaWVyJzogZmlsZS5tZXRhZGF0YS5fUmVzdW1hYmxlLnJlc3VtYWJsZUlkZW50aWZpZXJcbiAgICAgICAgICAgICAgIGxlbmd0aDpcbiAgICAgICAgICAgICAgICAgICRuZTogMFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgIGZpZWxkczpcbiAgICAgICAgICAgICAgICAgIGxlbmd0aDogMVxuICAgICAgICAgICAgICAgICAgbWV0YWRhdGE6IDFcbiAgICAgICAgICAgICAgIHNvcnQ6XG4gICAgICAgICAgICAgICAgICAnbWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlcic6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgIClcblxuICAgICAgICAgY3Vyc29yLmNvdW50IChlcnIsIGNvdW50KSA9PlxuICAgICAgICAgICAgaWYgZXJyXG4gICAgICAgICAgICAgICBsb2NrLnJlbGVhc2VMb2NrKClcbiAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayBlcnJcblxuICAgICAgICAgICAgdW5sZXNzIGNvdW50ID49IDFcbiAgICAgICAgICAgICAgIGN1cnNvci5jbG9zZSgpXG4gICAgICAgICAgICAgICBsb2NrLnJlbGVhc2VMb2NrKClcbiAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjaygpXG5cbiAgICAgICAgICAgIHVubGVzcyBjb3VudCBpcyBmaWxlLm1ldGFkYXRhLl9SZXN1bWFibGUucmVzdW1hYmxlVG90YWxDaHVua3NcbiAgICAgICAgICAgICAgIGN1cnNvci5jbG9zZSgpXG4gICAgICAgICAgICAgICBsb2NrLnJlbGVhc2VMb2NrKClcbiAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjaygpXG5cbiAgICAgICAgICAgICMgTWFuaXB1bGF0ZSB0aGUgY2h1bmtzIGFuZCBmaWxlcyBjb2xsZWN0aW9ucyBkaXJlY3RseSB1bmRlciB3cml0ZSBsb2NrXG4gICAgICAgICAgICBjaHVua3MgPSBAZGIuY29sbGVjdGlvbiBcIiN7QHJvb3R9LmNodW5rc1wiXG5cbiAgICAgICAgICAgIGN1cnNvci5iYXRjaFNpemUgZmlsZS5tZXRhZGF0YS5fUmVzdW1hYmxlLnJlc3VtYWJsZVRvdGFsQ2h1bmtzICsgMVxuXG4gICAgICAgICAgICBjdXJzb3IudG9BcnJheSAoZXJyLCBwYXJ0cykgPT5cblxuICAgICAgICAgICAgICAgaWYgZXJyXG4gICAgICAgICAgICAgICAgICBsb2NrLnJlbGVhc2VMb2NrKClcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjYWxsYmFjayBlcnJcblxuICAgICAgICAgICAgICAgYXN5bmMuZWFjaExpbWl0IHBhcnRzLCA1LFxuICAgICAgICAgICAgICAgICAgKHBhcnQsIGNiKSA9PlxuICAgICAgICAgICAgICAgICAgICAgaWYgZXJyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yIFwiRXJyb3IgZnJvbSBjdXJzb3IubmV4dCgpXCIsIGVyclxuICAgICAgICAgICAgICAgICAgICAgICAgY2IgZXJyXG4gICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2IgbmV3IE1ldGVvci5FcnJvciBcIlJlY2VpdmVkIG51bGwgcGFydFwiIHVubGVzcyBwYXJ0XG4gICAgICAgICAgICAgICAgICAgICBwYXJ0SWQgPSBtb25nb2RiLk9iamVjdElEKFwiI3twYXJ0Ll9pZH1cIilcbiAgICAgICAgICAgICAgICAgICAgIHBhcnRsb2NrID0gZ3JpZExvY2tzLkxvY2socGFydElkLCBAbG9ja3MsIHt9KS5vYnRhaW5Xcml0ZUxvY2soKVxuICAgICAgICAgICAgICAgICAgICAgcGFydGxvY2sub24gJ2xvY2tlZCcsICgpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICBhc3luYy5zZXJpZXMgW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIyBNb3ZlIHRoZSBjaHVua3MgdG8gdGhlIGNvcnJlY3QgZmlsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNiKSAtPiBjaHVua3MudXBkYXRlIHsgZmlsZXNfaWQ6IHBhcnRJZCwgbjogMCB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyAkc2V0OiB7IGZpbGVzX2lkOiBmaWxlSWQsIG46IHBhcnQubWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlciAtIDEgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAjIERlbGV0ZSB0aGUgdGVtcG9yYXJ5IGNodW5rIGZpbGUgZG9jdW1lbnRzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2IpIC0+IGZpbGVzLnJlbW92ZSB7IF9pZDogcGFydElkIH0sIGNiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVyciwgcmVzKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNiIGVyciBpZiBlcnJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVubGVzcyBwYXJ0Lm1ldGFkYXRhLl9SZXN1bWFibGUucmVzdW1hYmxlQ2h1bmtOdW1iZXIgaXMgcGFydC5tZXRhZGF0YS5fUmVzdW1hYmxlLnJlc3VtYWJsZVRvdGFsQ2h1bmtzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJ0bG9jay5yZW1vdmVMb2NrKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNiKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICMgY2hlY2sgZm9yIGEgZmluYWwgaGFuZ2luZyBncmlkZnMgY2h1bmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNodW5rcy51cGRhdGUgeyBmaWxlc19pZDogcGFydElkLCBuOiAxIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ICRzZXQ6IHsgZmlsZXNfaWQ6IGZpbGVJZCwgbjogcGFydC5tZXRhZGF0YS5fUmVzdW1hYmxlLnJlc3VtYWJsZUNodW5rTnVtYmVyIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZXJyLCByZXMpIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJ0bG9jay5yZW1vdmVMb2NrKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjYiBlcnIgaWYgZXJyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYigpXG4gICAgICAgICAgICAgICAgICAgICBwYXJ0bG9jay5vbiAndGltZWQtb3V0JywgKCkgLT4gY2IgbmV3IE1ldGVvci5FcnJvciAnUGFydGxvY2sgdGltZWQgb3V0ISdcbiAgICAgICAgICAgICAgICAgICAgIHBhcnRsb2NrLm9uICdleHBpcmVkJywgKCkgLT4gY2IgbmV3IE1ldGVvci5FcnJvciAnUGFydGxvY2sgZXhwaXJlZCEnXG4gICAgICAgICAgICAgICAgICAgICBwYXJ0bG9jay5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvciBcIkVycm9yIG9idGFpbmluZyBwYXJ0bG9jayAje3BhcnQuX2lkfVwiLCBlcnJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNiIGVyclxuICAgICAgICAgICAgICAgICAgKGVycikgPT5cbiAgICAgICAgICAgICAgICAgICAgIGlmIGVyclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jay5yZWxlYXNlTG9jaygpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sgZXJyXG4gICAgICAgICAgICAgICAgICAgICAjIEJ1aWxkIHVwIHRoZSBjb21tYW5kIGZvciB0aGUgbWQ1IGhhc2ggY2FsY3VsYXRpb25cbiAgICAgICAgICAgICAgICAgICAgIG1kNUNvbW1hbmQgPVxuICAgICAgICAgICAgICAgICAgICAgICBmaWxlbWQ1OiBmaWxlSWRcbiAgICAgICAgICAgICAgICAgICAgICAgcm9vdDogXCIje0Byb290fVwiXG4gICAgICAgICAgICAgICAgICAgICAjIFNlbmQgdGhlIGNvbW1hbmQgdG8gY2FsY3VsYXRlIHRoZSBtZDUgaGFzaCBvZiB0aGUgZmlsZVxuICAgICAgICAgICAgICAgICAgICAgQGRiLmNvbW1hbmQgbWQ1Q29tbWFuZCwgKGVyciwgcmVzdWx0cykgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgaWYgZXJyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2sucmVsZWFzZUxvY2soKVxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FsbGJhY2sgZXJyXG4gICAgICAgICAgICAgICAgICAgICAgICMgVXBkYXRlIHRoZSBzaXplIGFuZCBtZDUgdG8gdGhlIGZpbGUgZGF0YVxuICAgICAgICAgICAgICAgICAgICAgICBmaWxlcy51cGRhdGUgeyBfaWQ6IGZpbGVJZCB9LCB7ICRzZXQ6IHsgbGVuZ3RoOiBmaWxlLm1ldGFkYXRhLl9SZXN1bWFibGUucmVzdW1hYmxlVG90YWxTaXplLCBtZDU6IHJlc3VsdHMubWQ1IH19LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAoZXJyLCByZXMpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2sucmVsZWFzZUxvY2soKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayBlcnJcblxuICAgICAgbG9jay5vbiAnZXhwaXJlcy1zb29uJywgKCkgLT5cbiAgICAgICAgIGxvY2sucmVuZXdMb2NrKCkub25jZSAncmVuZXdlZCcsIChsZCkgLT5cbiAgICAgICAgICAgIHVubGVzcyBsZFxuICAgICAgICAgICAgICAgY29uc29sZS53YXJuIFwiUmVzdW1hYmxlIHVwbG9hZCBsb2NrIHJlbmV3YWwgZmFpbGVkIVwiXG4gICAgICBsb2NrLm9uICdleHBpcmVkJywgKCkgLT4gY2FsbGJhY2sgbmV3IE1ldGVvci5FcnJvciBcIkZpbGUgTG9jayBleHBpcmVkXCJcbiAgICAgIGxvY2sub24gJ3RpbWVkLW91dCcsICgpIC0+IGNhbGxiYWNrIG5ldyBNZXRlb3IuRXJyb3IgXCJGaWxlIExvY2sgdGltZWQgb3V0XCJcbiAgICAgIGxvY2sub24gJ2Vycm9yJywgKGVycikgLT4gY2FsbGJhY2sgZXJyXG5cbiAgICMgSGFuZGxlIEhUVFAgUE9TVCByZXF1ZXN0cyBmcm9tIFJlc3VtYWJsZS5qc1xuXG4gICByZXN1bWFibGVfcG9zdF9sb29rdXAgPSAocGFyYW1zLCBxdWVyeSwgbXVsdGlwYXJ0KSAtPlxuICAgICAgcmV0dXJuIHsgX2lkOiBzaGFyZS5zYWZlT2JqZWN0SUQobXVsdGlwYXJ0Py5wYXJhbXM/LnJlc3VtYWJsZUlkZW50aWZpZXIpIH1cblxuICAgcmVzdW1hYmxlX3Bvc3RfaGFuZGxlciA9IChyZXEsIHJlcywgbmV4dCkgLT5cblxuICAgICAgIyBUaGlzIGhhcyB0byBiZSBhIHJlc3VtYWJsZSBQT1NUXG4gICAgICB1bmxlc3MgcmVxLm11bHRpcGFydD8ucGFyYW1zPy5yZXN1bWFibGVJZGVudGlmaWVyXG4gICAgICAgICBjb25zb2xlLmVycm9yIFwiTWlzc2luZyByZXN1bWFibGUuanMgbXVsdGlwYXJ0IGluZm9ybWF0aW9uXCJcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAxLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICByZXR1cm5cblxuICAgICAgcmVzdW1hYmxlID0gcmVxLm11bHRpcGFydC5wYXJhbXNcbiAgICAgIHJlc3VtYWJsZS5yZXN1bWFibGVUb3RhbFNpemUgPSBwYXJzZUludCByZXN1bWFibGUucmVzdW1hYmxlVG90YWxTaXplXG4gICAgICByZXN1bWFibGUucmVzdW1hYmxlVG90YWxDaHVua3MgPSBwYXJzZUludCByZXN1bWFibGUucmVzdW1hYmxlVG90YWxDaHVua3NcbiAgICAgIHJlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlciA9IHBhcnNlSW50IHJlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlclxuICAgICAgcmVzdW1hYmxlLnJlc3VtYWJsZUNodW5rU2l6ZSA9IHBhcnNlSW50IHJlc3VtYWJsZS5yZXN1bWFibGVDaHVua1NpemVcbiAgICAgIHJlc3VtYWJsZS5yZXN1bWFibGVDdXJyZW50Q2h1bmtTaXplID0gcGFyc2VJbnQgcmVzdW1hYmxlLnJlc3VtYWJsZUN1cnJlbnRDaHVua1NpemVcblxuICAgICAgaWYgcmVxLm1heFVwbG9hZFNpemUgPiAwXG4gICAgICAgICB1bmxlc3MgcmVzdW1hYmxlLnJlc3VtYWJsZVRvdGFsU2l6ZSA8PSByZXEubWF4VXBsb2FkU2l6ZVxuICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg0MTMsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAjIFNhbml0eSBjaGVjayB0aGUgY2h1bmsgc2l6ZXMgdGhhdCBhcmUgY3JpdGljYWwgdG8gcmVhc3NlbWJsaW5nIHRoZSBmaWxlIGZyb20gcGFydHNcbiAgICAgIHVubGVzcyAoKHJlcS5ncmlkRlMuY2h1bmtTaXplIGlzIHJlc3VtYWJsZS5yZXN1bWFibGVDaHVua1NpemUpIGFuZFxuICAgICAgICAgICAgICAocmVzdW1hYmxlLnJlc3VtYWJsZUNodW5rTnVtYmVyIDw9IHJlc3VtYWJsZS5yZXN1bWFibGVUb3RhbENodW5rcykgYW5kXG4gICAgICAgICAgICAgIChyZXN1bWFibGUucmVzdW1hYmxlVG90YWxTaXplL3Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua1NpemUgPD0gcmVzdW1hYmxlLnJlc3VtYWJsZVRvdGFsQ2h1bmtzKzEpIGFuZFxuICAgICAgICAgICAgICAocmVzdW1hYmxlLnJlc3VtYWJsZUN1cnJlbnRDaHVua1NpemUgaXMgcmVzdW1hYmxlLnJlc3VtYWJsZUNodW5rU2l6ZSkgb3JcbiAgICAgICAgICAgICAgKChyZXN1bWFibGUucmVzdW1hYmxlQ2h1bmtOdW1iZXIgaXMgcmVzdW1hYmxlLnJlc3VtYWJsZVRvdGFsQ2h1bmtzKSBhbmRcbiAgICAgICAgICAgICAgIChyZXN1bWFibGUucmVzdW1hYmxlQ3VycmVudENodW5rU2l6ZSA8IDIqcmVzdW1hYmxlLnJlc3VtYWJsZUNodW5rU2l6ZSkpKVxuXG4gICAgICAgICByZXMud3JpdGVIZWFkKDUwMSwgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgIHJlcy5lbmQoKVxuICAgICAgICAgcmV0dXJuXG5cbiAgICAgIGNodW5rUXVlcnkgPVxuICAgICAgICAgbGVuZ3RoOiByZXN1bWFibGUucmVzdW1hYmxlQ3VycmVudENodW5rU2l6ZVxuICAgICAgICAgJ21ldGFkYXRhLl9SZXN1bWFibGUucmVzdW1hYmxlSWRlbnRpZmllcic6IHJlc3VtYWJsZS5yZXN1bWFibGVJZGVudGlmaWVyXG4gICAgICAgICAnbWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlcic6IHJlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlclxuXG4gICAgICAjIFRoaXMgaXMgdG8gaGFuZGxlIGR1cGxpY2F0ZSBjaHVuayB1cGxvYWRzIGluIGNhc2Ugb2YgbmV0d29yayB3ZWlyZG5lc3NcbiAgICAgIGZpbmRSZXN1bHQgPSBAZmluZE9uZSBjaHVua1F1ZXJ5LCB7IGZpZWxkczogeyBfaWQ6IDEgfX1cblxuICAgICAgaWYgZmluZFJlc3VsdFxuICAgICAgICAgIyBEdXBsaWNhdGUgY2h1bmsuLi4gRG9uJ3QgcmV3cml0ZSBpdC5cbiAgICAgICAgICMgY29uc29sZS53YXJuIFwiRHVwbGljYXRlIGNodW5rIGRldGVjdGVkOiAje3Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlcn0sICN7cmVzdW1hYmxlLnJlc3VtYWJsZUlkZW50aWZpZXJ9XCJcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgcmVzLmVuZCgpXG4gICAgICBlbHNlXG4gICAgICAgICAjIEV2ZXJ5dGhpbmcgbG9va3MgZ29vZCwgc28gd3JpdGUgdGhpcyBwYXJ0XG4gICAgICAgICByZXEuZ3JpZEZTLm1ldGFkYXRhLl9SZXN1bWFibGUgPSByZXN1bWFibGVcbiAgICAgICAgIHdyaXRlU3RyZWFtID0gQHVwc2VydFN0cmVhbVxuICAgICAgICAgICAgZmlsZW5hbWU6IFwiX1Jlc3VtYWJsZV8je3Jlc3VtYWJsZS5yZXN1bWFibGVJZGVudGlmaWVyfV8je3Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlcn1fI3tyZXN1bWFibGUucmVzdW1hYmxlVG90YWxDaHVua3N9XCJcbiAgICAgICAgICAgIG1ldGFkYXRhOiByZXEuZ3JpZEZTLm1ldGFkYXRhXG5cbiAgICAgICAgIHVubGVzcyB3cml0ZVN0cmVhbVxuICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg0MDQsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgICByZXEubXVsdGlwYXJ0LmZpbGVTdHJlYW0ucGlwZShzaGFyZS5zdHJlYW1DaHVua2VyKEBjaHVua1NpemUpKS5waXBlKHdyaXRlU3RyZWFtKVxuICAgICAgICAgICAgLm9uICdjbG9zZScsIHNoYXJlLmJpbmRfZW52KChyZXRGaWxlKSA9PlxuICAgICAgICAgICAgICAgaWYgcmV0RmlsZVxuICAgICAgICAgICAgICAgICAgIyBDaGVjayB0byBzZWUgaWYgYWxsIG9mIHRoZSBwYXJ0cyBhcmUgbm93IGF2YWlsYWJsZSBhbmQgY2FuIGJlIHJlYXNzZW1ibGVkXG4gICAgICAgICAgICAgICAgICBjaGVja19vcmRlci5iaW5kKEApKHJlcS5ncmlkRlMsIChlcnIpIC0+XG4gICAgICAgICAgICAgICAgICAgICBpZiBlcnJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IgXCJFcnJvciByZWFzc2VtYmxpbmcgY2h1bmtzIG9mIHJlc3VtYWJsZS5qcyB1cGxvYWRcIiwgZXJyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDUwMCwgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yIFwiTWlzc2luZyByZXRGaWxlIG9uIHBpcGUgY2xvc2VcIlxuICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgICAgIClcblxuICAgICAgICAgICAgLm9uICdlcnJvcicsIHNoYXJlLmJpbmRfZW52KChlcnIpID0+XG4gICAgICAgICAgICAgICBjb25zb2xlLmVycm9yIFwiUGlwaW5nIEVycm9yIVwiLCBlcnJcbiAgICAgICAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgICAgICAgcmVzLmVuZCgpKVxuXG4gICByZXN1bWFibGVfZ2V0X2xvb2t1cCA9IChwYXJhbXMsIHF1ZXJ5KSAtPlxuICAgICAgcSA9IHsgX2lkOiBzaGFyZS5zYWZlT2JqZWN0SUQocXVlcnkucmVzdW1hYmxlSWRlbnRpZmllcikgfVxuICAgICAgcmV0dXJuIHFcblxuICAgIyBUaGlzIGhhbmRsZXMgUmVzdW1hYmxlLmpzIFwidGVzdCBHRVRcIiByZXF1ZXN0cywgdGhhdCBleGlzdCB0byBkZXRlcm1pbmVcbiAgICMgaWYgYSBwYXJ0IGlzIGFscmVhZHkgdXBsb2FkZWQuIEl0IGFsc28gaGFuZGxlcyBIRUFEIHJlcXVlc3RzLCB3aGljaFxuICAgIyBzaG91bGQgYmUgYSBiaXQgbW9yZSBlZmZpY2llbnQgYW5kIHJlc3VtYWJsZS5qcyBub3cgc3VwcG9ydHNcbiAgIHJlc3VtYWJsZV9nZXRfaGFuZGxlciA9IChyZXEsIHJlcywgbmV4dCkgLT5cbiAgICAgIHF1ZXJ5ID0gcmVxLnF1ZXJ5XG4gICAgICBjaHVua1F1ZXJ5ID1cbiAgICAgICAgICRvcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgX2lkOiBzaGFyZS5zYWZlT2JqZWN0SUQocXVlcnkucmVzdW1hYmxlSWRlbnRpZmllcilcbiAgICAgICAgICAgICAgIGxlbmd0aDogcGFyc2VJbnQgcXVlcnkucmVzdW1hYmxlVG90YWxTaXplXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICBsZW5ndGg6IHBhcnNlSW50IHF1ZXJ5LnJlc3VtYWJsZUN1cnJlbnRDaHVua1NpemVcbiAgICAgICAgICAgICAgICdtZXRhZGF0YS5fUmVzdW1hYmxlLnJlc3VtYWJsZUlkZW50aWZpZXInOiBxdWVyeS5yZXN1bWFibGVJZGVudGlmaWVyXG4gICAgICAgICAgICAgICAnbWV0YWRhdGEuX1Jlc3VtYWJsZS5yZXN1bWFibGVDaHVua051bWJlcic6IHBhcnNlSW50IHF1ZXJ5LnJlc3VtYWJsZUNodW5rTnVtYmVyXG4gICAgICAgICAgICB9XG4gICAgICAgICBdXG5cbiAgICAgIHJlc3VsdCA9IEBmaW5kT25lIGNodW5rUXVlcnksIHsgZmllbGRzOiB7IF9pZDogMSB9fVxuICAgICAgaWYgcmVzdWx0XG4gICAgICAgICAjIENodW5rIGlzIHByZXNlbnRcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoMjAwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgZWxzZVxuICAgICAgICAgIyBDaHVuayBpcyBtaXNzaW5nXG4gICAgICAgICByZXMud3JpdGVIZWFkKDIwNCwgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcblxuICAgICAgcmVzLmVuZCgpXG5cbiAgICMgU2V0dXAgdGhlIEdFVCBhbmQgUE9TVCBIVFRQIFJFU1QgcGF0aHMgZm9yIFJlc3VtYWJsZS5qcyBpbiBleHByZXNzXG4gICBzaGFyZS5yZXN1bWFibGVQYXRocyA9IFtcbiAgICAgIHtcbiAgICAgICAgIG1ldGhvZDogJ2hlYWQnXG4gICAgICAgICBwYXRoOiBzaGFyZS5yZXN1bWFibGVCYXNlXG4gICAgICAgICBsb29rdXA6IHJlc3VtYWJsZV9nZXRfbG9va3VwXG4gICAgICAgICBoYW5kbGVyOiByZXN1bWFibGVfZ2V0X2hhbmRsZXJcbiAgICAgIH1cbiAgICAgIHtcbiAgICAgICAgIG1ldGhvZDogJ3Bvc3QnXG4gICAgICAgICBwYXRoOiBzaGFyZS5yZXN1bWFibGVCYXNlXG4gICAgICAgICBsb29rdXA6IHJlc3VtYWJsZV9wb3N0X2xvb2t1cFxuICAgICAgICAgaGFuZGxlcjogcmVzdW1hYmxlX3Bvc3RfaGFuZGxlclxuICAgICAgfVxuICAgICAge1xuICAgICAgICAgbWV0aG9kOiAnZ2V0J1xuICAgICAgICAgcGF0aDogc2hhcmUucmVzdW1hYmxlQmFzZVxuICAgICAgICAgbG9va3VwOiByZXN1bWFibGVfZ2V0X2xvb2t1cFxuICAgICAgICAgaGFuZGxlcjogcmVzdW1hYmxlX2dldF9oYW5kbGVyXG4gICAgICB9XG4gICBdXG4iLCIjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjXG4jICAgICBDb3B5cmlnaHQgKEMpIDIwMTQtMjAxNiBieSBWYXVnaG4gSXZlcnNvblxuIyAgICAgZmlsZUNvbGxlY3Rpb24gaXMgZnJlZSBzb2Z0d2FyZSByZWxlYXNlZCB1bmRlciB0aGUgTUlUL1gxMSBsaWNlbnNlLlxuIyAgICAgU2VlIGluY2x1ZGVkIExJQ0VOU0UgZmlsZSBmb3IgZGV0YWlscy5cbiMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyNcblxuaWYgTWV0ZW9yLmlzU2VydmVyXG5cbiAgIGV4cHJlc3MgPSBOcG0ucmVxdWlyZSAnZXhwcmVzcydcbiAgIGNvb2tpZVBhcnNlciA9IE5wbS5yZXF1aXJlICdjb29raWUtcGFyc2VyJ1xuICAgbW9uZ29kYiA9IE5wbS5yZXF1aXJlICdtb25nb2RiJ1xuICAgZ3JpZCA9IE5wbS5yZXF1aXJlICdncmlkZnMtbG9ja2luZy1zdHJlYW0nXG4gICBncmlkTG9ja3MgPSBOcG0ucmVxdWlyZSAnZ3JpZGZzLWxvY2tzJ1xuICAgZGljZXIgPSBOcG0ucmVxdWlyZSAnZGljZXInXG5cbiAgIGZpbmRfbWltZV9ib3VuZGFyeSA9IChyZXEpIC0+XG4gICAgICBSRV9CT1VOREFSWSA9IC9ebXVsdGlwYXJ0XFwvLis/KD86OyBib3VuZGFyeT0oPzooPzpcIiguKylcIil8KD86KFteXFxzXSspKSkpJC9pXG4gICAgICByZXN1bHQgPSBSRV9CT1VOREFSWS5leGVjIHJlcS5oZWFkZXJzWydjb250ZW50LXR5cGUnXVxuICAgICAgcmVzdWx0P1sxXSBvciByZXN1bHQ/WzJdXG5cbiAgICMgRmFzdCBNSU1FIE11bHRpcGFydCBwYXJzaW5nIG9mIGdlbmVyaWMgSFRUUCBQT1NUIHJlcXVlc3QgYm9kaWVzXG4gICBkaWNlX211bHRpcGFydCA9IChyZXEsIHJlcywgbmV4dCkgLT5cblxuICAgICAgbmV4dCA9IHNoYXJlLmJpbmRfZW52IG5leHRcblxuICAgICAgdW5sZXNzIHJlcS5tZXRob2QgaXMgJ1BPU1QnIGFuZCBub3QgcmVxLmRpY2VkXG4gICAgICAgICBuZXh0KClcbiAgICAgICAgIHJldHVyblxuXG4gICAgICByZXEuZGljZWQgPSB0cnVlICAgIyBEb24ndCByZWVudGVyIGZvciB0aGUgc2FtZSByZXF1ZXN0IG9uIG11bHRpcGxlIHJvdXRlc1xuXG4gICAgICByZXNwb25zZVNlbnQgPSBmYWxzZVxuICAgICAgaGFuZGxlRmFpbHVyZSA9IChtc2csIGVyciA9IFwiXCIsIHJldENvZGUgPSA1MDApIC0+XG4gICAgICAgICBjb25zb2xlLmVycm9yIFwiI3ttc2d9IFxcblwiLCBlcnJcbiAgICAgICAgIHVubGVzcyByZXNwb25zZVNlbnRcbiAgICAgICAgICAgIHJlc3BvbnNlU2VudCA9IHRydWVcbiAgICAgICAgICAgIHJlcy53cml0ZUhlYWQgcmV0Q29kZSwgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVyc1xuICAgICAgICAgICAgcmVzLmVuZCgpXG5cbiAgICAgIGJvdW5kYXJ5ID0gZmluZF9taW1lX2JvdW5kYXJ5IHJlcVxuXG4gICAgICB1bmxlc3MgYm91bmRhcnlcbiAgICAgICAgIGhhbmRsZUZhaWx1cmUgXCJObyBNSU1FIG11bHRpcGFydCBib3VuZGFyeSBmb3VuZCBmb3IgZGljZXJcIlxuICAgICAgICAgcmV0dXJuXG5cbiAgICAgIHBhcmFtcyA9IHt9XG4gICAgICBjb3VudCA9IDBcbiAgICAgIGZpbGVTdHJlYW0gPSBudWxsXG4gICAgICBmaWxlVHlwZSA9ICd0ZXh0L3BsYWluJ1xuICAgICAgZmlsZU5hbWUgPSAnYmxvYidcblxuICAgICAgZCA9IG5ldyBkaWNlciB7IGJvdW5kYXJ5OiBib3VuZGFyeSB9XG5cbiAgICAgIGQub24gJ3BhcnQnLCAocCkgLT5cbiAgICAgICAgIHAub24gJ2hlYWRlcicsIChoZWFkZXIpIC0+XG4gICAgICAgICAgICBSRV9GSUxFID0gL15mb3JtLWRhdGE7IG5hbWU9XCJmaWxlXCI7IGZpbGVuYW1lPVwiKFteXCJdKylcIi9cbiAgICAgICAgICAgIFJFX1BBUkFNID0gL15mb3JtLWRhdGE7IG5hbWU9XCIoW15cIl0rKVwiL1xuICAgICAgICAgICAgZm9yIGssIHYgb2YgaGVhZGVyXG4gICAgICAgICAgICAgICBpZiBrIGlzICdjb250ZW50LXR5cGUnXG4gICAgICAgICAgICAgICAgICBmaWxlVHlwZSA9IHZcbiAgICAgICAgICAgICAgIGlmIGsgaXMgJ2NvbnRlbnQtZGlzcG9zaXRpb24nXG4gICAgICAgICAgICAgICAgICBpZiByZSA9IFJFX0ZJTEUuZXhlYyh2KVxuICAgICAgICAgICAgICAgICAgICAgZmlsZVN0cmVhbSA9IHBcbiAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lID0gcmVbMV1cbiAgICAgICAgICAgICAgICAgIGVsc2UgaWYgcGFyYW0gPSBSRV9QQVJBTS5leGVjKHYpP1sxXVxuICAgICAgICAgICAgICAgICAgICAgZGF0YSA9ICcnXG4gICAgICAgICAgICAgICAgICAgICBjb3VudCsrXG4gICAgICAgICAgICAgICAgICAgICBwLm9uICdkYXRhJywgKGQpIC0+XG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhICs9IGQudG9TdHJpbmcoKVxuICAgICAgICAgICAgICAgICAgICAgcC5vbiAnZW5kJywgKCkgLT5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50LS1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtc1twYXJhbV0gPSBkYXRhXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiBjb3VudCBpcyAwIGFuZCBmaWxlU3RyZWFtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXEubXVsdGlwYXJ0ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVTdHJlYW06IGZpbGVTdHJlYW1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiBmaWxlTmFtZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZVR5cGU6IGZpbGVUeXBlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IHBhcmFtc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2VTZW50ID0gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgbmV4dCgpXG4gICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4gXCJEaWNlciBwYXJ0XCIsIHZcblxuICAgICAgICAgICAgaWYgY291bnQgaXMgMCBhbmQgZmlsZVN0cmVhbVxuICAgICAgICAgICAgICAgcmVxLm11bHRpcGFydCA9XG4gICAgICAgICAgICAgICAgICBmaWxlU3RyZWFtOiBmaWxlU3RyZWFtXG4gICAgICAgICAgICAgICAgICBmaWxlTmFtZTogZmlsZU5hbWVcbiAgICAgICAgICAgICAgICAgIGZpbGVUeXBlOiBmaWxlVHlwZVxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiBwYXJhbXNcbiAgICAgICAgICAgICAgIHJlc3BvbnNlU2VudCA9IHRydWVcbiAgICAgICAgICAgICAgIG5leHQoKVxuXG4gICAgICAgICBwLm9uICdlcnJvcicsIChlcnIpIC0+XG4gICAgICAgICAgICBoYW5kbGVGYWlsdXJlICdFcnJvciBpbiBEaWNlciB3aGlsZSBwYXJzaW5nIG11bHRpcGFydDonLCBlcnJcblxuICAgICAgZC5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgaGFuZGxlRmFpbHVyZSAnRXJyb3IgaW4gRGljZXIgd2hpbGUgcGFyc2luZyBwYXJ0czonLCBlcnJcblxuICAgICAgZC5vbiAnZmluaXNoJywgKCkgLT5cbiAgICAgICAgIHVubGVzcyBmaWxlU3RyZWFtXG4gICAgICAgICAgICBoYW5kbGVGYWlsdXJlIFwiRXJyb3IgaW4gRGljZXIsIG5vIGZpbGUgZm91bmQgaW4gUE9TVFwiXG5cbiAgICAgIHJlcS5waXBlKGQpXG5cbiAgICMgSGFuZGxlIGEgZ2VuZXJpYyBIVFRQIFBPU1QgZmlsZSB1cGxvYWRcblxuICAgIyBUaGlzIGN1cmwgY29tbWFuZCBzaG91bGQgYmUgcHJvcGVybHkgaGFuZGxlZCBieSB0aGlzIGNvZGU6XG4gICAjICUgY3VybCAtWCBQT1NUICdodHRwOi8vMTI3LjAuMC4xOjMwMDAvZ3JpZGZzL2ZzLzM4YTE0YzhmZWYyZDZjZWY1M2M3MDc5MicgXFxcbiAgICMgICAgICAgIC1GICdmaWxlPUBcInVuaXZlcnNlLnBuZ1wiO3R5cGU9aW1hZ2UvcG5nJyAtSCAnWC1BdXRoLVRva2VuOiB6cnRyb3RIckR6d0E0bkM1J1xuXG4gICBwb3N0ID0gKHJlcSwgcmVzLCBuZXh0KSAtPlxuICAgICAgIyBIYW5kbGUgZmlsZW5hbWUgb3IgZmlsZXR5cGUgZGF0YSB3aGVuIGluY2x1ZGVkXG4gICAgICByZXEuZ3JpZEZTLmNvbnRlbnRUeXBlID0gcmVxLm11bHRpcGFydC5maWxlVHlwZSBpZiByZXEubXVsdGlwYXJ0LmZpbGVUeXBlXG4gICAgICByZXEuZ3JpZEZTLmZpbGVuYW1lID0gcmVxLm11bHRpcGFydC5maWxlTmFtZSBpZiByZXEubXVsdGlwYXJ0LmZpbGVOYW1lXG5cbiAgICAgICMgV3JpdGUgdGhlIGZpbGUgZGF0YS4gIE5vIGNodW5rcyBoZXJlLCB0aGlzIGlzIHRoZSB3aG9sZSB0aGluZ1xuICAgICAgc3RyZWFtID0gQHVwc2VydFN0cmVhbSByZXEuZ3JpZEZTXG4gICAgICBpZiBzdHJlYW1cbiAgICAgICAgIHJlcS5tdWx0aXBhcnQuZmlsZVN0cmVhbS5waXBlKHNoYXJlLnN0cmVhbUNodW5rZXIoQGNodW5rU2l6ZSkpLnBpcGUoc3RyZWFtKVxuICAgICAgICAgICAgLm9uICdjbG9zZScsIChyZXRGaWxlKSAtPlxuICAgICAgICAgICAgICAgaWYgcmV0RmlsZVxuICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCgyMDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgIC5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgIGVsc2VcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoNDEwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgcmVzLmVuZCgpXG5cbiAgICMgSGFuZGxlIGEgZ2VuZXJpYyBIVFRQIEdFVCByZXF1ZXN0XG4gICAjIFRoaXMgYWxzbyBoYW5kbGVzIEhFQUQgcmVxdWVzdHNcbiAgICMgSWYgdGhlIHJlcXVlc3QgVVJMIGhhcyBhIFwiP2Rvd25sb2FkPXRydWVcIiBxdWVyeSwgdGhlbiBhIGJyb3dzZXIgZG93bmxvYWQgcmVzcG9uc2UgaXMgdHJpZ2dlcmVkXG5cbiAgIGdldCA9IChyZXEsIHJlcywgbmV4dCkgLT5cblxuICAgICAgaGVhZGVycyA9IHt9XG4gICAgICBmb3IgaCwgdiBvZiBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzXG4gICAgICAgICBoZWFkZXJzW2hdID0gdlxuXG4gICAgICAjIyBJZiBJZi1Nb2RpZmllZC1TaW5jZSBoZWFkZXIgcHJlc2VudCwgYW5kIHBhcnNlcyB0byBhIGRhdGUsIHRoZW4gd2VcbiAgICAgICMjIHJldHVybiAzMDQgKE5vdCBNb2RpZmllZCBTaW5jZSkgaWYgdGhlIG1vZGlmaWNhdGlvbiBkYXRlIGlzIGxlc3MgdGhhblxuICAgICAgIyMgdGhlIHNwZWNpZmllZCBkYXRlLCBvciB0aGV5IGJvdGggZm9ybWF0IHRvIHRoZSBzYW1lIFVUQyBzdHJpbmdcbiAgICAgICMjICh3aGljaCBjYW4gZGVhbCB3aXRoIHNvbWUgc3ViLXNlY29uZCByb3VuZGluZyBjYXVzZWQgYnkgZm9ybWF0dGluZykuXG4gICAgICBpZiByZXEuaGVhZGVyc1snaWYtbW9kaWZpZWQtc2luY2UnXVxuICAgICAgICAgc2luY2UgPSBEYXRlLnBhcnNlIHJlcS5oZWFkZXJzWydpZi1tb2RpZmllZC1zaW5jZSddICAjIyBOYU4gaWYgaW52YWlsZFxuICAgICAgICAgaWYgc2luY2UgYW5kIHJlcS5ncmlkRlMudXBsb2FkRGF0ZSBhbmQgKHJlcS5oZWFkZXJzWydpZi1tb2RpZmllZC1zaW5jZSddID09IHJlcS5ncmlkRlMudXBsb2FkRGF0ZS50b1VUQ1N0cmluZygpIG9yIHNpbmNlID49IHJlcS5ncmlkRlMudXBsb2FkRGF0ZS5nZXRUaW1lKCkpXG4gICAgICAgICAgICByZXMud3JpdGVIZWFkIDMwNCwgaGVhZGVyc1xuICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICByZXR1cm5cblxuICAgICAgIyBJZiByYW5nZSByZXF1ZXN0IGluIHRoZSBoZWFkZXJcbiAgICAgIGlmIHJlcS5oZWFkZXJzWydyYW5nZSddXG4gICAgICAgICMgU2V0IHN0YXR1cyBjb2RlIHRvIHBhcnRpYWwgZGF0YVxuICAgICAgICBzdGF0dXNDb2RlID0gMjA2XG5cbiAgICAgICAgIyBQaWNrIG91dCB0aGUgcmFuZ2UgcmVxdWlyZWQgYnkgdGhlIGJyb3dzZXJcbiAgICAgICAgcGFydHMgPSByZXEuaGVhZGVyc1tcInJhbmdlXCJdLnJlcGxhY2UoL2J5dGVzPS8sIFwiXCIpLnNwbGl0KFwiLVwiKVxuICAgICAgICBzdGFydCA9IHBhcnNlSW50KHBhcnRzWzBdLCAxMClcbiAgICAgICAgZW5kID0gKGlmIHBhcnRzWzFdIHRoZW4gcGFyc2VJbnQocGFydHNbMV0sIDEwKSBlbHNlIHJlcS5ncmlkRlMubGVuZ3RoIC0gMSlcblxuICAgICAgICAjIFVuYWJsZSB0byBoYW5kbGUgcmFuZ2UgcmVxdWVzdCAtIFNlbmQgdGhlIHZhbGlkIHJhbmdlIHdpdGggc3RhdHVzIGNvZGUgNDE2XG4gICAgICAgIGlmIChzdGFydCA8IDApIG9yIChlbmQgPj0gcmVxLmdyaWRGUy5sZW5ndGgpIG9yIChzdGFydCA+IGVuZCkgb3IgaXNOYU4oc3RhcnQpIG9yIGlzTmFOKGVuZClcbiAgICAgICAgICBoZWFkZXJzWydDb250ZW50LVJhbmdlJ10gPSAnYnl0ZXMgJyArICcqLycgKyByZXEuZ3JpZEZTLmxlbmd0aFxuICAgICAgICAgIHJlcy53cml0ZUhlYWQgNDE2LCBoZWFkZXJzXG4gICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgIyBEZXRlcm1pbmUgdGhlIGNodW5rIHNpemVcbiAgICAgICAgY2h1bmtzaXplID0gKGVuZCAtIHN0YXJ0KSArIDFcblxuICAgICAgICAjIENvbnN0cnVjdCB0aGUgcmFuZ2UgcmVxdWVzdCBoZWFkZXJcbiAgICAgICAgaGVhZGVyc1snQ29udGVudC1SYW5nZSddID0gJ2J5dGVzICcgKyBzdGFydCArICctJyArIGVuZCArICcvJyArIHJlcS5ncmlkRlMubGVuZ3RoXG4gICAgICAgIGhlYWRlcnNbJ0FjY2VwdC1SYW5nZXMnXSA9ICdieXRlcydcbiAgICAgICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSByZXEuZ3JpZEZTLmNvbnRlbnRUeXBlXG4gICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtTGVuZ3RoJ10gPSBjaHVua3NpemVcbiAgICAgICAgaGVhZGVyc1snTGFzdC1Nb2RpZmllZCddID0gcmVxLmdyaWRGUy51cGxvYWREYXRlLnRvVVRDU3RyaW5nKClcblxuICAgICAgICAjIFJlYWQgdGhlIHBhcnRpYWwgcmVxdWVzdCBmcm9tIGdyaWRmcyBzdHJlYW1cbiAgICAgICAgdW5sZXNzIHJlcS5tZXRob2QgaXMgJ0hFQUQnXG4gICAgICAgICAgIHN0cmVhbSA9IEBmaW5kT25lU3RyZWFtKFxuICAgICAgICAgICAgIF9pZDogcmVxLmdyaWRGUy5faWRcbiAgICAgICAgICAgLFxuICAgICAgICAgICAgIHJhbmdlOlxuICAgICAgICAgICAgICAgc3RhcnQ6IHN0YXJ0XG4gICAgICAgICAgICAgICBlbmQ6IGVuZFxuICAgICAgICAgICApXG5cbiAgICAgICMgT3RoZXJ3aXNlIHByZXBhcmUgdG8gc3RyZWFtIHRoZSB3aG9sZSBmaWxlXG4gICAgICBlbHNlXG4gICAgICAgICMgU2V0IGRlZmF1bHQgc3RhdHVzIGNvZGVcbiAgICAgICAgc3RhdHVzQ29kZSA9IDIwMFxuXG4gICAgICAgICMgU2V0IGRlZmF1bHQgaGVhZGVyc1xuICAgICAgICBoZWFkZXJzWydDb250ZW50LVR5cGUnXSA9IHJlcS5ncmlkRlMuY29udGVudFR5cGVcbiAgICAgICAgaGVhZGVyc1snQ29udGVudC1NRDUnXSA9IHJlcS5ncmlkRlMubWQ1XG4gICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtTGVuZ3RoJ10gPSByZXEuZ3JpZEZTLmxlbmd0aFxuICAgICAgICBoZWFkZXJzWydMYXN0LU1vZGlmaWVkJ10gPSByZXEuZ3JpZEZTLnVwbG9hZERhdGUudG9VVENTdHJpbmcoKVxuXG4gICAgICAgICMgT3BlbiBmaWxlIHRvIHN0cmVhbVxuICAgICAgICB1bmxlc3MgcmVxLm1ldGhvZCBpcyAnSEVBRCdcbiAgICAgICAgICAgc3RyZWFtID0gQGZpbmRPbmVTdHJlYW0geyBfaWQ6IHJlcS5ncmlkRlMuX2lkIH1cblxuICAgICAgIyBUcmlnZ2VyIGRvd25sb2FkIGluIGJyb3dzZXIsIG9wdGlvbmFsbHkgc3BlY2lmeSBmaWxlbmFtZS5cbiAgICAgIGlmIChyZXEucXVlcnkuZG93bmxvYWQgYW5kIHJlcS5xdWVyeS5kb3dubG9hZC50b0xvd2VyQ2FzZSgpID09ICd0cnVlJykgb3IgcmVxLnF1ZXJ5LmZpbGVuYW1lXG4gICAgICAgIGZpbGVuYW1lID0gZW5jb2RlVVJJQ29tcG9uZW50KHJlcS5xdWVyeS5maWxlbmFtZSA/IHJlcS5ncmlkRlMuZmlsZW5hbWUpXG4gICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtRGlzcG9zaXRpb24nXSA9IFwiYXR0YWNobWVudDsgZmlsZW5hbWU9XFxcIiN7ZmlsZW5hbWV9XFxcIjsgZmlsZW5hbWUqPVVURi04Jycje2ZpbGVuYW1lfVwiXG5cbiAgICAgICMgSWYgc3BlY2lmaWVkIGluIHVybCBxdWVyeSBzZXQgY2FjaGUgdG8gc3BlY2lmaWVkIHZhbHVlLCBtaWdodCB3YW50IHRvIGFkZCBtb3JlIG9wdGlvbnMgbGF0ZXIuXG4gICAgICBpZiByZXEucXVlcnkuY2FjaGUgYW5kIG5vdCBpc05hTihwYXJzZUludChyZXEucXVlcnkuY2FjaGUpKVxuICAgICAgICBoZWFkZXJzWydDYWNoZS1Db250cm9sJ10gPSBcIm1heC1hZ2U9XCIgKyBwYXJzZUludChyZXEucXVlcnkuY2FjaGUpK1wiLCBwcml2YXRlXCJcblxuICAgICAgIyBIRUFEcyBkb24ndCBoYXZlIGEgYm9keVxuICAgICAgaWYgcmVxLm1ldGhvZCBpcyAnSEVBRCdcbiAgICAgICAgcmVzLndyaXRlSGVhZCAyMDQsIGhlYWRlcnNcbiAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgIHJldHVyblxuXG4gICAgICAjIFN0cmVhbSBmaWxlXG4gICAgICBpZiBzdHJlYW1cbiAgICAgICAgIHJlcy53cml0ZUhlYWQgc3RhdHVzQ29kZSwgaGVhZGVyc1xuICAgICAgICAgc3RyZWFtLnBpcGUocmVzKVxuICAgICAgICAgICAgLm9uICdjbG9zZScsICgpIC0+XG4gICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgIC5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICByZXMuZW5kKGVycilcbiAgICAgIGVsc2VcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoNDEwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgcmVzLmVuZCgpXG5cbiAgICMgSGFuZGxlIGEgZ2VuZXJpYyBIVFRQIFBVVCByZXF1ZXN0XG5cbiAgICMgVGhpcyBjdXJsIGNvbW1hbmQgc2hvdWxkIGJlIHByb3Blcmx5IGhhbmRsZWQgYnkgdGhpcyBjb2RlOlxuICAgIyAlIGN1cmwgLVggUFVUICdodHRwOi8vMTI3LjAuMC4xOjMwMDAvZ3JpZGZzL2ZzLzc4NjhmM2RmODQyNWFlNjhhNTcyYjMzNCcgXFxcbiAgICMgICAgICAgIC1UIFwidW5pdmVyc2UucG5nXCIgLUggJ0NvbnRlbnQtVHlwZTogaW1hZ2UvcG5nJyAtSCAnWC1BdXRoLVRva2VuOiB0RVBBd1hiR3dnZkdpSkwzNSdcblxuICAgcHV0ID0gKHJlcSwgcmVzLCBuZXh0KSAtPlxuXG4gICAgICAjIEhhbmRsZSBjb250ZW50IHR5cGUgaWYgaXQncyBwcmVzZW50XG4gICAgICBpZiByZXEuaGVhZGVyc1snY29udGVudC10eXBlJ11cbiAgICAgICAgIHJlcS5ncmlkRlMuY29udGVudFR5cGUgPSByZXEuaGVhZGVyc1snY29udGVudC10eXBlJ11cblxuICAgICAgIyBXcml0ZSB0aGUgZmlsZVxuICAgICAgc3RyZWFtID0gQHVwc2VydFN0cmVhbSByZXEuZ3JpZEZTXG4gICAgICBpZiBzdHJlYW1cbiAgICAgICAgIHJlcS5waXBlKHNoYXJlLnN0cmVhbUNodW5rZXIoQGNodW5rU2l6ZSkpLnBpcGUoc3RyZWFtKVxuICAgICAgICAgICAgLm9uICdjbG9zZScsIChyZXRGaWxlKSAtPlxuICAgICAgICAgICAgICAgaWYgcmV0RmlsZVxuICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCgyMDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIC5vbiAnZXJyb3InLCAoZXJyKSAtPlxuICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICByZXMuZW5kKGVycilcbiAgICAgIGVsc2VcbiAgICAgICAgIHJlcy53cml0ZUhlYWQoNDA0LCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgcmVzLmVuZChcIiN7cmVxLnVybH0gTm90IGZvdW5kIVwiKVxuXG4gICAjIEhhbmRsZSBhIGdlbmVyaWMgSFRUUCBERUxFVEUgcmVxdWVzdFxuXG4gICAjIFRoaXMgY3VybCBjb21tYW5kIHNob3VsZCBiZSBwcm9wZXJseSBoYW5kbGVkIGJ5IHRoaXMgY29kZTpcbiAgICMgJSBjdXJsIC1YIERFTEVURSAnaHR0cDovLzEyNy4wLjAuMTozMDAwL2dyaWRmcy9mcy83ODY4ZjNkZjg0MjVhZTY4YTU3MmIzMzQnIFxcXG4gICAjICAgICAgICAtSCAnWC1BdXRoLVRva2VuOiB0RVBBd1hiR3dnZkdpSkwzNSdcblxuICAgZGVsID0gKHJlcSwgcmVzLCBuZXh0KSAtPlxuXG4gICAgICBAcmVtb3ZlIHJlcS5ncmlkRlNcbiAgICAgIHJlcy53cml0ZUhlYWQoMjA0LCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgcmVzLmVuZCgpXG5cbiAgICMgU2V0dXAgYWxsIG9mIHRoZSBhcHBsaWNhdGlvbiBzcGVjaWZpZWQgcGF0aHMgYW5kIGZpbGUgbG9va3VwcyBpbiBleHByZXNzXG4gICAjIEFsc28gcGVyZm9ybXMgYWxsb3cvZGVueSBwZXJtaXNzaW9uIGNoZWNrcyBmb3IgUE9TVC9QVVQvREVMRVRFXG5cbiAgIGJ1aWxkX2FjY2Vzc19wb2ludCA9IChodHRwKSAtPlxuXG4gICAgICAjIExvb3Agb3ZlciB0aGUgYXBwIHN1cHBsaWVkIGh0dHAgcGF0aHNcbiAgICAgIGZvciByIGluIGh0dHBcblxuICAgICAgICAgaWYgci5tZXRob2QudG9VcHBlckNhc2UoKSBpcyAnUE9TVCdcbiAgICAgICAgICAgIEByb3V0ZXIucG9zdCByLnBhdGgsIGRpY2VfbXVsdGlwYXJ0XG5cbiAgICAgICAgICMgQWRkIGFuIGV4cHJlc3MgbWlkZGxld2FyZSBmb3IgZWFjaCBhcHBsaWNhdGlvbiBSRVNUIHBhdGhcbiAgICAgICAgIEByb3V0ZXJbci5tZXRob2RdIHIucGF0aCwgZG8gKHIpID0+XG5cbiAgICAgICAgICAgIChyZXEsIHJlcywgbmV4dCkgPT5cblxuICAgICAgICAgICAgICAgIyBwYXJhbXMgYW5kIHF1ZXJpZXMgbGl0ZXJhbGx5IG5hbWVkIFwiX2lkXCIgZ2V0IGNvbnZlcnRlZCB0byBPYmplY3RJRHMgYXV0b21hdGljYWxseVxuICAgICAgICAgICAgICAgcmVxLnBhcmFtcy5faWQgPSBzaGFyZS5zYWZlT2JqZWN0SUQocmVxLnBhcmFtcy5faWQpIGlmIHJlcS5wYXJhbXM/Ll9pZD9cbiAgICAgICAgICAgICAgIHJlcS5xdWVyeS5faWQgPSBzaGFyZS5zYWZlT2JqZWN0SUQocmVxLnF1ZXJ5Ll9pZCkgaWYgcmVxLnF1ZXJ5Py5faWQ/XG5cbiAgICAgICAgICAgICAgICMgQnVpbGQgdGhlIHBhdGggbG9va3VwIG1vbmdvREIgcXVlcnkgb2JqZWN0IGZvciB0aGUgZ3JpZEZTIGZpbGVzIGNvbGxlY3Rpb25cbiAgICAgICAgICAgICAgIGxvb2t1cCA9IHIubG9va3VwPy5iaW5kKEApKHJlcS5wYXJhbXMgb3Ige30sIHJlcS5xdWVyeSBvciB7fSwgcmVxLm11bHRpcGFydClcbiAgICAgICAgICAgICAgIHVubGVzcyBsb29rdXA/XG4gICAgICAgICAgICAgICAgICAjIE5vIGxvb2t1cCByZXR1cm5lZCwgc28gYmFpbGluZ1xuICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgIyBQZXJmb3JtIHRoZSBjb2xsZWN0aW9uIHF1ZXJ5XG4gICAgICAgICAgICAgICAgICByZXEuZ3JpZEZTID0gQGZpbmRPbmUgbG9va3VwXG4gICAgICAgICAgICAgICAgICB1bmxlc3MgcmVxLmdyaWRGU1xuICAgICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg0MDQsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgICAgICAgICAgIHJldHVyblxuXG4gICAgICAgICAgICAgICAgICAjIE1ha2Ugc3VyZSB0aGF0IHRoZSByZXF1ZXN0ZWQgbWV0aG9kIGlzIHBlcm1pdHRlZCBmb3IgdGhpcyBmaWxlIGluIHRoZSBhbGxvdy9kZW55IHJ1bGVzXG4gICAgICAgICAgICAgICAgICBzd2l0Y2ggcmVxLm1ldGhvZFxuICAgICAgICAgICAgICAgICAgICAgd2hlbiAnSEVBRCcsICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB1bmxlc3Mgc2hhcmUuY2hlY2tfYWxsb3dfZGVueS5iaW5kKEApICdyZWFkJywgcmVxLm1ldGVvclVzZXJJZCwgcmVxLmdyaWRGU1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg0MDMsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXMuZW5kKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblxuICAgICAgICAgICAgICAgICAgICAgd2hlbiAnUE9TVCcsICdQVVQnXG4gICAgICAgICAgICAgICAgICAgICAgICByZXEubWF4VXBsb2FkU2l6ZSA9IEBtYXhVcGxvYWRTaXplXG4gICAgICAgICAgICAgICAgICAgICAgICB1bmxlc3Mgb3B0cyA9IHNoYXJlLmNoZWNrX2FsbG93X2RlbnkuYmluZChAKSAnd3JpdGUnLCByZXEubWV0ZW9yVXNlcklkLCByZXEuZ3JpZEZTXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDQwMywgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5lbmQoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiBvcHRzLm1heFVwbG9hZFNpemU/IGFuZCB0eXBlb2Ygb3B0cy5tYXhVcGxvYWRTaXplIGlzICdudW1iZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXEubWF4VXBsb2FkU2l6ZSA9IG9wdHMubWF4VXBsb2FkU2l6ZVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgcmVxLm1heFVwbG9hZFNpemUgPiAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB1bmxlc3MgcmVxLmhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ10/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDQxMSwgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5lbmQoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB1bmxlc3MgcGFyc2VJbnQocmVxLmhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ10pIDw9IHJlcS5tYXhVcGxvYWRTaXplXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDQxMywgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5lbmQoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgICB3aGVuICdERUxFVEUnXG4gICAgICAgICAgICAgICAgICAgICAgICB1bmxlc3Mgc2hhcmUuY2hlY2tfYWxsb3dfZGVueS5iaW5kKEApICdyZW1vdmUnLCByZXEubWV0ZW9yVXNlcklkLCByZXEuZ3JpZEZTXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXMud3JpdGVIZWFkKDQwMywgc2hhcmUuZGVmYXVsdFJlc3BvbnNlSGVhZGVycylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcy5lbmQoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgICB3aGVuICdPUFRJT05TJyAgIyBTaG91bGQgdGhlcmUgYmUgYSBwZXJtaXNzaW9uIGZvciBvcHRpb25zP1xuICAgICAgICAgICAgICAgICAgICAgICAgdW5sZXNzIChzaGFyZS5jaGVja19hbGxvd19kZW55LmJpbmQoQCkoJ3JlYWQnLCByZXEubWV0ZW9yVXNlcklkLCByZXEuZ3JpZEZTKSBvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaGFyZS5jaGVja19hbGxvd19kZW55LmJpbmQoQCkoJ3dyaXRlJywgcmVxLm1ldGVvclVzZXJJZCwgcmVxLmdyaWRGUykgb3JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hhcmUuY2hlY2tfYWxsb3dfZGVueS5iaW5kKEApKCdyZW1vdmUnLCByZXEubWV0ZW9yVXNlcklkLCByZXEuZ3JpZEZTKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcy53cml0ZUhlYWQoNDAzLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcy53cml0ZUhlYWQoNTAwLCBzaGFyZS5kZWZhdWx0UmVzcG9uc2VIZWFkZXJzKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzLmVuZCgpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm5cblxuICAgICAgICAgICAgICAgICAgbmV4dCgpXG5cbiAgICAgICAgICMgQWRkIGFuIGV4cHJlc3MgbWlkZGxld2FyZSBmb3IgZWFjaCBjdXN0b20gcmVxdWVzdCBoYW5kbGVyXG4gICAgICAgICBpZiB0eXBlb2Ygci5oYW5kbGVyIGlzICdmdW5jdGlvbidcbiAgICAgICAgICAgIEByb3V0ZXJbci5tZXRob2RdIHIucGF0aCwgci5oYW5kbGVyLmJpbmQoQClcblxuICAgICAgIyBBZGQgYWxsIG9mIGdlbmVyaWMgcmVxdWVzdCBoYW5kbGluZyBtZXRob2RzIHRvIHRoZSBleHByZXNzIHJvdXRlXG4gICAgICBAcm91dGVyLnJvdXRlKCcvKicpXG4gICAgICAgICAuaGVhZChnZXQuYmluZChAKSkgICAjIEdlbmVyaWMgSFRUUCBtZXRob2QgaGFuZGxlcnNcbiAgICAgICAgIC5nZXQoZ2V0LmJpbmQoQCkpXG4gICAgICAgICAucHV0KHB1dC5iaW5kKEApKVxuICAgICAgICAgLnBvc3QocG9zdC5iaW5kKEApKVxuICAgICAgICAgLmRlbGV0ZShkZWwuYmluZChAKSlcbiAgICAgICAgIC5hbGwgKHJlcSwgcmVzLCBuZXh0KSAtPiAgICMgVW5rb3duIG1ldGhvZHMgYXJlIGRlbmllZFxuICAgICAgICAgICAgcmVzLndyaXRlSGVhZCg1MDAsIHNoYXJlLmRlZmF1bHRSZXNwb25zZUhlYWRlcnMpXG4gICAgICAgICAgICByZXMuZW5kKClcblxuICAgIyBQZXJmb3JtcyBhIG1ldGVvciB1c2VySWQgbG9va3VwIGJ5IGhhc2VkIGFjY2VzcyB0b2tlblxuXG4gICBsb29rdXBfdXNlcklkX2J5X3Rva2VuID0gKGF1dGhUb2tlbikgLT5cbiAgICAgIHVzZXJEb2MgPSBNZXRlb3IudXNlcnM/LmZpbmRPbmVcbiAgICAgICAgICdzZXJ2aWNlcy5yZXN1bWUubG9naW5Ub2tlbnMnOlxuICAgICAgICAgICAgJGVsZW1NYXRjaDpcbiAgICAgICAgICAgICAgIGhhc2hlZFRva2VuOiBBY2NvdW50cz8uX2hhc2hMb2dpblRva2VuKGF1dGhUb2tlbilcbiAgICAgIHJldHVybiB1c2VyRG9jPy5faWQgb3IgbnVsbFxuXG4gICAjIEV4cHJlc3MgbWlkZGxld2FyZSB0byBjb252ZXJ0IGEgTWV0ZW9yIGFjY2VzcyB0b2tlbiBwcm92aWRlZCBpbiBhbiBIVFRQIHJlcXVlc3RcbiAgICMgdG8gYSBNZXRlb3IgdXNlcklkIGF0dGFjaGVkIHRvIHRoZSByZXF1ZXN0IG9iamVjdCBhcyByZXEubWV0ZW9yVXNlcklkXG5cbiAgIGhhbmRsZV9hdXRoID0gKHJlcSwgcmVzLCBuZXh0KSAtPlxuICAgICAgdW5sZXNzIHJlcS5tZXRlb3JVc2VySWQ/XG4gICAgICAgICAjIExvb2t1cCB1c2VySWQgaWYgdG9rZW4gaXMgcHJvdmlkZWQgaW4gSFRUUCBoZWRlclxuICAgICAgICAgaWYgcmVxLmhlYWRlcnM/Wyd4LWF1dGgtdG9rZW4nXT9cbiAgICAgICAgICAgIHJlcS5tZXRlb3JVc2VySWQgPSBsb29rdXBfdXNlcklkX2J5X3Rva2VuIHJlcS5oZWFkZXJzWyd4LWF1dGgtdG9rZW4nXVxuICAgICAgICAgIyBPciBhcyBhIFVSTCBxdWVyeSBvZiB0aGUgc2FtZSBuYW1lXG4gICAgICAgICBlbHNlIGlmIHJlcS5jb29raWVzP1snWC1BdXRoLVRva2VuJ10/XG4gICAgICAgICAgICByZXEubWV0ZW9yVXNlcklkID0gbG9va3VwX3VzZXJJZF9ieV90b2tlbiByZXEuY29va2llc1snWC1BdXRoLVRva2VuJ11cbiAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIHJlcS5tZXRlb3JVc2VySWQgPSBudWxsXG4gICAgICBuZXh0KClcblxuICAgIyBTZXQgdXAgYWxsIG9mIHRoZSBtaWRkbGV3YXJlLCBpbmNsdWRpbmcgb3B0aW9uYWwgc3VwcG9ydCBmb3IgUmVzdW1hYmxlLmpzIGNodW5rZWQgdXBsb2Fkc1xuICAgc2hhcmUuc2V0dXBIdHRwQWNjZXNzID0gKG9wdGlvbnMpIC0+XG5cbiAgICAgICMgU2V0IHVwIHN1cHBvcnQgZm9yIHJlc3VtYWJsZS5qcyBpZiByZXF1ZXN0ZWRcbiAgICAgIGlmIG9wdGlvbnMucmVzdW1hYmxlXG4gICAgICAgICBvcHRpb25zLmh0dHAgPSBbXSB1bmxlc3Mgb3B0aW9ucy5odHRwP1xuICAgICAgICAgcmVzdW1hYmxlSGFuZGxlcnMgPSBbXVxuICAgICAgICAgb3RoZXJIYW5kbGVycyA9IFtdXG4gICAgICAgICBmb3IgaCBpbiBvcHRpb25zLmh0dHBcbiAgICAgICAgICAgIGlmIGgucGF0aCBpcyBzaGFyZS5yZXN1bWFibGVCYXNlXG4gICAgICAgICAgICAgICByZXN1bWFibGVIYW5kbGVycy5wdXNoIGhcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgIG90aGVySGFuZGxlcnMucHVzaCBoXG4gICAgICAgICByZXN1bWFibGVIYW5kbGVycyA9IHJlc3VtYWJsZUhhbmRsZXJzLmNvbmNhdCBzaGFyZS5yZXN1bWFibGVQYXRoc1xuICAgICAgICAgb3B0aW9ucy5odHRwID0gcmVzdW1hYmxlSGFuZGxlcnMuY29uY2F0IG90aGVySGFuZGxlcnNcblxuICAgICAgIyBEb24ndCBzZXR1cCBhbnkgbWlkZGxld2FyZSB1bmxlc3MgdGhlcmUgYXJlIHJvdXRlcyBkZWZpbmVkXG4gICAgICBpZiBvcHRpb25zLmh0dHA/Lmxlbmd0aCA+IDBcbiAgICAgICAgIHIgPSBleHByZXNzLlJvdXRlcigpXG4gICAgICAgICByLnVzZSBleHByZXNzLnF1ZXJ5KCkgICAjIFBhcnNlIFVSTCBxdWVyeSBzdHJpbmdzXG4gICAgICAgICByLnVzZSBjb29raWVQYXJzZXIoKSAgICAjIFBhcnNlIGNvb2tpZXNcbiAgICAgICAgIHIudXNlIGhhbmRsZV9hdXRoICAgICAgICMgVHVybiB4LWF1dGgtdG9rZW5zIGludG8gTWV0ZW9yIHVzZXJJZHNcbiAgICAgICAgIFdlYkFwcC5yYXdDb25uZWN0SGFuZGxlcnMudXNlKEBiYXNlVVJMLCBzaGFyZS5iaW5kX2VudihyKSlcblxuICAgICAgICAgIyBTZXR1cCBhcHBsaWNhdGlvbiBIVFRQIFJFU1QgaW50ZXJmYWNlXG4gICAgICAgICBAcm91dGVyID0gZXhwcmVzcy5Sb3V0ZXIoKVxuICAgICAgICAgYnVpbGRfYWNjZXNzX3BvaW50LmJpbmQoQCkob3B0aW9ucy5odHRwLCBAcm91dGVyKVxuICAgICAgICAgV2ViQXBwLnJhd0Nvbm5lY3RIYW5kbGVycy51c2UoQGJhc2VVUkwsIHNoYXJlLmJpbmRfZW52KEByb3V0ZXIpKVxuIl19
