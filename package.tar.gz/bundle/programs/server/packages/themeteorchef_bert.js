(function () {

/* Package-scope variables */
var Bert;



/* Exports */
Package._define("themeteorchef:bert", {
  Bert: Bert
});

})();
