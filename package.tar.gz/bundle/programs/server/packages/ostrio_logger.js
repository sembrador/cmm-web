(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:logger":{"logger.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/ostrio_logger/logger.js                                                                                 //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  Logger: () => Logger,
  LoggerMessage: () => LoggerMessage
});

let _;

module.watch(require("meteor/underscore"), {
  _(v) {
    _ = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let ReactiveVar;
module.watch(require("meteor/reactive-var"), {
  ReactiveVar(v) {
    ReactiveVar = v;
  }

}, 2);
let check, Match;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 3);
let _inst = 0;
/*
 * @class Logger
 * @summary Extend-able Logger class
 */

class Logger {
  constructor() {
    this.userId = new ReactiveVar(null);
    this.prefix = ++_inst;
    this._rules = {};
    this._emitters = [];

    if (Meteor.isClient) {
      const _accounts = Package && Package['accounts-base'] && Package['accounts-base'].Accounts ? Package['accounts-base'].Accounts : undefined;

      if (_accounts) {
        _accounts.onLogin(() => {
          this.userId.set(Meteor.userId());
        });

        _accounts.onLogout(() => {
          this.userId.set(null);
        });
      }
    }
  }
  /*
   * @memberOf Logger
   * @name _log
   * @param level    {String} - Log level Accepts 'ERROR', 'FATAL', 'WARN', 'DEBUG', 'INFO', 'TRACE', 'LOG' and '*'
   * @param message  {String} - Text human-readable message
   * @param data     {Object} - [optional] Any additional info as object
   * @param userId   {String} - [optional] Current user id
   * @summary Pass log's data to Server or/and Client
   */


  _log(level, message, _data = {}, user) {
    const uid = user || this.userId.get();
    let data = _data;

    for (let i in this._emitters) {
      if (this._rules[this._emitters[i].name] && this._rules[this._emitters[i].name].enable === true) {
        if (Meteor.isServer && this._rules[this._emitters[i].name].server === false || Meteor.isClient && this._rules[this._emitters[i].name].client === false) {
          continue;
        }

        if (this._rules[this._emitters[i].name].allow.indexOf('*') !== -1 || this._rules[this._emitters[i].name].allow.indexOf(level) !== -1) {
          if (level === 'TRACE') {
            if (_.isString(data)) {
              let __data = _.clone(data);

              data = {
                data: __data
              };
            }

            data.stackTrace = this._getStackTrace();
          }

          if (Meteor.isClient && this._emitters[i].denyClient === true && this._emitters[i].denyServer === false) {
            Meteor.call(this._emitters[i].method, level, message, data, uid);
          } else if (this._rules[this._emitters[i].name].client === true && this._rules[this._emitters[i].name].server === true && this._emitters[i].denyClient === false && this._emitters[i].denyServer === false) {
            this._emitters[i].emitter(level, message, data, uid);

            if (Meteor.isClient) {
              Meteor.call(this._emitters[i].method, level, message, data, uid);
            }
          } else if (Meteor.isClient && this._rules[this._emitters[i].name].client === false && this._rules[this._emitters[i].name].server === true) {
            Meteor.call(this._emitters[i].method, level, message, data, uid);
          } else {
            this._emitters[i].emitter(level, message, data, uid);
          }
        }
      }
    }

    return new LoggerMessage({
      level: level,
      error: level,
      reason: message,
      errorType: level,
      message: message,
      details: data,
      data: data,
      user: uid,
      userId: uid
    });
  }
  /*
   * @memberOf Logger
   * @name rule
   * @param name    {String} - Adapter name
   * @param options {Object} - Settings object
         options.enable {Boolean} - Enable/disable adapter
         options.filter {Array}   - Array of strings, accepts:
                                   'ERROR', 'FATAL', 'WARN', 'DEBUG', 'INFO', 'TRACE', 'LOG' and '*'
                                   in lowercase or uppercase
                                   default: ['*'] - Accept all
         options.client {Boolean} - Allow execution on Client
         options.server {Boolean} - Allow execution on Server
   * @summary Enable/disable adapter and set it's settings
   */


  rule(name, options) {
    check(name, String);
    check(options, {
      enable: Boolean,
      client: Match.Optional(Boolean),
      server: Match.Optional(Boolean),
      filter: Match.Optional([String])
    });

    if (!_.isArray(options.filter) || _.isEmpty(options.filter)) {
      options.filter = ['*'];
    }

    if (options.filter) {
      for (let j = 0; j < options.filter.length; j++) {
        options.filter[j] = options.filter[j].toUpperCase();
      }
    }

    if (!_.isBoolean(options.client)) {
      options.client = false;
    }

    if (!_.isBoolean(options.server)) {
      options.server = true;
    }

    if (!_.isBoolean(options.enable)) {
      options.enable = true;
    }

    this._rules[name] = {
      allow: options.filter,
      enable: options.enable,
      client: options.client,
      server: options.server
    };
  }
  /*
   * @memberOf Logger
   * @name add
   * @param name        {String}    - Adapter name
   * @param emitter     {Function}  - Function called on Meteor.log...
   * @param init        {Function}  - Adapter initialization function
   * @param denyClient  {Boolean}   - Strictly deny execution on client, only pass via Meteor.methods
   * @param denyServer  {Boolean}   - Strictly deny execution on server, only client
   * @summary Register new adapter to be used within ostrio:logger package
   */


  add(name, emitter, init, denyClient = false, denyServer = false) {
    if (Meteor.isServer && denyServer || Meteor.isClient && denyClient) {
      return;
    }

    if (init && _.isFunction(init)) {
      init();
    }

    this._emitters.push({
      name: name,
      emitter: emitter,
      method: `${this.prefix}_logger_emit_${name}`,
      denyClient: denyClient,
      denyServer: denyServer
    });

    if (Meteor.isServer) {
      const method = {};

      method[`${this.prefix}_logger_emit_${name}`] = function (level, message, data, userId) {
        check(level, String);
        check(message, Match.Optional(Match.OneOf(Number, String, null)));
        check(data, Match.Optional(Match.OneOf(String, Object, null)));
        check(userId, Match.Optional(Match.OneOf(String, Number, null)));
        emitter(level, message, data, userId || this.userId);
      };

      Meteor.methods(method);
    }
  }
  /*
   * @memberOf Logger
   * @name info; debug; error; fatal; warn; trace; log; _
   * @param message {String} - Any text message
   * @param data    {Object} - [optional] Any additional info as object
   * @param userId  {String} - [optional] Current user id
   * @summary Methods below is shortcuts for _log() method
   */


  info(message, data, userId) {
    return this._log('INFO', message, data, userId);
  }

  debug(message, data, userId) {
    return this._log('DEBUG', message, data, userId);
  }

  error(message, data, userId) {
    return this._log('ERROR', message, data, userId);
  }

  fatal(message, data, userId) {
    return this._log('FATAL', message, data, userId);
  }

  warn(message, data, userId) {
    return this._log('WARN', message, data, userId);
  }

  trace(message, data, userId) {
    return this._log('TRACE', message, data, userId);
  }

  log(message, data, userId) {
    return this._log('LOG', message, data, userId);
  }

  _(message, data, userId) {
    return this._log('LOG', message, data, userId);
  }
  /*
   * @memberOf Logger
   * @name antiCircular
   * @param data {Object} - Circular or any other object which needs to be non-circular
   */


  antiCircular(obj) {
    const _cache = [];

    const _wrap = o => {
      for (let v in o) {
        if (v !== null && typeof v === 'object') {
          if (_cache.indexOf(v) !== -1) {
            o[o[v]] = '[Circular]';
            break;
          }

          _cache.push(v);

          _wrap(v);

          break;
        }
      }
    };

    _wrap(obj);

    return obj;
  }
  /*
   * @memberOf Logger
   * @name _getStackTrace
   * @summary Prepare stack trace message
   */


  _getStackTrace() {
    let obj = {};

    if (_.isFunction(Error.captureStackTrace)) {
      Error.captureStackTrace(obj, this._getStackTrace);
    } else {
      const err = new Error();

      if (err.stack) {
        obj.stack = err.stack;
      } else {
        obj.stack = 'Not available of not supported';
      }
    }

    const idx = obj.stack.indexOf('_getStackTrace');
    const idx2 = obj.stack.indexOf('_log');

    if (idx >= 0) {
      obj.stack = obj.stack.substring(obj.stack.indexOf('\n', idx + 1) + 1);
    }

    if (idx2 >= 0) {
      obj.stack = obj.stack.substring(obj.stack.indexOf('\n', idx2 + 1) + 1);
    }

    return obj.stack;
  }

}
/*
 * @class LoggerMessage
 * @param data {Object}
 * @summary Construct message object, ready to be thrown and stringified
 */


class LoggerMessage {
  constructor(data) {
    this.data = data.data;
    this.user = data.user;
    this.level = data.level;
    this.error = data.error;
    this.userId = data.userId;
    this.reason = data.reason;
    this.details = data.details;
    this.message = data.message;

    this.toString = () => {
      return `[${this.reason}] \nLevel: ${this.level}; \nDetails: ${JSON.stringify(Logger.prototype.antiCircular(this.data))}; \nUserId: ${this.userId};`;
    };
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/ostrio:logger/logger.js");

/* Exports */
Package._define("ostrio:logger", exports);

})();

//# sourceURL=meteor://💻app/packages/ostrio_logger.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmxvZ2dlci9sb2dnZXIuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiTG9nZ2VyIiwiTG9nZ2VyTWVzc2FnZSIsIl8iLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiTWV0ZW9yIiwiUmVhY3RpdmVWYXIiLCJjaGVjayIsIk1hdGNoIiwiX2luc3QiLCJjb25zdHJ1Y3RvciIsInVzZXJJZCIsInByZWZpeCIsIl9ydWxlcyIsIl9lbWl0dGVycyIsImlzQ2xpZW50IiwiX2FjY291bnRzIiwiUGFja2FnZSIsIkFjY291bnRzIiwidW5kZWZpbmVkIiwib25Mb2dpbiIsInNldCIsIm9uTG9nb3V0IiwiX2xvZyIsImxldmVsIiwibWVzc2FnZSIsIl9kYXRhIiwidXNlciIsInVpZCIsImdldCIsImRhdGEiLCJpIiwibmFtZSIsImVuYWJsZSIsImlzU2VydmVyIiwic2VydmVyIiwiY2xpZW50IiwiYWxsb3ciLCJpbmRleE9mIiwiaXNTdHJpbmciLCJfX2RhdGEiLCJjbG9uZSIsInN0YWNrVHJhY2UiLCJfZ2V0U3RhY2tUcmFjZSIsImRlbnlDbGllbnQiLCJkZW55U2VydmVyIiwiY2FsbCIsIm1ldGhvZCIsImVtaXR0ZXIiLCJlcnJvciIsInJlYXNvbiIsImVycm9yVHlwZSIsImRldGFpbHMiLCJydWxlIiwib3B0aW9ucyIsIlN0cmluZyIsIkJvb2xlYW4iLCJPcHRpb25hbCIsImZpbHRlciIsImlzQXJyYXkiLCJpc0VtcHR5IiwiaiIsImxlbmd0aCIsInRvVXBwZXJDYXNlIiwiaXNCb29sZWFuIiwiYWRkIiwiaW5pdCIsImlzRnVuY3Rpb24iLCJwdXNoIiwiT25lT2YiLCJOdW1iZXIiLCJPYmplY3QiLCJtZXRob2RzIiwiaW5mbyIsImRlYnVnIiwiZmF0YWwiLCJ3YXJuIiwidHJhY2UiLCJsb2ciLCJhbnRpQ2lyY3VsYXIiLCJvYmoiLCJfY2FjaGUiLCJfd3JhcCIsIm8iLCJFcnJvciIsImNhcHR1cmVTdGFja1RyYWNlIiwiZXJyIiwic3RhY2siLCJpZHgiLCJpZHgyIiwic3Vic3RyaW5nIiwidG9TdHJpbmciLCJKU09OIiwic3RyaW5naWZ5IiwicHJvdG90eXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsVUFBTyxNQUFJQSxNQUFaO0FBQW1CQyxpQkFBYyxNQUFJQTtBQUFyQyxDQUFkOztBQUFtRSxJQUFJQyxDQUFKOztBQUFNSixPQUFPSyxLQUFQLENBQWFDLFFBQVEsbUJBQVIsQ0FBYixFQUEwQztBQUFDRixJQUFFRyxDQUFGLEVBQUk7QUFBQ0gsUUFBRUcsQ0FBRjtBQUFJOztBQUFWLENBQTFDLEVBQXNELENBQXREO0FBQXlELElBQUlDLE1BQUo7QUFBV1IsT0FBT0ssS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRSxTQUFPRCxDQUFQLEVBQVM7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJRSxXQUFKO0FBQWdCVCxPQUFPSyxLQUFQLENBQWFDLFFBQVEscUJBQVIsQ0FBYixFQUE0QztBQUFDRyxjQUFZRixDQUFaLEVBQWM7QUFBQ0Usa0JBQVlGLENBQVo7QUFBYzs7QUFBOUIsQ0FBNUMsRUFBNEUsQ0FBNUU7QUFBK0UsSUFBSUcsS0FBSixFQUFVQyxLQUFWO0FBQWdCWCxPQUFPSyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNJLFFBQU1ILENBQU4sRUFBUTtBQUFDRyxZQUFNSCxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSSxRQUFNSixDQUFOLEVBQVE7QUFBQ0ksWUFBTUosQ0FBTjtBQUFROztBQUFwQyxDQUFyQyxFQUEyRSxDQUEzRTtBQUszVCxJQUFJSyxRQUFRLENBQVo7QUFFQTs7Ozs7QUFJQSxNQUFNVixNQUFOLENBQWE7QUFDWFcsZ0JBQWM7QUFDWixTQUFLQyxNQUFMLEdBQWlCLElBQUlMLFdBQUosQ0FBZ0IsSUFBaEIsQ0FBakI7QUFDQSxTQUFLTSxNQUFMLEdBQWlCLEVBQUVILEtBQW5CO0FBQ0EsU0FBS0ksTUFBTCxHQUFpQixFQUFqQjtBQUNBLFNBQUtDLFNBQUwsR0FBaUIsRUFBakI7O0FBRUEsUUFBSVQsT0FBT1UsUUFBWCxFQUFxQjtBQUNuQixZQUFNQyxZQUFhQyxXQUFXQSxRQUFRLGVBQVIsQ0FBWCxJQUF1Q0EsUUFBUSxlQUFSLEVBQXlCQyxRQUFqRSxHQUE2RUQsUUFBUSxlQUFSLEVBQXlCQyxRQUF0RyxHQUFpSEMsU0FBbkk7O0FBQ0EsVUFBSUgsU0FBSixFQUFlO0FBQ2JBLGtCQUFVSSxPQUFWLENBQWtCLE1BQU07QUFDdEIsZUFBS1QsTUFBTCxDQUFZVSxHQUFaLENBQWdCaEIsT0FBT00sTUFBUCxFQUFoQjtBQUNELFNBRkQ7O0FBSUFLLGtCQUFVTSxRQUFWLENBQW1CLE1BQU07QUFDdkIsZUFBS1gsTUFBTCxDQUFZVSxHQUFaLENBQWdCLElBQWhCO0FBQ0QsU0FGRDtBQUdEO0FBQ0Y7QUFDRjtBQUVEOzs7Ozs7Ozs7OztBQVNBRSxPQUFLQyxLQUFMLEVBQVlDLE9BQVosRUFBcUJDLFFBQVEsRUFBN0IsRUFBaUNDLElBQWpDLEVBQXVDO0FBQ3JDLFVBQU1DLE1BQU1ELFFBQVEsS0FBS2hCLE1BQUwsQ0FBWWtCLEdBQVosRUFBcEI7QUFDQSxRQUFJQyxPQUFPSixLQUFYOztBQUVBLFNBQUssSUFBSUssQ0FBVCxJQUFjLEtBQUtqQixTQUFuQixFQUE4QjtBQUM1QixVQUFJLEtBQUtELE1BQUwsQ0FBWSxLQUFLQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCQyxJQUE5QixLQUF1QyxLQUFLbkIsTUFBTCxDQUFZLEtBQUtDLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JDLElBQTlCLEVBQW9DQyxNQUFwQyxLQUErQyxJQUExRixFQUFnRztBQUM5RixZQUFJNUIsT0FBTzZCLFFBQVAsSUFBbUIsS0FBS3JCLE1BQUwsQ0FBWSxLQUFLQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCQyxJQUE5QixFQUFvQ0csTUFBcEMsS0FBK0MsS0FBbEUsSUFBMkU5QixPQUFPVSxRQUFQLElBQW1CLEtBQUtGLE1BQUwsQ0FBWSxLQUFLQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCQyxJQUE5QixFQUFvQ0ksTUFBcEMsS0FBK0MsS0FBakosRUFBd0o7QUFDdEo7QUFDRDs7QUFFRCxZQUFJLEtBQUt2QixNQUFMLENBQVksS0FBS0MsU0FBTCxDQUFlaUIsQ0FBZixFQUFrQkMsSUFBOUIsRUFBb0NLLEtBQXBDLENBQTBDQyxPQUExQyxDQUFrRCxHQUFsRCxNQUEyRCxDQUFDLENBQTVELElBQWlFLEtBQUt6QixNQUFMLENBQVksS0FBS0MsU0FBTCxDQUFlaUIsQ0FBZixFQUFrQkMsSUFBOUIsRUFBb0NLLEtBQXBDLENBQTBDQyxPQUExQyxDQUFrRGQsS0FBbEQsTUFBNkQsQ0FBQyxDQUFuSSxFQUFzSTtBQUNwSSxjQUFJQSxVQUFVLE9BQWQsRUFBdUI7QUFDckIsZ0JBQUl2QixFQUFFc0MsUUFBRixDQUFXVCxJQUFYLENBQUosRUFBc0I7QUFDcEIsa0JBQUlVLFNBQVN2QyxFQUFFd0MsS0FBRixDQUFRWCxJQUFSLENBQWI7O0FBQ0FBLHFCQUFPO0FBQUNBLHNCQUFNVTtBQUFQLGVBQVA7QUFDRDs7QUFDRFYsaUJBQUtZLFVBQUwsR0FBa0IsS0FBS0MsY0FBTCxFQUFsQjtBQUNEOztBQUVELGNBQUl0QyxPQUFPVSxRQUFQLElBQW1CLEtBQUtELFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JhLFVBQWxCLEtBQWlDLElBQXBELElBQTRELEtBQUs5QixTQUFMLENBQWVpQixDQUFmLEVBQWtCYyxVQUFsQixLQUFpQyxLQUFqRyxFQUF3RztBQUN0R3hDLG1CQUFPeUMsSUFBUCxDQUFZLEtBQUtoQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCZ0IsTUFBOUIsRUFBc0N2QixLQUF0QyxFQUE2Q0MsT0FBN0MsRUFBc0RLLElBQXRELEVBQTRERixHQUE1RDtBQUNELFdBRkQsTUFFTyxJQUFJLEtBQUtmLE1BQUwsQ0FBWSxLQUFLQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCQyxJQUE5QixFQUFvQ0ksTUFBcEMsS0FBK0MsSUFBL0MsSUFBdUQsS0FBS3ZCLE1BQUwsQ0FBWSxLQUFLQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCQyxJQUE5QixFQUFvQ0csTUFBcEMsS0FBK0MsSUFBdEcsSUFBOEcsS0FBS3JCLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JhLFVBQWxCLEtBQWlDLEtBQS9JLElBQXdKLEtBQUs5QixTQUFMLENBQWVpQixDQUFmLEVBQWtCYyxVQUFsQixLQUFpQyxLQUE3TCxFQUFvTTtBQUN6TSxpQkFBSy9CLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JpQixPQUFsQixDQUEwQnhCLEtBQTFCLEVBQWlDQyxPQUFqQyxFQUEwQ0ssSUFBMUMsRUFBZ0RGLEdBQWhEOztBQUNBLGdCQUFJdkIsT0FBT1UsUUFBWCxFQUFxQjtBQUNuQlYscUJBQU95QyxJQUFQLENBQVksS0FBS2hDLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JnQixNQUE5QixFQUFzQ3ZCLEtBQXRDLEVBQTZDQyxPQUE3QyxFQUFzREssSUFBdEQsRUFBNERGLEdBQTVEO0FBQ0Q7QUFDRixXQUxNLE1BS0EsSUFBSXZCLE9BQU9VLFFBQVAsSUFBbUIsS0FBS0YsTUFBTCxDQUFZLEtBQUtDLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JDLElBQTlCLEVBQW9DSSxNQUFwQyxLQUErQyxLQUFsRSxJQUEyRSxLQUFLdkIsTUFBTCxDQUFZLEtBQUtDLFNBQUwsQ0FBZWlCLENBQWYsRUFBa0JDLElBQTlCLEVBQW9DRyxNQUFwQyxLQUErQyxJQUE5SCxFQUFvSTtBQUN6STlCLG1CQUFPeUMsSUFBUCxDQUFZLEtBQUtoQyxTQUFMLENBQWVpQixDQUFmLEVBQWtCZ0IsTUFBOUIsRUFBc0N2QixLQUF0QyxFQUE2Q0MsT0FBN0MsRUFBc0RLLElBQXRELEVBQTRERixHQUE1RDtBQUNELFdBRk0sTUFFQTtBQUNMLGlCQUFLZCxTQUFMLENBQWVpQixDQUFmLEVBQWtCaUIsT0FBbEIsQ0FBMEJ4QixLQUExQixFQUFpQ0MsT0FBakMsRUFBMENLLElBQTFDLEVBQWdERixHQUFoRDtBQUNEO0FBQ0Y7QUFDRjtBQUNGOztBQUVELFdBQU8sSUFBSTVCLGFBQUosQ0FBa0I7QUFDdkJ3QixhQUFPQSxLQURnQjtBQUV2QnlCLGFBQU96QixLQUZnQjtBQUd2QjBCLGNBQVF6QixPQUhlO0FBSXZCMEIsaUJBQVczQixLQUpZO0FBS3ZCQyxlQUFTQSxPQUxjO0FBTXZCMkIsZUFBU3RCLElBTmM7QUFPdkJBLFlBQU1BLElBUGlCO0FBUXZCSCxZQUFNQyxHQVJpQjtBQVN2QmpCLGNBQVFpQjtBQVRlLEtBQWxCLENBQVA7QUFXRDtBQUVEOzs7Ozs7Ozs7Ozs7Ozs7O0FBY0F5QixPQUFLckIsSUFBTCxFQUFXc0IsT0FBWCxFQUFvQjtBQUNsQi9DLFVBQU15QixJQUFOLEVBQVl1QixNQUFaO0FBQ0FoRCxVQUFNK0MsT0FBTixFQUFlO0FBQ2JyQixjQUFRdUIsT0FESztBQUVicEIsY0FBUTVCLE1BQU1pRCxRQUFOLENBQWVELE9BQWYsQ0FGSztBQUdickIsY0FBUTNCLE1BQU1pRCxRQUFOLENBQWVELE9BQWYsQ0FISztBQUliRSxjQUFRbEQsTUFBTWlELFFBQU4sQ0FBZSxDQUFDRixNQUFELENBQWY7QUFKSyxLQUFmOztBQU9BLFFBQUksQ0FBQ3RELEVBQUUwRCxPQUFGLENBQVVMLFFBQVFJLE1BQWxCLENBQUQsSUFBOEJ6RCxFQUFFMkQsT0FBRixDQUFVTixRQUFRSSxNQUFsQixDQUFsQyxFQUE2RDtBQUMzREosY0FBUUksTUFBUixHQUFpQixDQUFDLEdBQUQsQ0FBakI7QUFDRDs7QUFFRCxRQUFJSixRQUFRSSxNQUFaLEVBQW9CO0FBQ2xCLFdBQUssSUFBSUcsSUFBSSxDQUFiLEVBQWdCQSxJQUFJUCxRQUFRSSxNQUFSLENBQWVJLE1BQW5DLEVBQTJDRCxHQUEzQyxFQUFnRDtBQUM5Q1AsZ0JBQVFJLE1BQVIsQ0FBZUcsQ0FBZixJQUFvQlAsUUFBUUksTUFBUixDQUFlRyxDQUFmLEVBQWtCRSxXQUFsQixFQUFwQjtBQUNEO0FBQ0Y7O0FBRUQsUUFBSSxDQUFDOUQsRUFBRStELFNBQUYsQ0FBWVYsUUFBUWxCLE1BQXBCLENBQUwsRUFBa0M7QUFDaENrQixjQUFRbEIsTUFBUixHQUFpQixLQUFqQjtBQUNEOztBQUVELFFBQUksQ0FBQ25DLEVBQUUrRCxTQUFGLENBQVlWLFFBQVFuQixNQUFwQixDQUFMLEVBQWtDO0FBQ2hDbUIsY0FBUW5CLE1BQVIsR0FBaUIsSUFBakI7QUFDRDs7QUFFRCxRQUFJLENBQUNsQyxFQUFFK0QsU0FBRixDQUFZVixRQUFRckIsTUFBcEIsQ0FBTCxFQUFrQztBQUNoQ3FCLGNBQVFyQixNQUFSLEdBQWlCLElBQWpCO0FBQ0Q7O0FBRUQsU0FBS3BCLE1BQUwsQ0FBWW1CLElBQVosSUFBb0I7QUFDbEJLLGFBQU9pQixRQUFRSSxNQURHO0FBRWxCekIsY0FBUXFCLFFBQVFyQixNQUZFO0FBR2xCRyxjQUFRa0IsUUFBUWxCLE1BSEU7QUFJbEJELGNBQVFtQixRQUFRbkI7QUFKRSxLQUFwQjtBQU1EO0FBRUQ7Ozs7Ozs7Ozs7OztBQVVBOEIsTUFBSWpDLElBQUosRUFBVWdCLE9BQVYsRUFBbUJrQixJQUFuQixFQUF5QnRCLGFBQWEsS0FBdEMsRUFBNkNDLGFBQWEsS0FBMUQsRUFBaUU7QUFDL0QsUUFBSXhDLE9BQU82QixRQUFQLElBQW1CVyxVQUFuQixJQUFpQ3hDLE9BQU9VLFFBQVAsSUFBbUI2QixVQUF4RCxFQUFvRTtBQUNsRTtBQUNEOztBQUVELFFBQUlzQixRQUFRakUsRUFBRWtFLFVBQUYsQ0FBYUQsSUFBYixDQUFaLEVBQWdDO0FBQzlCQTtBQUNEOztBQUVELFNBQUtwRCxTQUFMLENBQWVzRCxJQUFmLENBQW9CO0FBQ2xCcEMsWUFBTUEsSUFEWTtBQUVsQmdCLGVBQVNBLE9BRlM7QUFHbEJELGNBQVMsR0FBRSxLQUFLbkMsTUFBTyxnQkFBZW9CLElBQUssRUFIekI7QUFJbEJZLGtCQUFZQSxVQUpNO0FBS2xCQyxrQkFBWUE7QUFMTSxLQUFwQjs7QUFRQSxRQUFJeEMsT0FBTzZCLFFBQVgsRUFBcUI7QUFDbkIsWUFBTWEsU0FBUyxFQUFmOztBQUNBQSxhQUFRLEdBQUUsS0FBS25DLE1BQU8sZ0JBQWVvQixJQUFLLEVBQTFDLElBQStDLFVBQVVSLEtBQVYsRUFBaUJDLE9BQWpCLEVBQTBCSyxJQUExQixFQUFnQ25CLE1BQWhDLEVBQXdDO0FBQ3JGSixjQUFNaUIsS0FBTixFQUFhK0IsTUFBYjtBQUNBaEQsY0FBTWtCLE9BQU4sRUFBZWpCLE1BQU1pRCxRQUFOLENBQWVqRCxNQUFNNkQsS0FBTixDQUFZQyxNQUFaLEVBQW9CZixNQUFwQixFQUE0QixJQUE1QixDQUFmLENBQWY7QUFDQWhELGNBQU11QixJQUFOLEVBQVl0QixNQUFNaUQsUUFBTixDQUFlakQsTUFBTTZELEtBQU4sQ0FBWWQsTUFBWixFQUFvQmdCLE1BQXBCLEVBQTRCLElBQTVCLENBQWYsQ0FBWjtBQUNBaEUsY0FBTUksTUFBTixFQUFjSCxNQUFNaUQsUUFBTixDQUFlakQsTUFBTTZELEtBQU4sQ0FBWWQsTUFBWixFQUFvQmUsTUFBcEIsRUFBNEIsSUFBNUIsQ0FBZixDQUFkO0FBQ0F0QixnQkFBUXhCLEtBQVIsRUFBZUMsT0FBZixFQUF3QkssSUFBeEIsRUFBK0JuQixVQUFVLEtBQUtBLE1BQTlDO0FBQ0QsT0FORDs7QUFPQU4sYUFBT21FLE9BQVAsQ0FBZXpCLE1BQWY7QUFDRDtBQUNGO0FBRUQ7Ozs7Ozs7Ozs7QUFRQTBCLE9BQUtoRCxPQUFMLEVBQWNLLElBQWQsRUFBb0JuQixNQUFwQixFQUE0QjtBQUMxQixXQUFPLEtBQUtZLElBQUwsQ0FBVSxNQUFWLEVBQWtCRSxPQUFsQixFQUEyQkssSUFBM0IsRUFBaUNuQixNQUFqQyxDQUFQO0FBQ0Q7O0FBQ0QrRCxRQUFNakQsT0FBTixFQUFlSyxJQUFmLEVBQXFCbkIsTUFBckIsRUFBNkI7QUFDM0IsV0FBTyxLQUFLWSxJQUFMLENBQVUsT0FBVixFQUFtQkUsT0FBbkIsRUFBNEJLLElBQTVCLEVBQWtDbkIsTUFBbEMsQ0FBUDtBQUNEOztBQUNEc0MsUUFBTXhCLE9BQU4sRUFBZUssSUFBZixFQUFxQm5CLE1BQXJCLEVBQTZCO0FBQzNCLFdBQU8sS0FBS1ksSUFBTCxDQUFVLE9BQVYsRUFBbUJFLE9BQW5CLEVBQTRCSyxJQUE1QixFQUFrQ25CLE1BQWxDLENBQVA7QUFDRDs7QUFDRGdFLFFBQU1sRCxPQUFOLEVBQWVLLElBQWYsRUFBcUJuQixNQUFyQixFQUE2QjtBQUMzQixXQUFPLEtBQUtZLElBQUwsQ0FBVSxPQUFWLEVBQW1CRSxPQUFuQixFQUE0QkssSUFBNUIsRUFBa0NuQixNQUFsQyxDQUFQO0FBQ0Q7O0FBQ0RpRSxPQUFLbkQsT0FBTCxFQUFjSyxJQUFkLEVBQW9CbkIsTUFBcEIsRUFBNEI7QUFDMUIsV0FBTyxLQUFLWSxJQUFMLENBQVUsTUFBVixFQUFrQkUsT0FBbEIsRUFBMkJLLElBQTNCLEVBQWlDbkIsTUFBakMsQ0FBUDtBQUNEOztBQUNEa0UsUUFBTXBELE9BQU4sRUFBZUssSUFBZixFQUFxQm5CLE1BQXJCLEVBQTZCO0FBQzNCLFdBQU8sS0FBS1ksSUFBTCxDQUFVLE9BQVYsRUFBbUJFLE9BQW5CLEVBQTRCSyxJQUE1QixFQUFrQ25CLE1BQWxDLENBQVA7QUFDRDs7QUFDRG1FLE1BQUlyRCxPQUFKLEVBQWFLLElBQWIsRUFBbUJuQixNQUFuQixFQUEyQjtBQUN6QixXQUFPLEtBQUtZLElBQUwsQ0FBVSxLQUFWLEVBQWlCRSxPQUFqQixFQUEwQkssSUFBMUIsRUFBZ0NuQixNQUFoQyxDQUFQO0FBQ0Q7O0FBQ0RWLElBQUV3QixPQUFGLEVBQVdLLElBQVgsRUFBaUJuQixNQUFqQixFQUF5QjtBQUN2QixXQUFPLEtBQUtZLElBQUwsQ0FBVSxLQUFWLEVBQWlCRSxPQUFqQixFQUEwQkssSUFBMUIsRUFBZ0NuQixNQUFoQyxDQUFQO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBb0UsZUFBYUMsR0FBYixFQUFrQjtBQUNoQixVQUFNQyxTQUFTLEVBQWY7O0FBQ0EsVUFBTUMsUUFBU0MsQ0FBRCxJQUFPO0FBQ25CLFdBQUssSUFBSS9FLENBQVQsSUFBYytFLENBQWQsRUFBaUI7QUFDZixZQUFJL0UsTUFBTSxJQUFOLElBQWMsT0FBT0EsQ0FBUCxLQUFhLFFBQS9CLEVBQXlDO0FBQ3ZDLGNBQUk2RSxPQUFPM0MsT0FBUCxDQUFlbEMsQ0FBZixNQUFzQixDQUFDLENBQTNCLEVBQThCO0FBQzVCK0UsY0FBRUEsRUFBRS9FLENBQUYsQ0FBRixJQUFVLFlBQVY7QUFDQTtBQUNEOztBQUNENkUsaUJBQU9iLElBQVAsQ0FBWWhFLENBQVo7O0FBQ0E4RSxnQkFBTTlFLENBQU47O0FBQ0E7QUFDRDtBQUNGO0FBQ0YsS0FaRDs7QUFjQThFLFVBQU1GLEdBQU47O0FBQ0EsV0FBT0EsR0FBUDtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQXJDLG1CQUFpQjtBQUNmLFFBQUlxQyxNQUFNLEVBQVY7O0FBQ0EsUUFBSS9FLEVBQUVrRSxVQUFGLENBQWFpQixNQUFNQyxpQkFBbkIsQ0FBSixFQUEyQztBQUN6Q0QsWUFBTUMsaUJBQU4sQ0FBd0JMLEdBQXhCLEVBQTZCLEtBQUtyQyxjQUFsQztBQUNELEtBRkQsTUFFTztBQUNMLFlBQU0yQyxNQUFNLElBQUlGLEtBQUosRUFBWjs7QUFDQSxVQUFJRSxJQUFJQyxLQUFSLEVBQWU7QUFDYlAsWUFBSU8sS0FBSixHQUFZRCxJQUFJQyxLQUFoQjtBQUNELE9BRkQsTUFFTztBQUNMUCxZQUFJTyxLQUFKLEdBQVksZ0NBQVo7QUFDRDtBQUNGOztBQUVELFVBQU1DLE1BQU1SLElBQUlPLEtBQUosQ0FBVWpELE9BQVYsQ0FBa0IsZ0JBQWxCLENBQVo7QUFDQSxVQUFNbUQsT0FBT1QsSUFBSU8sS0FBSixDQUFVakQsT0FBVixDQUFrQixNQUFsQixDQUFiOztBQUNBLFFBQUlrRCxPQUFPLENBQVgsRUFBYztBQUNaUixVQUFJTyxLQUFKLEdBQVlQLElBQUlPLEtBQUosQ0FBVUcsU0FBVixDQUFvQlYsSUFBSU8sS0FBSixDQUFVakQsT0FBVixDQUFrQixJQUFsQixFQUF3QmtELE1BQU0sQ0FBOUIsSUFBbUMsQ0FBdkQsQ0FBWjtBQUNEOztBQUNELFFBQUlDLFFBQVEsQ0FBWixFQUFlO0FBQ2JULFVBQUlPLEtBQUosR0FBWVAsSUFBSU8sS0FBSixDQUFVRyxTQUFWLENBQW9CVixJQUFJTyxLQUFKLENBQVVqRCxPQUFWLENBQWtCLElBQWxCLEVBQXdCbUQsT0FBTyxDQUEvQixJQUFvQyxDQUF4RCxDQUFaO0FBQ0Q7O0FBRUQsV0FBT1QsSUFBSU8sS0FBWDtBQUNEOztBQWpRVTtBQW9RYjs7Ozs7OztBQUtBLE1BQU12RixhQUFOLENBQW9CO0FBQ2xCVSxjQUFZb0IsSUFBWixFQUFrQjtBQUNoQixTQUFLQSxJQUFMLEdBQWVBLEtBQUtBLElBQXBCO0FBQ0EsU0FBS0gsSUFBTCxHQUFlRyxLQUFLSCxJQUFwQjtBQUNBLFNBQUtILEtBQUwsR0FBZU0sS0FBS04sS0FBcEI7QUFDQSxTQUFLeUIsS0FBTCxHQUFlbkIsS0FBS21CLEtBQXBCO0FBQ0EsU0FBS3RDLE1BQUwsR0FBZW1CLEtBQUtuQixNQUFwQjtBQUNBLFNBQUt1QyxNQUFMLEdBQWVwQixLQUFLb0IsTUFBcEI7QUFDQSxTQUFLRSxPQUFMLEdBQWV0QixLQUFLc0IsT0FBcEI7QUFDQSxTQUFLM0IsT0FBTCxHQUFlSyxLQUFLTCxPQUFwQjs7QUFFQSxTQUFLa0UsUUFBTCxHQUFnQixNQUFNO0FBQ3BCLGFBQVEsSUFBRyxLQUFLekMsTUFBTyxjQUFhLEtBQUsxQixLQUFNLGdCQUFlb0UsS0FBS0MsU0FBTCxDQUFlOUYsT0FBTytGLFNBQVAsQ0FBaUJmLFlBQWpCLENBQThCLEtBQUtqRCxJQUFuQyxDQUFmLENBQXlELGVBQWMsS0FBS25CLE1BQU8sR0FBako7QUFDRCxLQUZEO0FBR0Q7O0FBZGlCLEMiLCJmaWxlIjoiL3BhY2thZ2VzL29zdHJpb19sb2dnZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfIH0gICAgICAgICAgICBmcm9tICdtZXRlb3IvdW5kZXJzY29yZSc7XG5pbXBvcnQgeyBNZXRlb3IgfSAgICAgICBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFJlYWN0aXZlVmFyIH0gIGZyb20gJ21ldGVvci9yZWFjdGl2ZS12YXInO1xuaW1wb3J0IHsgY2hlY2ssIE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcblxubGV0IF9pbnN0ID0gMDtcblxuLypcbiAqIEBjbGFzcyBMb2dnZXJcbiAqIEBzdW1tYXJ5IEV4dGVuZC1hYmxlIExvZ2dlciBjbGFzc1xuICovXG5jbGFzcyBMb2dnZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnVzZXJJZCAgICA9IG5ldyBSZWFjdGl2ZVZhcihudWxsKTtcbiAgICB0aGlzLnByZWZpeCAgICA9ICsrX2luc3Q7XG4gICAgdGhpcy5fcnVsZXMgICAgPSB7fTtcbiAgICB0aGlzLl9lbWl0dGVycyA9IFtdO1xuXG4gICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgY29uc3QgX2FjY291bnRzID0gKFBhY2thZ2UgJiYgUGFja2FnZVsnYWNjb3VudHMtYmFzZSddICYmIFBhY2thZ2VbJ2FjY291bnRzLWJhc2UnXS5BY2NvdW50cykgPyBQYWNrYWdlWydhY2NvdW50cy1iYXNlJ10uQWNjb3VudHMgOiB1bmRlZmluZWQ7XG4gICAgICBpZiAoX2FjY291bnRzKSB7XG4gICAgICAgIF9hY2NvdW50cy5vbkxvZ2luKCgpID0+IHtcbiAgICAgICAgICB0aGlzLnVzZXJJZC5zZXQoTWV0ZW9yLnVzZXJJZCgpKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgX2FjY291bnRzLm9uTG9nb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLnVzZXJJZC5zZXQobnVsbCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBtZW1iZXJPZiBMb2dnZXJcbiAgICogQG5hbWUgX2xvZ1xuICAgKiBAcGFyYW0gbGV2ZWwgICAge1N0cmluZ30gLSBMb2cgbGV2ZWwgQWNjZXB0cyAnRVJST1InLCAnRkFUQUwnLCAnV0FSTicsICdERUJVRycsICdJTkZPJywgJ1RSQUNFJywgJ0xPRycgYW5kICcqJ1xuICAgKiBAcGFyYW0gbWVzc2FnZSAge1N0cmluZ30gLSBUZXh0IGh1bWFuLXJlYWRhYmxlIG1lc3NhZ2VcbiAgICogQHBhcmFtIGRhdGEgICAgIHtPYmplY3R9IC0gW29wdGlvbmFsXSBBbnkgYWRkaXRpb25hbCBpbmZvIGFzIG9iamVjdFxuICAgKiBAcGFyYW0gdXNlcklkICAge1N0cmluZ30gLSBbb3B0aW9uYWxdIEN1cnJlbnQgdXNlciBpZFxuICAgKiBAc3VtbWFyeSBQYXNzIGxvZydzIGRhdGEgdG8gU2VydmVyIG9yL2FuZCBDbGllbnRcbiAgICovXG4gIF9sb2cobGV2ZWwsIG1lc3NhZ2UsIF9kYXRhID0ge30sIHVzZXIpIHtcbiAgICBjb25zdCB1aWQgPSB1c2VyIHx8IHRoaXMudXNlcklkLmdldCgpO1xuICAgIGxldCBkYXRhID0gX2RhdGE7XG5cbiAgICBmb3IgKGxldCBpIGluIHRoaXMuX2VtaXR0ZXJzKSB7XG4gICAgICBpZiAodGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0gJiYgdGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0uZW5hYmxlID09PSB0cnVlKSB7XG4gICAgICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIgJiYgdGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0uc2VydmVyID09PSBmYWxzZSB8fCBNZXRlb3IuaXNDbGllbnQgJiYgdGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0uY2xpZW50ID09PSBmYWxzZSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRoaXMuX3J1bGVzW3RoaXMuX2VtaXR0ZXJzW2ldLm5hbWVdLmFsbG93LmluZGV4T2YoJyonKSAhPT0gLTEgfHwgdGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0uYWxsb3cuaW5kZXhPZihsZXZlbCkgIT09IC0xKSB7XG4gICAgICAgICAgaWYgKGxldmVsID09PSAnVFJBQ0UnKSB7XG4gICAgICAgICAgICBpZiAoXy5pc1N0cmluZyhkYXRhKSkge1xuICAgICAgICAgICAgICBsZXQgX19kYXRhID0gXy5jbG9uZShkYXRhKTtcbiAgICAgICAgICAgICAgZGF0YSA9IHtkYXRhOiBfX2RhdGF9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGF0YS5zdGFja1RyYWNlID0gdGhpcy5fZ2V0U3RhY2tUcmFjZSgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgdGhpcy5fZW1pdHRlcnNbaV0uZGVueUNsaWVudCA9PT0gdHJ1ZSAmJiB0aGlzLl9lbWl0dGVyc1tpXS5kZW55U2VydmVyID09PSBmYWxzZSkge1xuICAgICAgICAgICAgTWV0ZW9yLmNhbGwodGhpcy5fZW1pdHRlcnNbaV0ubWV0aG9kLCBsZXZlbCwgbWVzc2FnZSwgZGF0YSwgdWlkKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuX3J1bGVzW3RoaXMuX2VtaXR0ZXJzW2ldLm5hbWVdLmNsaWVudCA9PT0gdHJ1ZSAmJiB0aGlzLl9ydWxlc1t0aGlzLl9lbWl0dGVyc1tpXS5uYW1lXS5zZXJ2ZXIgPT09IHRydWUgJiYgdGhpcy5fZW1pdHRlcnNbaV0uZGVueUNsaWVudCA9PT0gZmFsc2UgJiYgdGhpcy5fZW1pdHRlcnNbaV0uZGVueVNlcnZlciA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHRoaXMuX2VtaXR0ZXJzW2ldLmVtaXR0ZXIobGV2ZWwsIG1lc3NhZ2UsIGRhdGEsIHVpZCk7XG4gICAgICAgICAgICBpZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gICAgICAgICAgICAgIE1ldGVvci5jYWxsKHRoaXMuX2VtaXR0ZXJzW2ldLm1ldGhvZCwgbGV2ZWwsIG1lc3NhZ2UsIGRhdGEsIHVpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChNZXRlb3IuaXNDbGllbnQgJiYgdGhpcy5fcnVsZXNbdGhpcy5fZW1pdHRlcnNbaV0ubmFtZV0uY2xpZW50ID09PSBmYWxzZSAmJiB0aGlzLl9ydWxlc1t0aGlzLl9lbWl0dGVyc1tpXS5uYW1lXS5zZXJ2ZXIgPT09IHRydWUpIHtcbiAgICAgICAgICAgIE1ldGVvci5jYWxsKHRoaXMuX2VtaXR0ZXJzW2ldLm1ldGhvZCwgbGV2ZWwsIG1lc3NhZ2UsIGRhdGEsIHVpZCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX2VtaXR0ZXJzW2ldLmVtaXR0ZXIobGV2ZWwsIG1lc3NhZ2UsIGRhdGEsIHVpZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBMb2dnZXJNZXNzYWdlKHtcbiAgICAgIGxldmVsOiBsZXZlbCxcbiAgICAgIGVycm9yOiBsZXZlbCxcbiAgICAgIHJlYXNvbjogbWVzc2FnZSxcbiAgICAgIGVycm9yVHlwZTogbGV2ZWwsXG4gICAgICBtZXNzYWdlOiBtZXNzYWdlLFxuICAgICAgZGV0YWlsczogZGF0YSxcbiAgICAgIGRhdGE6IGRhdGEsXG4gICAgICB1c2VyOiB1aWQsXG4gICAgICB1c2VySWQ6IHVpZFxuICAgIH0pO1xuICB9XG5cbiAgLypcbiAgICogQG1lbWJlck9mIExvZ2dlclxuICAgKiBAbmFtZSBydWxlXG4gICAqIEBwYXJhbSBuYW1lICAgIHtTdHJpbmd9IC0gQWRhcHRlciBuYW1lXG4gICAqIEBwYXJhbSBvcHRpb25zIHtPYmplY3R9IC0gU2V0dGluZ3Mgb2JqZWN0XG4gICAgICAgICBvcHRpb25zLmVuYWJsZSB7Qm9vbGVhbn0gLSBFbmFibGUvZGlzYWJsZSBhZGFwdGVyXG4gICAgICAgICBvcHRpb25zLmZpbHRlciB7QXJyYXl9ICAgLSBBcnJheSBvZiBzdHJpbmdzLCBhY2NlcHRzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnRVJST1InLCAnRkFUQUwnLCAnV0FSTicsICdERUJVRycsICdJTkZPJywgJ1RSQUNFJywgJ0xPRycgYW5kICcqJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbiBsb3dlcmNhc2Ugb3IgdXBwZXJjYXNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6IFsnKiddIC0gQWNjZXB0IGFsbFxuICAgICAgICAgb3B0aW9ucy5jbGllbnQge0Jvb2xlYW59IC0gQWxsb3cgZXhlY3V0aW9uIG9uIENsaWVudFxuICAgICAgICAgb3B0aW9ucy5zZXJ2ZXIge0Jvb2xlYW59IC0gQWxsb3cgZXhlY3V0aW9uIG9uIFNlcnZlclxuICAgKiBAc3VtbWFyeSBFbmFibGUvZGlzYWJsZSBhZGFwdGVyIGFuZCBzZXQgaXQncyBzZXR0aW5nc1xuICAgKi9cbiAgcnVsZShuYW1lLCBvcHRpb25zKSB7XG4gICAgY2hlY2sobmFtZSwgU3RyaW5nKTtcbiAgICBjaGVjayhvcHRpb25zLCB7XG4gICAgICBlbmFibGU6IEJvb2xlYW4sXG4gICAgICBjbGllbnQ6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgICAgc2VydmVyOiBNYXRjaC5PcHRpb25hbChCb29sZWFuKSxcbiAgICAgIGZpbHRlcjogTWF0Y2guT3B0aW9uYWwoW1N0cmluZ10pXG4gICAgfSk7XG5cbiAgICBpZiAoIV8uaXNBcnJheShvcHRpb25zLmZpbHRlcikgfHwgXy5pc0VtcHR5KG9wdGlvbnMuZmlsdGVyKSkge1xuICAgICAgb3B0aW9ucy5maWx0ZXIgPSBbJyonXTtcbiAgICB9XG5cbiAgICBpZiAob3B0aW9ucy5maWx0ZXIpIHtcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgb3B0aW9ucy5maWx0ZXIubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgb3B0aW9ucy5maWx0ZXJbal0gPSBvcHRpb25zLmZpbHRlcltqXS50b1VwcGVyQ2FzZSgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICghXy5pc0Jvb2xlYW4ob3B0aW9ucy5jbGllbnQpKSB7XG4gICAgICBvcHRpb25zLmNsaWVudCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghXy5pc0Jvb2xlYW4ob3B0aW9ucy5zZXJ2ZXIpKSB7XG4gICAgICBvcHRpb25zLnNlcnZlciA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKCFfLmlzQm9vbGVhbihvcHRpb25zLmVuYWJsZSkpIHtcbiAgICAgIG9wdGlvbnMuZW5hYmxlID0gdHJ1ZTtcbiAgICB9XG5cbiAgICB0aGlzLl9ydWxlc1tuYW1lXSA9IHtcbiAgICAgIGFsbG93OiBvcHRpb25zLmZpbHRlcixcbiAgICAgIGVuYWJsZTogb3B0aW9ucy5lbmFibGUsXG4gICAgICBjbGllbnQ6IG9wdGlvbnMuY2xpZW50LFxuICAgICAgc2VydmVyOiBvcHRpb25zLnNlcnZlclxuICAgIH07XG4gIH1cblxuICAvKlxuICAgKiBAbWVtYmVyT2YgTG9nZ2VyXG4gICAqIEBuYW1lIGFkZFxuICAgKiBAcGFyYW0gbmFtZSAgICAgICAge1N0cmluZ30gICAgLSBBZGFwdGVyIG5hbWVcbiAgICogQHBhcmFtIGVtaXR0ZXIgICAgIHtGdW5jdGlvbn0gIC0gRnVuY3Rpb24gY2FsbGVkIG9uIE1ldGVvci5sb2cuLi5cbiAgICogQHBhcmFtIGluaXQgICAgICAgIHtGdW5jdGlvbn0gIC0gQWRhcHRlciBpbml0aWFsaXphdGlvbiBmdW5jdGlvblxuICAgKiBAcGFyYW0gZGVueUNsaWVudCAge0Jvb2xlYW59ICAgLSBTdHJpY3RseSBkZW55IGV4ZWN1dGlvbiBvbiBjbGllbnQsIG9ubHkgcGFzcyB2aWEgTWV0ZW9yLm1ldGhvZHNcbiAgICogQHBhcmFtIGRlbnlTZXJ2ZXIgIHtCb29sZWFufSAgIC0gU3RyaWN0bHkgZGVueSBleGVjdXRpb24gb24gc2VydmVyLCBvbmx5IGNsaWVudFxuICAgKiBAc3VtbWFyeSBSZWdpc3RlciBuZXcgYWRhcHRlciB0byBiZSB1c2VkIHdpdGhpbiBvc3RyaW86bG9nZ2VyIHBhY2thZ2VcbiAgICovXG4gIGFkZChuYW1lLCBlbWl0dGVyLCBpbml0LCBkZW55Q2xpZW50ID0gZmFsc2UsIGRlbnlTZXJ2ZXIgPSBmYWxzZSkge1xuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIgJiYgZGVueVNlcnZlciB8fCBNZXRlb3IuaXNDbGllbnQgJiYgZGVueUNsaWVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChpbml0ICYmIF8uaXNGdW5jdGlvbihpbml0KSkge1xuICAgICAgaW5pdCgpO1xuICAgIH1cblxuICAgIHRoaXMuX2VtaXR0ZXJzLnB1c2goe1xuICAgICAgbmFtZTogbmFtZSxcbiAgICAgIGVtaXR0ZXI6IGVtaXR0ZXIsXG4gICAgICBtZXRob2Q6IGAke3RoaXMucHJlZml4fV9sb2dnZXJfZW1pdF8ke25hbWV9YCxcbiAgICAgIGRlbnlDbGllbnQ6IGRlbnlDbGllbnQsXG4gICAgICBkZW55U2VydmVyOiBkZW55U2VydmVyXG4gICAgfSk7XG5cbiAgICBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4gICAgICBjb25zdCBtZXRob2QgPSB7fTtcbiAgICAgIG1ldGhvZFtgJHt0aGlzLnByZWZpeH1fbG9nZ2VyX2VtaXRfJHtuYW1lfWBdID0gZnVuY3Rpb24gKGxldmVsLCBtZXNzYWdlLCBkYXRhLCB1c2VySWQpIHtcbiAgICAgICAgY2hlY2sobGV2ZWwsIFN0cmluZyk7XG4gICAgICAgIGNoZWNrKG1lc3NhZ2UsIE1hdGNoLk9wdGlvbmFsKE1hdGNoLk9uZU9mKE51bWJlciwgU3RyaW5nLCBudWxsKSkpO1xuICAgICAgICBjaGVjayhkYXRhLCBNYXRjaC5PcHRpb25hbChNYXRjaC5PbmVPZihTdHJpbmcsIE9iamVjdCwgbnVsbCkpKTtcbiAgICAgICAgY2hlY2sodXNlcklkLCBNYXRjaC5PcHRpb25hbChNYXRjaC5PbmVPZihTdHJpbmcsIE51bWJlciwgbnVsbCkpKTtcbiAgICAgICAgZW1pdHRlcihsZXZlbCwgbWVzc2FnZSwgZGF0YSwgKHVzZXJJZCB8fCB0aGlzLnVzZXJJZCkpO1xuICAgICAgfTtcbiAgICAgIE1ldGVvci5tZXRob2RzKG1ldGhvZCk7XG4gICAgfVxuICB9XG5cbiAgLypcbiAgICogQG1lbWJlck9mIExvZ2dlclxuICAgKiBAbmFtZSBpbmZvOyBkZWJ1ZzsgZXJyb3I7IGZhdGFsOyB3YXJuOyB0cmFjZTsgbG9nOyBfXG4gICAqIEBwYXJhbSBtZXNzYWdlIHtTdHJpbmd9IC0gQW55IHRleHQgbWVzc2FnZVxuICAgKiBAcGFyYW0gZGF0YSAgICB7T2JqZWN0fSAtIFtvcHRpb25hbF0gQW55IGFkZGl0aW9uYWwgaW5mbyBhcyBvYmplY3RcbiAgICogQHBhcmFtIHVzZXJJZCAge1N0cmluZ30gLSBbb3B0aW9uYWxdIEN1cnJlbnQgdXNlciBpZFxuICAgKiBAc3VtbWFyeSBNZXRob2RzIGJlbG93IGlzIHNob3J0Y3V0cyBmb3IgX2xvZygpIG1ldGhvZFxuICAgKi9cbiAgaW5mbyhtZXNzYWdlLCBkYXRhLCB1c2VySWQpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nKCdJTkZPJywgbWVzc2FnZSwgZGF0YSwgdXNlcklkKTtcbiAgfVxuICBkZWJ1ZyhtZXNzYWdlLCBkYXRhLCB1c2VySWQpIHtcbiAgICByZXR1cm4gdGhpcy5fbG9nKCdERUJVRycsIG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCk7XG4gIH1cbiAgZXJyb3IobWVzc2FnZSwgZGF0YSwgdXNlcklkKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZygnRVJST1InLCBtZXNzYWdlLCBkYXRhLCB1c2VySWQpO1xuICB9XG4gIGZhdGFsKG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCkge1xuICAgIHJldHVybiB0aGlzLl9sb2coJ0ZBVEFMJywgbWVzc2FnZSwgZGF0YSwgdXNlcklkKTtcbiAgfVxuICB3YXJuKG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCkge1xuICAgIHJldHVybiB0aGlzLl9sb2coJ1dBUk4nLCBtZXNzYWdlLCBkYXRhLCB1c2VySWQpO1xuICB9XG4gIHRyYWNlKG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCkge1xuICAgIHJldHVybiB0aGlzLl9sb2coJ1RSQUNFJywgbWVzc2FnZSwgZGF0YSwgdXNlcklkKTtcbiAgfVxuICBsb2cobWVzc2FnZSwgZGF0YSwgdXNlcklkKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvZygnTE9HJywgbWVzc2FnZSwgZGF0YSwgdXNlcklkKTtcbiAgfVxuICBfKG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCkge1xuICAgIHJldHVybiB0aGlzLl9sb2coJ0xPRycsIG1lc3NhZ2UsIGRhdGEsIHVzZXJJZCk7XG4gIH1cblxuICAvKlxuICAgKiBAbWVtYmVyT2YgTG9nZ2VyXG4gICAqIEBuYW1lIGFudGlDaXJjdWxhclxuICAgKiBAcGFyYW0gZGF0YSB7T2JqZWN0fSAtIENpcmN1bGFyIG9yIGFueSBvdGhlciBvYmplY3Qgd2hpY2ggbmVlZHMgdG8gYmUgbm9uLWNpcmN1bGFyXG4gICAqL1xuICBhbnRpQ2lyY3VsYXIob2JqKSB7XG4gICAgY29uc3QgX2NhY2hlID0gW107XG4gICAgY29uc3QgX3dyYXAgPSAobykgPT4ge1xuICAgICAgZm9yIChsZXQgdiBpbiBvKSB7XG4gICAgICAgIGlmICh2ICE9PSBudWxsICYmIHR5cGVvZiB2ID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIGlmIChfY2FjaGUuaW5kZXhPZih2KSAhPT0gLTEpIHtcbiAgICAgICAgICAgIG9bb1t2XV0gPSAnW0NpcmN1bGFyXSc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgX2NhY2hlLnB1c2godik7XG4gICAgICAgICAgX3dyYXAodik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuXG4gICAgX3dyYXAob2JqKTtcbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgLypcbiAgICogQG1lbWJlck9mIExvZ2dlclxuICAgKiBAbmFtZSBfZ2V0U3RhY2tUcmFjZVxuICAgKiBAc3VtbWFyeSBQcmVwYXJlIHN0YWNrIHRyYWNlIG1lc3NhZ2VcbiAgICovXG4gIF9nZXRTdGFja1RyYWNlKCkge1xuICAgIGxldCBvYmogPSB7fTtcbiAgICBpZiAoXy5pc0Z1bmN0aW9uKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSkge1xuICAgICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2Uob2JqLCB0aGlzLl9nZXRTdGFja1RyYWNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCk7XG4gICAgICBpZiAoZXJyLnN0YWNrKSB7XG4gICAgICAgIG9iai5zdGFjayA9IGVyci5zdGFjaztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9iai5zdGFjayA9ICdOb3QgYXZhaWxhYmxlIG9mIG5vdCBzdXBwb3J0ZWQnO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IGlkeCA9IG9iai5zdGFjay5pbmRleE9mKCdfZ2V0U3RhY2tUcmFjZScpO1xuICAgIGNvbnN0IGlkeDIgPSBvYmouc3RhY2suaW5kZXhPZignX2xvZycpO1xuICAgIGlmIChpZHggPj0gMCkge1xuICAgICAgb2JqLnN0YWNrID0gb2JqLnN0YWNrLnN1YnN0cmluZyhvYmouc3RhY2suaW5kZXhPZignXFxuJywgaWR4ICsgMSkgKyAxKTtcbiAgICB9XG4gICAgaWYgKGlkeDIgPj0gMCkge1xuICAgICAgb2JqLnN0YWNrID0gb2JqLnN0YWNrLnN1YnN0cmluZyhvYmouc3RhY2suaW5kZXhPZignXFxuJywgaWR4MiArIDEpICsgMSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG9iai5zdGFjaztcbiAgfVxufVxuXG4vKlxuICogQGNsYXNzIExvZ2dlck1lc3NhZ2VcbiAqIEBwYXJhbSBkYXRhIHtPYmplY3R9XG4gKiBAc3VtbWFyeSBDb25zdHJ1Y3QgbWVzc2FnZSBvYmplY3QsIHJlYWR5IHRvIGJlIHRocm93biBhbmQgc3RyaW5naWZpZWRcbiAqL1xuY2xhc3MgTG9nZ2VyTWVzc2FnZSB7XG4gIGNvbnN0cnVjdG9yKGRhdGEpIHtcbiAgICB0aGlzLmRhdGEgICAgPSBkYXRhLmRhdGE7XG4gICAgdGhpcy51c2VyICAgID0gZGF0YS51c2VyO1xuICAgIHRoaXMubGV2ZWwgICA9IGRhdGEubGV2ZWw7XG4gICAgdGhpcy5lcnJvciAgID0gZGF0YS5lcnJvcjtcbiAgICB0aGlzLnVzZXJJZCAgPSBkYXRhLnVzZXJJZDtcbiAgICB0aGlzLnJlYXNvbiAgPSBkYXRhLnJlYXNvbjtcbiAgICB0aGlzLmRldGFpbHMgPSBkYXRhLmRldGFpbHM7XG4gICAgdGhpcy5tZXNzYWdlID0gZGF0YS5tZXNzYWdlO1xuXG4gICAgdGhpcy50b1N0cmluZyA9ICgpID0+IHtcbiAgICAgIHJldHVybiBgWyR7dGhpcy5yZWFzb259XSBcXG5MZXZlbDogJHt0aGlzLmxldmVsfTsgXFxuRGV0YWlsczogJHtKU09OLnN0cmluZ2lmeShMb2dnZXIucHJvdG90eXBlLmFudGlDaXJjdWxhcih0aGlzLmRhdGEpKX07IFxcblVzZXJJZDogJHt0aGlzLnVzZXJJZH07YDtcbiAgICB9O1xuICB9XG59XG5cbmV4cG9ydCB7IExvZ2dlciwgTG9nZ2VyTWVzc2FnZSB9O1xuIl19
