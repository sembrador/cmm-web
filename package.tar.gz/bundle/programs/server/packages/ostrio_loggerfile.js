(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:loggerfile":{"server.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/ostrio_loggerfile/server.js                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  LoggerFile: () => LoggerFile
});

let _;

module.watch(require("meteor/underscore"), {
  _(v) {
    _ = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Logger;
module.watch(require("meteor/ostrio:logger"), {
  Logger(v) {
    Logger = v;
  }

}, 2);
let check, Match;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 3);
let fs;
module.watch(require("fs-extra"), {
  default(v) {
    fs = v;
  }

}, 4);

const NOOP = () => {};
/*
 * @class LoggerFile
 * @summary File (FS) adapter for ostrio:logger (Logger)
 */


class LoggerFile {
  constructor(logger, options = {}) {
    check(logger, Match.OneOf(Logger, Object));
    check(options, Match.Optional(Object));
    this.logger = logger;
    this.options = options;
    /* fileNameFormat - Log file name */

    if (this.options.fileNameFormat) {
      if (!_.isFunction(this.options.fileNameFormat)) {
        throw new Meteor.Error('[LoggerFile] [options.fileNameFormat] Must be a Function!');
      }
    } else {
      this.options.fileNameFormat = time => {
        let month = `${time.getMonth() + 1}`;

        if (month.length === 1) {
          month = '0' + month;
        }

        let date = `${time.getDate()}`;

        if (date.length === 1) {
          date = '0' + date;
        }

        let year = `${time.getFullYear()}`;

        if (year.length === 1) {
          year = '0' + year;
        }

        return `${date}-${month}-${year}.log`;
      };
    }
    /* format - Log record format */


    if (this.options.format) {
      if (!_.isFunction(this.options.format)) {
        throw new Meteor.Error('[LoggerFile] [options.format] Must be a Function!');
      }
    } else {
      this.options.format = (time, level, message, data, userId) => {
        let month = `${time.getMonth() + 1}`;

        if (month.length === 1) {
          month = '0' + month;
        }

        let date = `${time.getDate()}`;

        if (date.length === 1) {
          date = '0' + date;
        }

        let year = `${time.getFullYear()}`;

        if (year.length === 1) {
          year = '0' + year;
        }

        let hours = `${time.getHours()}`;

        if (hours.length === 1) {
          hours = '0' + hours;
        }

        let mins = `${time.getMinutes()}`;

        if (mins.length === 1) {
          mins = '0' + mins;
        }

        let sec = `${time.getSeconds()}`;

        if (sec.length === 1) {
          sec = '0' + sec;
        }

        return `${date}-${month}-${year} ${hours}:${mins}:${sec} | [${level}] | Message: \"${message}\" | User: ${userId} | data: ${data}\r\n`;
      };
    }
    /* path - Log's storage path */


    if (this.options.path) {
      if (!_.isString(this.options.path)) {
        throw new Meteor.Error('[LoggerFile] [options.path] Must be a String!');
      }
    } else {
      this.options.path = Meteor.rootPath + (process.env.NODE_ENV === 'development' ? '/static/logs' : '/assets/app/logs');
    }

    this.options.path = this.options.path.replace(/\/$/, '');
    fs.ensureDir(`${this.options.path}`, EDError => {
      if (EDError) {
        throw new Meteor.Error('[LoggerFile] [options.path] Error:', EDError);
      }

      fs.writeFile(`${this.options.path}/test`, 'test', WFError => {
        if (WFError) {
          throw new Meteor.Error(`[LoggerFile] [options.path] ${this.options.path} is not writable!!!`, WFError);
        }

        fs.unlink(`${this.options.path}/test`, NOOP);
      });
    });
    this.logger.add('File', (level, message, data = null, userId) => {
      const time = new Date();
      let _data = null;

      if (data) {
        _data = this.logger.antiCircular(_.clone(data));

        if (_.isString(_data.stackTrace)) {
          _data.stackTrace = _data.stackTrace.split(/\n|\\n|\r|\r\n/g);
        }

        _data = JSON.stringify(_data, false, 2);
      }

      fs.appendFile(`${this.options.path}/${this.options.fileNameFormat(time)}`, this.options.format(time, level, message, _data, userId), NOOP);
    }, NOOP, false, false);
  }

  enable(rule = {}) {
    check(rule, {
      enable: Match.Optional(Boolean),
      client: Match.Optional(Boolean),
      server: Match.Optional(Boolean),
      filter: Match.Optional([String])
    });

    if (rule.enable == null) {
      rule.enable = true;
    }

    if (rule.client == null) {
      rule.client = true;
    }

    if (rule.server == null) {
      rule.server = true;
    }

    this.logger.rule('File', rule);
    return this;
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"fs-extra":{"package.json":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// node_modules/meteor/ostrio_loggerfile/node_modules/fs-extra/package.json                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
exports.name = "fs-extra";
exports.version = "5.0.0";
exports.main = "./lib/index.js";

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// node_modules/meteor/ostrio_loggerfile/node_modules/fs-extra/lib/index.js                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
'use strict'

const assign = require('./util/assign')

const fs = {}

// Export graceful-fs:
assign(fs, require('./fs'))
// Export extra methods:
assign(fs, require('./copy'))
assign(fs, require('./copy-sync'))
assign(fs, require('./mkdirs'))
assign(fs, require('./remove'))
assign(fs, require('./json'))
assign(fs, require('./move'))
assign(fs, require('./move-sync'))
assign(fs, require('./empty'))
assign(fs, require('./ensure'))
assign(fs, require('./output'))
assign(fs, require('./path-exists'))

module.exports = fs

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/ostrio:loggerfile/server.js");

/* Exports */
Package._define("ostrio:loggerfile", exports);

})();

//# sourceURL=meteor://💻app/packages/ostrio_loggerfile.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmxvZ2dlcmZpbGUvc2VydmVyLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkxvZ2dlckZpbGUiLCJfIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1ldGVvciIsIkxvZ2dlciIsImNoZWNrIiwiTWF0Y2giLCJmcyIsImRlZmF1bHQiLCJOT09QIiwiY29uc3RydWN0b3IiLCJsb2dnZXIiLCJvcHRpb25zIiwiT25lT2YiLCJPYmplY3QiLCJPcHRpb25hbCIsImZpbGVOYW1lRm9ybWF0IiwiaXNGdW5jdGlvbiIsIkVycm9yIiwidGltZSIsIm1vbnRoIiwiZ2V0TW9udGgiLCJsZW5ndGgiLCJkYXRlIiwiZ2V0RGF0ZSIsInllYXIiLCJnZXRGdWxsWWVhciIsImZvcm1hdCIsImxldmVsIiwibWVzc2FnZSIsImRhdGEiLCJ1c2VySWQiLCJob3VycyIsImdldEhvdXJzIiwibWlucyIsImdldE1pbnV0ZXMiLCJzZWMiLCJnZXRTZWNvbmRzIiwicGF0aCIsImlzU3RyaW5nIiwicm9vdFBhdGgiLCJwcm9jZXNzIiwiZW52IiwiTk9ERV9FTlYiLCJyZXBsYWNlIiwiZW5zdXJlRGlyIiwiRURFcnJvciIsIndyaXRlRmlsZSIsIldGRXJyb3IiLCJ1bmxpbmsiLCJhZGQiLCJEYXRlIiwiX2RhdGEiLCJhbnRpQ2lyY3VsYXIiLCJjbG9uZSIsInN0YWNrVHJhY2UiLCJzcGxpdCIsIkpTT04iLCJzdHJpbmdpZnkiLCJhcHBlbmRGaWxlIiwiZW5hYmxlIiwicnVsZSIsIkJvb2xlYW4iLCJjbGllbnQiLCJzZXJ2ZXIiLCJmaWx0ZXIiLCJTdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLGNBQVcsTUFBSUE7QUFBaEIsQ0FBZDs7QUFBMkMsSUFBSUMsQ0FBSjs7QUFBTUgsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLG1CQUFSLENBQWIsRUFBMEM7QUFBQ0YsSUFBRUcsQ0FBRixFQUFJO0FBQUNILFFBQUVHLENBQUY7QUFBSTs7QUFBVixDQUExQyxFQUFzRCxDQUF0RDtBQUF5RCxJQUFJQyxNQUFKO0FBQVdQLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0UsU0FBT0QsQ0FBUCxFQUFTO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUUsTUFBSjtBQUFXUixPQUFPSSxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDRyxTQUFPRixDQUFQLEVBQVM7QUFBQ0UsYUFBT0YsQ0FBUDtBQUFTOztBQUFwQixDQUE3QyxFQUFtRSxDQUFuRTtBQUFzRSxJQUFJRyxLQUFKLEVBQVVDLEtBQVY7QUFBZ0JWLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0ksUUFBTUgsQ0FBTixFQUFRO0FBQUNHLFlBQU1ILENBQU47QUFBUSxHQUFsQjs7QUFBbUJJLFFBQU1KLENBQU4sRUFBUTtBQUFDSSxZQUFNSixDQUFOO0FBQVE7O0FBQXBDLENBQXJDLEVBQTJFLENBQTNFO0FBQThFLElBQUlLLEVBQUo7QUFBT1gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDTyxVQUFRTixDQUFSLEVBQVU7QUFBQ0ssU0FBR0wsQ0FBSDtBQUFLOztBQUFqQixDQUFqQyxFQUFvRCxDQUFwRDs7QUFLMVcsTUFBTU8sT0FBTyxNQUFNLENBQUUsQ0FBckI7QUFFQTs7Ozs7O0FBSUEsTUFBTVgsVUFBTixDQUFpQjtBQUNmWSxjQUFZQyxNQUFaLEVBQW9CQyxVQUFVLEVBQTlCLEVBQWtDO0FBQ2hDUCxVQUFNTSxNQUFOLEVBQWNMLE1BQU1PLEtBQU4sQ0FBWVQsTUFBWixFQUFvQlUsTUFBcEIsQ0FBZDtBQUNBVCxVQUFNTyxPQUFOLEVBQWVOLE1BQU1TLFFBQU4sQ0FBZUQsTUFBZixDQUFmO0FBRUEsU0FBS0gsTUFBTCxHQUFlQSxNQUFmO0FBQ0EsU0FBS0MsT0FBTCxHQUFlQSxPQUFmO0FBRUE7O0FBQ0EsUUFBSSxLQUFLQSxPQUFMLENBQWFJLGNBQWpCLEVBQWlDO0FBQy9CLFVBQUksQ0FBQ2pCLEVBQUVrQixVQUFGLENBQWEsS0FBS0wsT0FBTCxDQUFhSSxjQUExQixDQUFMLEVBQWdEO0FBQzlDLGNBQU0sSUFBSWIsT0FBT2UsS0FBWCxDQUFpQiwyREFBakIsQ0FBTjtBQUNEO0FBQ0YsS0FKRCxNQUlPO0FBQ0wsV0FBS04sT0FBTCxDQUFhSSxjQUFiLEdBQStCRyxJQUFELElBQVU7QUFDdEMsWUFBSUMsUUFBUyxHQUFFRCxLQUFLRSxRQUFMLEtBQWtCLENBQUUsRUFBbkM7O0FBQ0EsWUFBSUQsTUFBTUUsTUFBTixLQUFpQixDQUFyQixFQUF3QjtBQUN0QkYsa0JBQVEsTUFBTUEsS0FBZDtBQUNEOztBQUVELFlBQUlHLE9BQVMsR0FBRUosS0FBS0ssT0FBTCxFQUFlLEVBQTlCOztBQUNBLFlBQUlELEtBQUtELE1BQUwsS0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckJDLGlCQUFRLE1BQU1BLElBQWQ7QUFDRDs7QUFFRCxZQUFJRSxPQUFTLEdBQUVOLEtBQUtPLFdBQUwsRUFBbUIsRUFBbEM7O0FBQ0EsWUFBSUQsS0FBS0gsTUFBTCxLQUFnQixDQUFwQixFQUF1QjtBQUNyQkcsaUJBQVEsTUFBTUEsSUFBZDtBQUNEOztBQUVELGVBQVEsR0FBRUYsSUFBSyxJQUFHSCxLQUFNLElBQUdLLElBQUssTUFBaEM7QUFDRCxPQWpCRDtBQWtCRDtBQUVEOzs7QUFDQSxRQUFJLEtBQUtiLE9BQUwsQ0FBYWUsTUFBakIsRUFBeUI7QUFDdkIsVUFBRyxDQUFDNUIsRUFBRWtCLFVBQUYsQ0FBYSxLQUFLTCxPQUFMLENBQWFlLE1BQTFCLENBQUosRUFBdUM7QUFDckMsY0FBTSxJQUFJeEIsT0FBT2UsS0FBWCxDQUFpQixtREFBakIsQ0FBTjtBQUNEO0FBQ0YsS0FKRCxNQUlPO0FBQ0wsV0FBS04sT0FBTCxDQUFhZSxNQUFiLEdBQXNCLENBQUNSLElBQUQsRUFBT1MsS0FBUCxFQUFjQyxPQUFkLEVBQXVCQyxJQUF2QixFQUE2QkMsTUFBN0IsS0FBd0M7QUFDNUQsWUFBSVgsUUFBUyxHQUFFRCxLQUFLRSxRQUFMLEtBQWtCLENBQUUsRUFBbkM7O0FBQ0EsWUFBSUQsTUFBTUUsTUFBTixLQUFpQixDQUFyQixFQUF3QjtBQUN0QkYsa0JBQVEsTUFBTUEsS0FBZDtBQUNEOztBQUNELFlBQUlHLE9BQVMsR0FBRUosS0FBS0ssT0FBTCxFQUFlLEVBQTlCOztBQUNBLFlBQUlELEtBQUtELE1BQUwsS0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckJDLGlCQUFRLE1BQU1BLElBQWQ7QUFDRDs7QUFDRCxZQUFJRSxPQUFTLEdBQUVOLEtBQUtPLFdBQUwsRUFBbUIsRUFBbEM7O0FBQ0EsWUFBSUQsS0FBS0gsTUFBTCxLQUFnQixDQUFwQixFQUF1QjtBQUNyQkcsaUJBQVEsTUFBTUEsSUFBZDtBQUNEOztBQUNELFlBQUlPLFFBQVMsR0FBRWIsS0FBS2MsUUFBTCxFQUFnQixFQUEvQjs7QUFDQSxZQUFJRCxNQUFNVixNQUFOLEtBQWlCLENBQXJCLEVBQXdCO0FBQ3RCVSxrQkFBUSxNQUFNQSxLQUFkO0FBQ0Q7O0FBQ0QsWUFBSUUsT0FBUyxHQUFFZixLQUFLZ0IsVUFBTCxFQUFrQixFQUFqQzs7QUFDQSxZQUFJRCxLQUFLWixNQUFMLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCWSxpQkFBUSxNQUFNQSxJQUFkO0FBQ0Q7O0FBQ0QsWUFBSUUsTUFBUyxHQUFFakIsS0FBS2tCLFVBQUwsRUFBa0IsRUFBakM7O0FBQ0EsWUFBSUQsSUFBSWQsTUFBSixLQUFlLENBQW5CLEVBQXNCO0FBQ3BCYyxnQkFBUSxNQUFNQSxHQUFkO0FBQ0Q7O0FBRUQsZUFBUSxHQUFFYixJQUFLLElBQUdILEtBQU0sSUFBR0ssSUFBSyxJQUFHTyxLQUFNLElBQUdFLElBQUssSUFBR0UsR0FBSSxPQUFNUixLQUFNLGtCQUFpQkMsT0FBUSxjQUFhRSxNQUFPLFlBQVdELElBQUssTUFBakk7QUFDRCxPQTNCRDtBQTRCRDtBQUVEOzs7QUFDQSxRQUFJLEtBQUtsQixPQUFMLENBQWEwQixJQUFqQixFQUF1QjtBQUNyQixVQUFJLENBQUN2QyxFQUFFd0MsUUFBRixDQUFXLEtBQUszQixPQUFMLENBQWEwQixJQUF4QixDQUFMLEVBQW9DO0FBQ2xDLGNBQU0sSUFBSW5DLE9BQU9lLEtBQVgsQ0FBaUIsK0NBQWpCLENBQU47QUFDRDtBQUNGLEtBSkQsTUFJTztBQUNMLFdBQUtOLE9BQUwsQ0FBYTBCLElBQWIsR0FBb0JuQyxPQUFPcUMsUUFBUCxJQUFvQkMsUUFBUUMsR0FBUixDQUFZQyxRQUFaLEtBQXlCLGFBQTFCLEdBQTJDLGNBQTNDLEdBQTRELGtCQUEvRSxDQUFwQjtBQUNEOztBQUVELFNBQUsvQixPQUFMLENBQWEwQixJQUFiLEdBQW9CLEtBQUsxQixPQUFMLENBQWEwQixJQUFiLENBQWtCTSxPQUFsQixDQUEwQixLQUExQixFQUFpQyxFQUFqQyxDQUFwQjtBQUVBckMsT0FBR3NDLFNBQUgsQ0FBYyxHQUFFLEtBQUtqQyxPQUFMLENBQWEwQixJQUFLLEVBQWxDLEVBQXNDUSxPQUFELElBQWE7QUFDaEQsVUFBSUEsT0FBSixFQUFhO0FBQ1gsY0FBTSxJQUFJM0MsT0FBT2UsS0FBWCxDQUFpQixvQ0FBakIsRUFBdUQ0QixPQUF2RCxDQUFOO0FBQ0Q7O0FBRUR2QyxTQUFHd0MsU0FBSCxDQUFjLEdBQUUsS0FBS25DLE9BQUwsQ0FBYTBCLElBQUssT0FBbEMsRUFBMEMsTUFBMUMsRUFBbURVLE9BQUQsSUFBYTtBQUM3RCxZQUFJQSxPQUFKLEVBQWE7QUFDWCxnQkFBTSxJQUFJN0MsT0FBT2UsS0FBWCxDQUFrQiwrQkFBOEIsS0FBS04sT0FBTCxDQUFhMEIsSUFBSyxxQkFBbEUsRUFBd0ZVLE9BQXhGLENBQU47QUFDRDs7QUFDRHpDLFdBQUcwQyxNQUFILENBQVcsR0FBRSxLQUFLckMsT0FBTCxDQUFhMEIsSUFBSyxPQUEvQixFQUF1QzdCLElBQXZDO0FBQ0QsT0FMRDtBQU1ELEtBWEQ7QUFhQSxTQUFLRSxNQUFMLENBQVl1QyxHQUFaLENBQWdCLE1BQWhCLEVBQXdCLENBQUN0QixLQUFELEVBQVFDLE9BQVIsRUFBaUJDLE9BQU8sSUFBeEIsRUFBOEJDLE1BQTlCLEtBQXlDO0FBQy9ELFlBQU1aLE9BQU8sSUFBSWdDLElBQUosRUFBYjtBQUNBLFVBQUlDLFFBQVMsSUFBYjs7QUFFQSxVQUFJdEIsSUFBSixFQUFVO0FBQ1JzQixnQkFBUSxLQUFLekMsTUFBTCxDQUFZMEMsWUFBWixDQUF5QnRELEVBQUV1RCxLQUFGLENBQVF4QixJQUFSLENBQXpCLENBQVI7O0FBQ0EsWUFBSS9CLEVBQUV3QyxRQUFGLENBQVdhLE1BQU1HLFVBQWpCLENBQUosRUFBa0M7QUFDaENILGdCQUFNRyxVQUFOLEdBQW1CSCxNQUFNRyxVQUFOLENBQWlCQyxLQUFqQixDQUF1QixpQkFBdkIsQ0FBbkI7QUFDRDs7QUFDREosZ0JBQVFLLEtBQUtDLFNBQUwsQ0FBZU4sS0FBZixFQUFzQixLQUF0QixFQUE2QixDQUE3QixDQUFSO0FBQ0Q7O0FBRUQ3QyxTQUFHb0QsVUFBSCxDQUFlLEdBQUUsS0FBSy9DLE9BQUwsQ0FBYTBCLElBQUssSUFBRyxLQUFLMUIsT0FBTCxDQUFhSSxjQUFiLENBQTRCRyxJQUE1QixDQUFrQyxFQUF4RSxFQUEyRSxLQUFLUCxPQUFMLENBQWFlLE1BQWIsQ0FBb0JSLElBQXBCLEVBQTBCUyxLQUExQixFQUFpQ0MsT0FBakMsRUFBMEN1QixLQUExQyxFQUFpRHJCLE1BQWpELENBQTNFLEVBQXFJdEIsSUFBckk7QUFDRCxLQWJELEVBYUdBLElBYkgsRUFhUyxLQWJULEVBYWdCLEtBYmhCO0FBY0Q7O0FBRURtRCxTQUFPQyxPQUFPLEVBQWQsRUFBa0I7QUFDaEJ4RCxVQUFNd0QsSUFBTixFQUFZO0FBQ1ZELGNBQVF0RCxNQUFNUyxRQUFOLENBQWUrQyxPQUFmLENBREU7QUFFVkMsY0FBUXpELE1BQU1TLFFBQU4sQ0FBZStDLE9BQWYsQ0FGRTtBQUdWRSxjQUFRMUQsTUFBTVMsUUFBTixDQUFlK0MsT0FBZixDQUhFO0FBSVZHLGNBQVEzRCxNQUFNUyxRQUFOLENBQWUsQ0FBQ21ELE1BQUQsQ0FBZjtBQUpFLEtBQVo7O0FBT0EsUUFBSUwsS0FBS0QsTUFBTCxJQUFlLElBQW5CLEVBQXlCO0FBQ3ZCQyxXQUFLRCxNQUFMLEdBQWMsSUFBZDtBQUNEOztBQUNELFFBQUlDLEtBQUtFLE1BQUwsSUFBZSxJQUFuQixFQUF5QjtBQUN2QkYsV0FBS0UsTUFBTCxHQUFjLElBQWQ7QUFDRDs7QUFDRCxRQUFJRixLQUFLRyxNQUFMLElBQWUsSUFBbkIsRUFBeUI7QUFDdkJILFdBQUtHLE1BQUwsR0FBYyxJQUFkO0FBQ0Q7O0FBRUQsU0FBS3JELE1BQUwsQ0FBWWtELElBQVosQ0FBaUIsTUFBakIsRUFBeUJBLElBQXpCO0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7O0FBbEljLEMiLCJmaWxlIjoiL3BhY2thZ2VzL29zdHJpb19sb2dnZXJmaWxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgXyB9ICAgICAgICAgICAgZnJvbSAnbWV0ZW9yL3VuZGVyc2NvcmUnO1xuaW1wb3J0IHsgTWV0ZW9yIH0gICAgICAgZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBMb2dnZXIgfSAgICAgICBmcm9tICdtZXRlb3Ivb3N0cmlvOmxvZ2dlcic7XG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IGZzICAgICAgICAgICAgICAgZnJvbSAnZnMtZXh0cmEnO1xuY29uc3QgTk9PUCA9ICgpID0+IHt9O1xuXG4vKlxuICogQGNsYXNzIExvZ2dlckZpbGVcbiAqIEBzdW1tYXJ5IEZpbGUgKEZTKSBhZGFwdGVyIGZvciBvc3RyaW86bG9nZ2VyIChMb2dnZXIpXG4gKi9cbmNsYXNzIExvZ2dlckZpbGUge1xuICBjb25zdHJ1Y3Rvcihsb2dnZXIsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNoZWNrKGxvZ2dlciwgTWF0Y2guT25lT2YoTG9nZ2VyLCBPYmplY3QpKTtcbiAgICBjaGVjayhvcHRpb25zLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcblxuICAgIHRoaXMubG9nZ2VyICA9IGxvZ2dlcjtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXG4gICAgLyogZmlsZU5hbWVGb3JtYXQgLSBMb2cgZmlsZSBuYW1lICovXG4gICAgaWYgKHRoaXMub3B0aW9ucy5maWxlTmFtZUZvcm1hdCkge1xuICAgICAgaWYgKCFfLmlzRnVuY3Rpb24odGhpcy5vcHRpb25zLmZpbGVOYW1lRm9ybWF0KSkge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdbTG9nZ2VyRmlsZV0gW29wdGlvbnMuZmlsZU5hbWVGb3JtYXRdIE11c3QgYmUgYSBGdW5jdGlvbiEnKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5vcHRpb25zLmZpbGVOYW1lRm9ybWF0ID0gKHRpbWUpID0+IHtcbiAgICAgICAgbGV0IG1vbnRoID0gYCR7dGltZS5nZXRNb250aCgpICsgMX1gO1xuICAgICAgICBpZiAobW9udGgubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgbW9udGggPSAnMCcgKyBtb250aDtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBkYXRlICA9IGAke3RpbWUuZ2V0RGF0ZSgpfWA7XG4gICAgICAgIGlmIChkYXRlLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIGRhdGUgID0gJzAnICsgZGF0ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCB5ZWFyICA9IGAke3RpbWUuZ2V0RnVsbFllYXIoKX1gO1xuICAgICAgICBpZiAoeWVhci5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICB5ZWFyICA9ICcwJyArIHllYXI7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gYCR7ZGF0ZX0tJHttb250aH0tJHt5ZWFyfS5sb2dgO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICAvKiBmb3JtYXQgLSBMb2cgcmVjb3JkIGZvcm1hdCAqL1xuICAgIGlmICh0aGlzLm9wdGlvbnMuZm9ybWF0KSB7XG4gICAgICBpZighXy5pc0Z1bmN0aW9uKHRoaXMub3B0aW9ucy5mb3JtYXQpKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ1tMb2dnZXJGaWxlXSBbb3B0aW9ucy5mb3JtYXRdIE11c3QgYmUgYSBGdW5jdGlvbiEnKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5vcHRpb25zLmZvcm1hdCA9ICh0aW1lLCBsZXZlbCwgbWVzc2FnZSwgZGF0YSwgdXNlcklkKSA9PiB7XG4gICAgICAgIGxldCBtb250aCA9IGAke3RpbWUuZ2V0TW9udGgoKSArIDF9YDtcbiAgICAgICAgaWYgKG1vbnRoLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIG1vbnRoID0gJzAnICsgbW9udGg7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGRhdGUgID0gYCR7dGltZS5nZXREYXRlKCl9YDtcbiAgICAgICAgaWYgKGRhdGUubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgZGF0ZSAgPSAnMCcgKyBkYXRlO1xuICAgICAgICB9XG4gICAgICAgIGxldCB5ZWFyICA9IGAke3RpbWUuZ2V0RnVsbFllYXIoKX1gO1xuICAgICAgICBpZiAoeWVhci5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICB5ZWFyICA9ICcwJyArIHllYXI7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGhvdXJzID0gYCR7dGltZS5nZXRIb3VycygpfWA7XG4gICAgICAgIGlmIChob3Vycy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICBob3VycyA9ICcwJyArIGhvdXJzO1xuICAgICAgICB9XG4gICAgICAgIGxldCBtaW5zICA9IGAke3RpbWUuZ2V0TWludXRlcygpfWA7XG4gICAgICAgIGlmIChtaW5zLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIG1pbnMgID0gJzAnICsgbWlucztcbiAgICAgICAgfVxuICAgICAgICBsZXQgc2VjICAgPSBgJHt0aW1lLmdldFNlY29uZHMoKX1gO1xuICAgICAgICBpZiAoc2VjLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIHNlYyAgID0gJzAnICsgc2VjO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGAke2RhdGV9LSR7bW9udGh9LSR7eWVhcn0gJHtob3Vyc306JHttaW5zfToke3NlY30gfCBbJHtsZXZlbH1dIHwgTWVzc2FnZTogXFxcIiR7bWVzc2FnZX1cXFwiIHwgVXNlcjogJHt1c2VySWR9IHwgZGF0YTogJHtkYXRhfVxcclxcbmA7XG4gICAgICB9O1xuICAgIH1cblxuICAgIC8qIHBhdGggLSBMb2cncyBzdG9yYWdlIHBhdGggKi9cbiAgICBpZiAodGhpcy5vcHRpb25zLnBhdGgpIHtcbiAgICAgIGlmICghXy5pc1N0cmluZyh0aGlzLm9wdGlvbnMucGF0aCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignW0xvZ2dlckZpbGVdIFtvcHRpb25zLnBhdGhdIE11c3QgYmUgYSBTdHJpbmchJyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMub3B0aW9ucy5wYXRoID0gTWV0ZW9yLnJvb3RQYXRoICsgKChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ2RldmVsb3BtZW50JykgPyAnL3N0YXRpYy9sb2dzJyA6ICcvYXNzZXRzL2FwcC9sb2dzJyk7XG4gICAgfVxuXG4gICAgdGhpcy5vcHRpb25zLnBhdGggPSB0aGlzLm9wdGlvbnMucGF0aC5yZXBsYWNlKC9cXC8kLywgJycpO1xuXG4gICAgZnMuZW5zdXJlRGlyKGAke3RoaXMub3B0aW9ucy5wYXRofWAsIChFREVycm9yKSA9PiB7XG4gICAgICBpZiAoRURFcnJvcikge1xuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdbTG9nZ2VyRmlsZV0gW29wdGlvbnMucGF0aF0gRXJyb3I6JywgRURFcnJvcik7XG4gICAgICB9XG5cbiAgICAgIGZzLndyaXRlRmlsZShgJHt0aGlzLm9wdGlvbnMucGF0aH0vdGVzdGAsICd0ZXN0JywgKFdGRXJyb3IpID0+IHtcbiAgICAgICAgaWYgKFdGRXJyb3IpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGBbTG9nZ2VyRmlsZV0gW29wdGlvbnMucGF0aF0gJHt0aGlzLm9wdGlvbnMucGF0aH0gaXMgbm90IHdyaXRhYmxlISEhYCwgV0ZFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZnMudW5saW5rKGAke3RoaXMub3B0aW9ucy5wYXRofS90ZXN0YCwgTk9PUCk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHRoaXMubG9nZ2VyLmFkZCgnRmlsZScsIChsZXZlbCwgbWVzc2FnZSwgZGF0YSA9IG51bGwsIHVzZXJJZCkgPT4ge1xuICAgICAgY29uc3QgdGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICBsZXQgX2RhdGEgID0gbnVsbDtcblxuICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgX2RhdGEgPSB0aGlzLmxvZ2dlci5hbnRpQ2lyY3VsYXIoXy5jbG9uZShkYXRhKSk7XG4gICAgICAgIGlmIChfLmlzU3RyaW5nKF9kYXRhLnN0YWNrVHJhY2UpKSB7XG4gICAgICAgICAgX2RhdGEuc3RhY2tUcmFjZSA9IF9kYXRhLnN0YWNrVHJhY2Uuc3BsaXQoL1xcbnxcXFxcbnxcXHJ8XFxyXFxuL2cpO1xuICAgICAgICB9XG4gICAgICAgIF9kYXRhID0gSlNPTi5zdHJpbmdpZnkoX2RhdGEsIGZhbHNlLCAyKTtcbiAgICAgIH1cblxuICAgICAgZnMuYXBwZW5kRmlsZShgJHt0aGlzLm9wdGlvbnMucGF0aH0vJHt0aGlzLm9wdGlvbnMuZmlsZU5hbWVGb3JtYXQodGltZSl9YCwgdGhpcy5vcHRpb25zLmZvcm1hdCh0aW1lLCBsZXZlbCwgbWVzc2FnZSwgX2RhdGEsIHVzZXJJZCksIE5PT1ApO1xuICAgIH0sIE5PT1AsIGZhbHNlLCBmYWxzZSk7XG4gIH1cblxuICBlbmFibGUocnVsZSA9IHt9KSB7XG4gICAgY2hlY2socnVsZSwge1xuICAgICAgZW5hYmxlOiBNYXRjaC5PcHRpb25hbChCb29sZWFuKSxcbiAgICAgIGNsaWVudDogTWF0Y2guT3B0aW9uYWwoQm9vbGVhbiksXG4gICAgICBzZXJ2ZXI6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgICAgZmlsdGVyOiBNYXRjaC5PcHRpb25hbChbU3RyaW5nXSlcbiAgICB9KTtcblxuICAgIGlmIChydWxlLmVuYWJsZSA9PSBudWxsKSB7XG4gICAgICBydWxlLmVuYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIGlmIChydWxlLmNsaWVudCA9PSBudWxsKSB7XG4gICAgICBydWxlLmNsaWVudCA9IHRydWU7XG4gICAgfVxuICAgIGlmIChydWxlLnNlcnZlciA9PSBudWxsKSB7XG4gICAgICBydWxlLnNlcnZlciA9IHRydWU7XG4gICAgfVxuXG4gICAgdGhpcy5sb2dnZXIucnVsZSgnRmlsZScsIHJ1bGUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG59XG5cbmV4cG9ydCB7IExvZ2dlckZpbGUgfTtcbiJdfQ==
